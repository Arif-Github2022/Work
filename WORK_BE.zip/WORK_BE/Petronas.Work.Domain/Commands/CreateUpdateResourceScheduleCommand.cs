﻿using MediatR;
using Petronas.Work.Domain.Models;

namespace Petronas.Work.Domain.Commands
{
    public class CreateUpdateResourceScheduleCommand: IRequest<DefaultResponseResult>
    {
        public string? TraceID { get; set; }
        public List<ResourceScheduleDetails> ResourceSchedule { get; set; }
    }

    public class ResourceScheduleDetails
    {
        public Guid Id { get; set; }
        
        public Guid ResourceId { get; set; }
        
        public string? ResourceName { get; set; }

        public string? ResourceCompany { get; set; }

        public bool IsResourceContractor { get; set; }
        
        public string? ResourceAceId { get; set; }
        
        public Guid WorkOrderId { get; set; }
        
        public DateTime? PlannedDate { get; set; }
        
        public int? PlannedWorkHours { get; set; }
    }
}
