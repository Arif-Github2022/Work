﻿using MediatR;
using Petronas.Work.Domain.Models;

namespace Petronas.Work.Domain.Commands
{
    public class CreateScheduleCommand : IRequest<DefaultResponseResult>
    {   
        public string? TraceID { get; set; }
        public Guid Id { get; set; }
        public Guid WorkOrderId { get; set; }
        public DateTime? ScheduleStartDate { get; set; }
        public DateTime? ScheduleEndDate { get; set; }
        public DateTime RecordCreatedOn { get; set; }
        public Guid RecordCreatedById { get; set; }
        public DateTime RecordUpdatedOn { get; set; }
        public Guid RecordUpdatedById { get; set; }
        public bool? IsActive { get; set; }
        public bool? IsDeleted { get; set; }
    }
}
