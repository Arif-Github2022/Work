﻿using MediatR;
using Petronas.Work.Domain.Models;

namespace Petronas.Work.Domain.Commands
{
    public class CreateResourceCommand : IRequest<DefaultResponseResult>
    {
        public string? TeamId { get; set; }
        public List<ResourceInformation>? ResourceInformation { get; set; }
    }
}
