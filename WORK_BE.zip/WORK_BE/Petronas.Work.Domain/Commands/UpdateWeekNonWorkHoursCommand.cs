﻿using MediatR;
using Petronas.Work.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Domain.Commands
{
    public class UpdateWeekNonWorkHoursCommand : IRequest<DefaultResponseResult>
    {
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

        public string TraceId { get; set; }
        public List<ResourceNonWorkHours> ResourceNonWorkHours { get; set; }
    }
    public class ResourceNonWorkHours

    {
        public Guid Id { get; set; }
        public string Name { get; set; }

        public List<WeekDayNonWorkHours> WeekDayNonWorkHours { get; set; }
    }

    public class WeekDayNonWorkHours
    {
        public string WeekDay { get; set; }
        public int AwayHours { get; set; }
    }
}
