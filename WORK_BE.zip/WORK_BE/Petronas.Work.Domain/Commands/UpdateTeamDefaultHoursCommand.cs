﻿using MediatR;
using Petronas.Work.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Domain.Commands
{

    public class UpdateTeamDefaultHoursCommand : IRequest<DefaultResponseResult>
    {
        public List<resourceDefaultWorkHours> ResourceDefaultWorkHours { get; set; }

        public string TraceId { get; set; }
    }

    public class resourceDefaultWorkHours

    {
        public Guid? Id { get; set; }
        public string Name { get; set; }

        public List<weekDayDefaultWorkHours> WeekDayDefaultWorkHours { get; set; }
    }

    public class weekDayDefaultWorkHours
    {
        public string WeekDay { get; set; }
        public int WorkHours { get; set; }
    }
}
