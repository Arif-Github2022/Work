﻿using MediatR;
using Petronas.Work.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Domain.Commands
{
    public class CreateTeamCommand : IRequest<DefaultResponseResult>
    {
        public string? TraceID { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public Guid Id { get; set; }
        public DateTime RecordCreatedOn { get; set; }
        public Guid RecordCreatedById { get; set; }
        public DateTime RecordUpdatedOn { get; set; }
        public Guid RecordUpdatedById { get; set; }
        public bool? IsActive { get; set; }
        public bool? IsDeleted { get; set; }
    }

}
