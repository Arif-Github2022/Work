﻿using AutoMapper;
using Petronas.Work.Core.Model;
using Petronas.Work.Data.Entities.dbo;
using Petronas.Work.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Domain.MappingProfiles
{
    public class ResourceScheduleMappingProfile : Profile
    {
        public ResourceScheduleMappingProfile()
        {
            // Db object to business object mapping
            CreateMap<WorkOrder, GetResourceScheduleQueryResult>()
                .ReverseMap();
        }
    }
}
