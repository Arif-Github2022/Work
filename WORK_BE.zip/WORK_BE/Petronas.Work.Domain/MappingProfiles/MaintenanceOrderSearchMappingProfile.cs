﻿using AutoMapper;
using Petronas.Work.Core.Model;
using Petronas.Work.Data.Entities.dbo;
using Petronas.Work.Domain.Models;
namespace Petronas.Work.Domain.MappingProfiles
{
    public class MaintenanceOrderSearchMappingProfile : Profile
    {
        public MaintenanceOrderSearchMappingProfile()
        {
            // Db object to business object mapping
            CreateMap<WorkOrder, MaintenanceOrderSearchResult>()
                .ReverseMap();

            CreateMap<WeekInfo, OrderWeekSchedule>()
                .ForMember(orderWeekSchedule => orderWeekSchedule.StartDate, opt => opt.MapFrom(weekInfo => weekInfo.StartDate))
                .ForMember(orderWeekSchedule => orderWeekSchedule.EndDate, opt => opt.MapFrom(weekInfo => weekInfo.EndDate))
                .ForMember(orderWeekSchedule => orderWeekSchedule.WeekNumber, opt => opt.MapFrom(weekInfo => weekInfo.WeekNumberOfYear))
                .ReverseMap();
        }
    }
}
