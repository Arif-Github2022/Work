﻿using Petronas.Work.Core.Model;
using Petronas.Work.Data.Entities.dbo;
using Petronas.Work.Domain.Common.Interface;

namespace Petronas.Work.Domain.Common
{
    public class ResourceWeekWorkHourCalculator : IResourceWeekWorkHourCalculator
    {
        public int CalculateAndGetAvailableHours(WeekInfo week, List<DefaultResourceWorkPlan> defaultResourceWorkPlanList)
        {
            int availableHours = 0;
            if (defaultResourceWorkPlanList != null && defaultResourceWorkPlanList.Any())
            {
                DateTime currentDate = week.StartDate;
                while (currentDate.Date <= week.EndDate.Date)
                {
                    if (currentDate.DayOfWeek != DayOfWeek.Saturday && currentDate.DayOfWeek != DayOfWeek.Sunday)
                    {
                        var resourceWorkPlan = defaultResourceWorkPlanList.Find(x => !string.IsNullOrWhiteSpace(x.WeekDay) && Enum.TryParse<DayOfWeek>(x.WeekDay, out _) && Enum.Parse<DayOfWeek>(x.WeekDay) == currentDate.DayOfWeek);

                        if (resourceWorkPlan != null)
                        {
                            availableHours += resourceWorkPlan.WorkHours;
                        }
                    }
                    currentDate = currentDate.AddDays(1);
                }
            }
            return availableHours;
        }

        public int CalculateAndGetPlannedHours(WeekInfo week, List<ResourceSchedule> ResourceScheduleList, List<DefaultResourceWorkPlan> defaultResourceWorkPlanList)
        {
            int plannedHours = 0;
            if (ResourceScheduleList != null && ResourceScheduleList.Any())
            {
                DateTime currentDate = week.StartDate;
                while (currentDate.Date <= week.EndDate.Date)
                {
                    if (currentDate.DayOfWeek != DayOfWeek.Saturday && currentDate.DayOfWeek != DayOfWeek.Sunday)
                    {
                        var defaultResourceWorkPlan = defaultResourceWorkPlanList.Find(x => !string.IsNullOrWhiteSpace(x.WeekDay) && Enum.TryParse<DayOfWeek>(x.WeekDay, out _) && Enum.Parse<DayOfWeek>(x.WeekDay) == currentDate.DayOfWeek);

                        var plannedScheduleList = ResourceScheduleList.FindAll(x => x.PlannedDate.HasValue && x.PlannedDate.Value.Date == currentDate.Date);

                        if (plannedScheduleList != null && plannedScheduleList.Any() && plannedScheduleList.All(i => i.PlannedWorkHours.HasValue))
                        {
                            // Remove overtime
                            if (defaultResourceWorkPlan != null)
                            {
                                plannedScheduleList.ForEach((plannedSchedule) =>
                                {
                                    if (plannedSchedule.PlannedWorkHours.Value > defaultResourceWorkPlan.WorkHours)
                                    {
                                        plannedHours += defaultResourceWorkPlan.WorkHours;
                                    }
                                    else
                                    {
                                        plannedHours += plannedSchedule.PlannedWorkHours.Value;
                                    }
                                });
                            }
                        }
                    }

                    currentDate = currentDate.AddDays(1);
                }
            }
            return plannedHours;
        }

        public int CalculateAndGetActualHours(WeekInfo week, List<ResourceSchedule> ResourceScheduleList, List<DefaultResourceWorkPlan> defaultResourceWorkPlanList)
        {
            int actualHours = 0;
            if (ResourceScheduleList != null && ResourceScheduleList.Any())
            {
                DateTime currentDate = week.StartDate;
                while (currentDate.Date <= week.EndDate.Date)
                {
                    if (currentDate.DayOfWeek != DayOfWeek.Saturday && currentDate.DayOfWeek != DayOfWeek.Sunday)
                    {
                        var defaultResourceWorkPlan = defaultResourceWorkPlanList.Find(x => !string.IsNullOrWhiteSpace(x.WeekDay) && Enum.TryParse<DayOfWeek>(x.WeekDay, out _) && Enum.Parse<DayOfWeek>(x.WeekDay) == currentDate.DayOfWeek);

                        var actualScheduleList = ResourceScheduleList.FindAll(x => x.ActualDate.HasValue && x.ActualDate.Value.Date == currentDate.Date);

                        if (actualScheduleList != null && actualScheduleList.Any() && actualScheduleList.All(i => i.ActualWorkHours.HasValue))
                        {
                            actualScheduleList.ForEach((actualSchedule) =>
                            {
                                if (actualSchedule.ActualWorkHours.Value > defaultResourceWorkPlan.WorkHours)
                                {
                                    actualHours += defaultResourceWorkPlan.WorkHours;
                                }
                                else
                                {
                                    actualHours += actualSchedule.ActualWorkHours.Value;
                                }
                            });
                        }
                    }

                    currentDate = currentDate.AddDays(1);
                }
            }
            return actualHours;
        }

        public int CalculateAndGetPlannedOvertimeHours(WeekInfo week, List<ResourceSchedule> ResourceScheduleList, List<DefaultResourceWorkPlan> defaultResourceWorkPlanList, List<ResourceCapacity> resourceCapacityList)
        {
            int overtimeHours = 0;
            if (ResourceScheduleList != null && ResourceScheduleList.Any())
            {
                DateTime currentDate = week.StartDate;
                while (currentDate.Date <= week.EndDate.Date)
                {
                    var defaultResourceWorkPlan = defaultResourceWorkPlanList.Find(x => !string.IsNullOrWhiteSpace(x.WeekDay) && Enum.TryParse<DayOfWeek>(x.WeekDay, out _) && Enum.Parse<DayOfWeek>(x.WeekDay) == currentDate.DayOfWeek);

                    var overtimeScheduleList = ResourceScheduleList.FindAll(x => x.PlannedDate.HasValue && x.PlannedDate.Value.Date == currentDate.Date)
                        .GroupBy(i => i.PlannedDate).Select(x => new ResourceSchedule
                        {
                            PlannedDate = x.Key,
                            ActualDate = x.First().ActualDate,
                            ActualWorkHours = x.Sum(k => k.ActualWorkHours),
                            PlannedWorkHours = x.Sum(k => k.PlannedWorkHours)
                        }).ToList();

                    var resourceCapacity = resourceCapacityList != null && resourceCapacityList.Any() ? resourceCapacityList.Find(x => x.Day.HasValue && x.Day.Value.Date == currentDate.Date) : null;

                    if (currentDate.DayOfWeek != DayOfWeek.Saturday && currentDate.DayOfWeek != DayOfWeek.Sunday)
                    {
                        if (overtimeScheduleList != null && overtimeScheduleList.Any() && overtimeScheduleList.All(i => i.PlannedWorkHours.HasValue) && defaultResourceWorkPlan != null)
                        {
                            overtimeScheduleList.ForEach((overtimeSchedule) =>
                            {
                                if (overtimeSchedule.PlannedDate.HasValue && overtimeSchedule.PlannedDate.Value.Date == currentDate.Date)
                                {
                                    var workHoursCapacityForDay = defaultResourceWorkPlan.WorkHours;

                                    if (resourceCapacity != null && resourceCapacity.AwayHours.HasValue)
                                    {
                                        workHoursCapacityForDay = defaultResourceWorkPlan.WorkHours - resourceCapacity.AwayHours.Value;

                                        if (overtimeSchedule.PlannedWorkHours.Value > workHoursCapacityForDay)
                                        {
                                            overtimeHours += overtimeSchedule.PlannedWorkHours.Value - workHoursCapacityForDay;
                                        }
                                    }
                                    else if (overtimeSchedule.PlannedWorkHours.Value > workHoursCapacityForDay)
                                    {
                                        overtimeHours += overtimeSchedule.PlannedWorkHours.Value - workHoursCapacityForDay;
                                    }
                                }
                            });
                        }
                    }

                    if (currentDate.DayOfWeek == DayOfWeek.Saturday || currentDate.DayOfWeek == DayOfWeek.Sunday)
                    {
                        if (overtimeScheduleList != null && overtimeScheduleList.Any() && overtimeScheduleList.All(i => i.PlannedWorkHours.HasValue) && defaultResourceWorkPlan != null)
                        {
                            overtimeScheduleList.ForEach((overtimeSchedule) =>
                            {
                                if (overtimeSchedule.PlannedDate.HasValue && overtimeSchedule.PlannedDate.Value.Date == currentDate.Date)
                                {
                                    if (overtimeSchedule.PlannedWorkHours.Value > defaultResourceWorkPlan.WorkHours)
                                    {
                                        overtimeHours += overtimeSchedule.PlannedWorkHours.Value;
                                    }
                                }
                            });
                        }
                    }
                    currentDate = currentDate.AddDays(1);
                }
            }
            return overtimeHours;
        }

        public int CalculateAndGetActualOvertimeHours(WeekInfo week, List<ResourceSchedule> ResourceScheduleList, List<DefaultResourceWorkPlan> defaultResourceWorkPlanList, List<ResourceCapacity> resourceCapacityList)
        {
            int overtimeHours = 0;
            if (ResourceScheduleList != null && ResourceScheduleList.Any())
            {
                DateTime currentDate = week.StartDate;
                while (currentDate.Date <= week.EndDate.Date)
                {
                    var defaultResourceWorkPlan = defaultResourceWorkPlanList.Find(x => !string.IsNullOrWhiteSpace(x.WeekDay) && Enum.TryParse<DayOfWeek>(x.WeekDay, out _) && Enum.Parse<DayOfWeek>(x.WeekDay) == currentDate.DayOfWeek);

                    var overtimeScheduleList = ResourceScheduleList.FindAll(x => x.ActualDate.HasValue && x.ActualDate.Value.Date == currentDate.Date)
                        .GroupBy(i => i.ActualDate).Select(x => new ResourceSchedule
                        {
                            PlannedDate = x.First().PlannedDate,
                            ActualDate = x.Key,
                            ActualWorkHours = x.Sum(k => k.ActualWorkHours),
                            PlannedWorkHours = x.Sum(k => k.PlannedWorkHours)
                        }).ToList();

                    var resourceCapacity = resourceCapacityList != null && resourceCapacityList.Any() ? resourceCapacityList.Find(x => x.Day.HasValue && x.Day.Value.Date == currentDate.Date) : null;

                    if (currentDate.DayOfWeek != DayOfWeek.Saturday && currentDate.DayOfWeek != DayOfWeek.Sunday)
                    {
                        if (overtimeScheduleList != null && overtimeScheduleList.Any() && overtimeScheduleList.All(i => i.ActualWorkHours.HasValue) && defaultResourceWorkPlan != null)
                        {
                            overtimeScheduleList.ForEach((overtimeSchedule) =>
                            {
                                if (overtimeSchedule.ActualDate.HasValue && overtimeSchedule.ActualDate.Value.Date == currentDate.Date)
                                {
                                    var workHoursCapacityForDay = defaultResourceWorkPlan.WorkHours;
                                    if (resourceCapacity != null && resourceCapacity.AwayHours.HasValue)
                                    {
                                        workHoursCapacityForDay = defaultResourceWorkPlan.WorkHours - resourceCapacity.AwayHours.Value;

                                        if (overtimeSchedule.ActualWorkHours.Value > workHoursCapacityForDay)
                                        {
                                            overtimeHours += overtimeSchedule.ActualWorkHours.Value - workHoursCapacityForDay;
                                        }
                                    }
                                    else if (overtimeSchedule.ActualWorkHours.Value > workHoursCapacityForDay)
                                    {
                                        overtimeHours += overtimeSchedule.ActualWorkHours.Value - workHoursCapacityForDay;
                                    }
                                }
                            });

                        }
                    }

                    if (currentDate.DayOfWeek == DayOfWeek.Saturday || currentDate.DayOfWeek == DayOfWeek.Sunday)
                    {
                        if (overtimeScheduleList != null && overtimeScheduleList.Any() && overtimeScheduleList.All(i => i.ActualWorkHours.HasValue) && defaultResourceWorkPlan != null)
                        {
                            overtimeScheduleList.ForEach((overtimeSchedule) =>
                            {
                                if (overtimeSchedule.ActualDate.HasValue && overtimeSchedule.ActualDate.Value.Date == currentDate.Date)
                                {
                                    if (overtimeSchedule.ActualWorkHours.Value > defaultResourceWorkPlan.WorkHours)
                                    {
                                        overtimeHours += overtimeSchedule.ActualWorkHours.Value;
                                    }
                                }
                            });

                        }
                    }
                    currentDate = currentDate.AddDays(1);
                }
            }
            return overtimeHours;
        }


        public int CalculateAndGetUnavailableHours(WeekInfo week, List<ResourceCapacity> resourceCapacityList)
        {
            int unavailableHours = 0;
            if (resourceCapacityList != null && resourceCapacityList.Any())
            {
                DateTime currentDate = week.StartDate;
                while (currentDate.Date <= week.EndDate.Date)
                {
                    var resourceCapacity = resourceCapacityList.Find(x =>x.Day.HasValue && x.Day.Value.Date == currentDate.Date);

                    if (resourceCapacity != null && resourceCapacity.AwayHours.HasValue)
                    {
                        unavailableHours += resourceCapacity.AwayHours.Value;
                    }

                    currentDate = currentDate.AddDays(1);
                }
            }
            return unavailableHours;
        }

        public List<(Guid ResourceId, DayOfWeek WeekDay, int AvailableHours)> CalculateAndGetWeekDayAvailableHours(WeekInfo week, List<DefaultResourceWorkPlan> defaultResourceWorkPlanList, List<DayOfWeek> dayOfWeekList)
        {
            var weekAvailableHours = new List<(Guid ResourceId, DayOfWeek WeekDay, int AvailableHours)>();

            if (defaultResourceWorkPlanList != null && defaultResourceWorkPlanList.Any())
            {
                DateTime currentDate = week.StartDate;
                var resourceId = defaultResourceWorkPlanList.First().ResourceId;
                while (currentDate.Date <= week.EndDate.Date)
                {
                    if (currentDate.DayOfWeek != DayOfWeek.Saturday && currentDate.DayOfWeek != DayOfWeek.Sunday)
                    {
                        if (dayOfWeekList.Contains(currentDate.DayOfWeek))
                        {
                            var resourceWorkPlan = defaultResourceWorkPlanList.Find(x => !string.IsNullOrWhiteSpace(x.WeekDay) && Enum.TryParse<DayOfWeek>(x.WeekDay, out _) && Enum.Parse<DayOfWeek>(x.WeekDay) == currentDate.DayOfWeek);

                            if (resourceWorkPlan != null)
                            {
                                weekAvailableHours.Add((resourceId, currentDate.DayOfWeek, resourceWorkPlan.WorkHours));
                            }
                        }
                    }
                    currentDate = currentDate.AddDays(1);
                }
            }
            return weekAvailableHours;
        }

        public List<(Guid ResourceId, DayOfWeek WeekDay, int PlannedHours)> CalculateAndGetWeekDayPlannedHours(WeekInfo week, List<ResourceSchedule> ResourceScheduleList, List<DefaultResourceWorkPlan> defaultResourceWorkPlanList, List<DayOfWeek> dayOfWeekList)
        {
            var weekPlannedHours = new List<(Guid ResourceId, DayOfWeek WeekDay, int PlannedHours)>();
            if (ResourceScheduleList != null && ResourceScheduleList.Any())
            {
                DateTime currentDate = week.StartDate;
                var resourceId = ResourceScheduleList.First().ResourceId;
                while (currentDate.Date <= week.EndDate.Date)
                {
                    if (currentDate.DayOfWeek != DayOfWeek.Saturday && currentDate.DayOfWeek != DayOfWeek.Sunday)
                    {
                        if (dayOfWeekList.Contains(currentDate.DayOfWeek))
                        {
                            var defaultResourceWorkPlan = defaultResourceWorkPlanList.Find(x => !string.IsNullOrWhiteSpace(x.WeekDay) && Enum.TryParse<DayOfWeek>(x.WeekDay, out _) && Enum.Parse<DayOfWeek>(x.WeekDay) == currentDate.DayOfWeek);

                            var plannedScheduleList = ResourceScheduleList.FindAll(x => x.PlannedDate.HasValue && x.PlannedDate.Value.Date == currentDate.Date);

                            if (plannedScheduleList != null && plannedScheduleList.Any() && plannedScheduleList.All(i => i.PlannedWorkHours.HasValue))
                            {
                                plannedScheduleList.ForEach((plannedSchedule) =>
                                {
                                    // Remove overtime
                                    if (defaultResourceWorkPlan != null && plannedSchedule.PlannedWorkHours.Value > defaultResourceWorkPlan.WorkHours)
                                    {
                                        weekPlannedHours.Add((resourceId, currentDate.DayOfWeek, defaultResourceWorkPlan.WorkHours));
                                    }
                                    else
                                    {
                                        weekPlannedHours.Add((resourceId, currentDate.DayOfWeek, plannedSchedule.PlannedWorkHours.Value));
                                    }
                                });
                            }
                        }
                    }

                    currentDate = currentDate.AddDays(1);
                }
            }
            return weekPlannedHours;
        }

        public List<(Guid ResourceId, DayOfWeek WeekDay, int ActualHours)> CalculateAndGetWeekDayActualHours(WeekInfo week, List<ResourceSchedule> ResourceScheduleList, List<DefaultResourceWorkPlan> defaultResourceWorkPlanList, List<DayOfWeek> dayOfWeekList)
        {
            var weekActualHours = new List<(Guid ResourceId, DayOfWeek WeekDay, int ActualHours)>();
            if (ResourceScheduleList != null && ResourceScheduleList.Any())
            {
                DateTime currentDate = week.StartDate;
                var resourceId = ResourceScheduleList.First().ResourceId;
                while (currentDate.Date <= week.EndDate.Date)
                {
                    if (currentDate.DayOfWeek != DayOfWeek.Saturday && currentDate.DayOfWeek != DayOfWeek.Sunday)
                    {
                        if (dayOfWeekList.Contains(currentDate.DayOfWeek))
                        {
                            var defaultResourceWorkPlan = defaultResourceWorkPlanList.Find(x => !string.IsNullOrWhiteSpace(x.WeekDay) && Enum.TryParse<DayOfWeek>(x.WeekDay, out _) && Enum.Parse<DayOfWeek>(x.WeekDay) == currentDate.DayOfWeek);

                            var actualScheduleList = ResourceScheduleList.FindAll(x => x.ActualDate.HasValue && x.ActualDate.Value.Date == currentDate.Date);

                            if (actualScheduleList != null && actualScheduleList.Any() && actualScheduleList.All(i => i.ActualWorkHours.HasValue))
                            {
                                actualScheduleList.ForEach((actualSchedule) =>
                                {
                                    if (actualSchedule.ActualWorkHours.Value > defaultResourceWorkPlan.WorkHours)
                                    {
                                        weekActualHours.Add((resourceId, currentDate.DayOfWeek, defaultResourceWorkPlan.WorkHours));
                                    }
                                    else
                                    {
                                        weekActualHours.Add((resourceId, currentDate.DayOfWeek, actualSchedule.ActualWorkHours.Value));
                                    }
                                });
                            }
                        }
                    }

                    currentDate = currentDate.AddDays(1);
                }
            }
            return weekActualHours;
        }


        public List<(Guid ResourceId, DayOfWeek WeekDay, int PlannedOvertimeHours)> CalculateAndGetWeekDayPlannedOvertimeHours(WeekInfo week, List<ResourceSchedule> ResourceScheduleList, List<DefaultResourceWorkPlan> defaultResourceWorkPlanList, List<ResourceCapacity> resourceCapacityList, List<DayOfWeek> dayOfWeekList)
        {
            var weekOvertimeHours = new List<(Guid ResourceId, DayOfWeek WeekDay, int OvertimeHours)>();
            if (ResourceScheduleList != null && ResourceScheduleList.Any())
            {
                DateTime currentDate = week.StartDate;
                var resourceId = ResourceScheduleList.First().ResourceId;
                while (currentDate.Date <= week.EndDate.Date)
                {
                    var defaultResourceWorkPlan = defaultResourceWorkPlanList.Find(x => !string.IsNullOrWhiteSpace(x.WeekDay) && Enum.TryParse<DayOfWeek>(x.WeekDay, out _) && Enum.Parse<DayOfWeek>(x.WeekDay) == currentDate.DayOfWeek);
                    var overtimeScheduleList = ResourceScheduleList.FindAll(x => x.PlannedDate.HasValue && x.PlannedDate.Value.Date == currentDate.Date)
                        .GroupBy(i => i.PlannedDate).Select(x => new ResourceSchedule
                        {
                            PlannedDate = x.Key,
                            ActualDate = x.First().ActualDate,
                            ActualWorkHours = x.Sum(k => k.ActualWorkHours),
                            PlannedWorkHours = x.Sum(k => k.PlannedWorkHours)
                        }).ToList();
                    var resourceCapacity = resourceCapacityList != null && resourceCapacityList.Any() ? resourceCapacityList.Find(x => x.Day.HasValue && x.Day.Value.Date == currentDate.Date) : null;

                    if (currentDate.DayOfWeek != DayOfWeek.Saturday && currentDate.DayOfWeek != DayOfWeek.Sunday && dayOfWeekList.Contains(currentDate.DayOfWeek))
                    {
                        if (overtimeScheduleList != null && overtimeScheduleList.Any() && overtimeScheduleList.All(i => i.PlannedWorkHours.HasValue) && defaultResourceWorkPlan != null)
                        {
                            overtimeScheduleList.ForEach((overtimeSchedule) =>
                            {
                                if (overtimeSchedule.PlannedDate.HasValue && overtimeSchedule.PlannedDate.Value.Date == currentDate.Date)
                                {
                                    var workHoursCapacityForDay = defaultResourceWorkPlan.WorkHours;

                                    if (resourceCapacity != null && resourceCapacity.AwayHours.HasValue)
                                    {
                                        workHoursCapacityForDay = defaultResourceWorkPlan.WorkHours - resourceCapacity.AwayHours.Value;

                                        if (overtimeSchedule.PlannedWorkHours.Value > workHoursCapacityForDay)
                                        {
                                            int overtimeHours = overtimeSchedule.PlannedWorkHours.Value - workHoursCapacityForDay;
                                            weekOvertimeHours.Add((resourceId, currentDate.DayOfWeek, overtimeHours));
                                        }
                                    }
                                    else if (overtimeSchedule.PlannedWorkHours.Value > workHoursCapacityForDay)
                                    {
                                        int overtimeHours = overtimeSchedule.PlannedWorkHours.Value - workHoursCapacityForDay;
                                        weekOvertimeHours.Add((resourceId, currentDate.DayOfWeek, overtimeHours));
                                    }
                                }
                            });
                        }
                    }

                    if (currentDate.DayOfWeek == DayOfWeek.Saturday || currentDate.DayOfWeek == DayOfWeek.Sunday)
                    {
                        if (overtimeScheduleList != null && overtimeScheduleList.Any() && overtimeScheduleList.All(i => i.PlannedWorkHours.HasValue) && defaultResourceWorkPlan != null)
                        {
                            overtimeScheduleList.ForEach((overtimeSchedule) =>
                            {
                                if (overtimeSchedule.PlannedDate.HasValue && overtimeSchedule.PlannedDate.Value.Date == currentDate.Date)
                                {
                                    int overtimeHours = overtimeSchedule.PlannedWorkHours.Value;
                                    weekOvertimeHours.Add((resourceId, currentDate.DayOfWeek, overtimeHours));
                                }
                            });
                        }
                    }
                    currentDate = currentDate.AddDays(1);
                }
            }
            return weekOvertimeHours;
        }

        public List<(Guid ResourceId, DayOfWeek WeekDay, int ActualOvertimeHours)> CalculateAndGetWeekDayActualOvertimeHours(WeekInfo week, List<ResourceSchedule> ResourceScheduleList, List<DefaultResourceWorkPlan> defaultResourceWorkPlanList, List<ResourceCapacity> resourceCapacityList, List<DayOfWeek> dayOfWeekList)
        {
            var weekOvertimeHours = new List<(Guid ResourceId, DayOfWeek WeekDay, int OvertimeHours)>();
            if (ResourceScheduleList != null && ResourceScheduleList.Any())
            {
                DateTime currentDate = week.StartDate;
                var resourceId = ResourceScheduleList.First().ResourceId;
                while (currentDate.Date <= week.EndDate.Date)
                {
                    var defaultResourceWorkPlan = defaultResourceWorkPlanList.Find(x => !string.IsNullOrWhiteSpace(x.WeekDay) && Enum.TryParse<DayOfWeek>(x.WeekDay, out _) && Enum.Parse<DayOfWeek>(x.WeekDay) == currentDate.DayOfWeek);
                    var overtimeScheduleList = ResourceScheduleList.FindAll(x => x.ActualDate.HasValue && x.ActualDate.Value.Date == currentDate.Date)
                        .GroupBy(i => i.ActualDate).Select(x => new ResourceSchedule
                        {
                            PlannedDate = x.First().PlannedDate,
                            ActualDate = x.Key,
                            ActualWorkHours = x.Sum(k => k.ActualWorkHours),
                            PlannedWorkHours = x.Sum(k => k.PlannedWorkHours)
                        }).ToList();

                    var resourceCapacity = resourceCapacityList != null && resourceCapacityList.Any() ? resourceCapacityList.Find(x => x.Day.HasValue && x.Day.Value.Date == currentDate.Date) : null;

                    if (currentDate.DayOfWeek != DayOfWeek.Saturday && currentDate.DayOfWeek != DayOfWeek.Sunday && dayOfWeekList.Contains(currentDate.DayOfWeek))
                    {
                        if (overtimeScheduleList != null && overtimeScheduleList.Any() && overtimeScheduleList.All(i => i.ActualWorkHours.HasValue) && defaultResourceWorkPlan != null)
                        {
                            overtimeScheduleList.ForEach((overtimeSchedule) =>
                            {
                                if (overtimeSchedule.ActualDate.HasValue && overtimeSchedule.ActualDate.Value.Date == currentDate.Date)
                                {
                                    var workHoursCapacityForDay = defaultResourceWorkPlan.WorkHours;

                                    if (resourceCapacity != null && resourceCapacity.AwayHours.HasValue)
                                    {
                                        workHoursCapacityForDay = defaultResourceWorkPlan.WorkHours - resourceCapacity.AwayHours.Value;

                                        if (overtimeSchedule.ActualWorkHours.Value > workHoursCapacityForDay)
                                        {
                                            int overtimeHours = overtimeSchedule.ActualWorkHours.Value - workHoursCapacityForDay;
                                            weekOvertimeHours.Add((resourceId, currentDate.DayOfWeek, overtimeHours));
                                        }
                                    }
                                    else if (overtimeSchedule.ActualWorkHours.Value > workHoursCapacityForDay)
                                    {
                                        int overtimeHours = overtimeSchedule.ActualWorkHours.Value - workHoursCapacityForDay;
                                        weekOvertimeHours.Add((resourceId, currentDate.DayOfWeek, overtimeHours));
                                    }
                                }
                            });

                        }
                    }

                    if (currentDate.DayOfWeek == DayOfWeek.Saturday || currentDate.DayOfWeek == DayOfWeek.Sunday)
                    {
                        if (overtimeScheduleList != null && overtimeScheduleList.Any() && overtimeScheduleList.All(i => i.ActualWorkHours.HasValue) && defaultResourceWorkPlan != null)
                        {
                            overtimeScheduleList.ForEach((overtimeSchedule) =>
                            {
                                if (overtimeSchedule.ActualDate.HasValue && overtimeSchedule.ActualDate.Value.Date == currentDate.Date)
                                {
                                    int overtimeHours = overtimeSchedule.ActualWorkHours.Value;
                                    weekOvertimeHours.Add((resourceId, currentDate.DayOfWeek, overtimeHours));
                                }
                            });

                        }
                    }
                    currentDate = currentDate.AddDays(1);
                }
            }
            return weekOvertimeHours;
        }


        public List<(Guid ResourceId, DayOfWeek WeekDay, int UnavailableHours)> CalculateAndGetWeekDayUnavailableHours(WeekInfo week, List<ResourceCapacity> resourceCapacityList, List<DayOfWeek> dayOfWeekList)
        {
            var weekUnavailableHours = new List<(Guid ResourceId, DayOfWeek WeekDay, int UnavailableHours)>();
            if (resourceCapacityList != null && resourceCapacityList.Any())
            {
                DateTime currentDate = week.StartDate;
                var resourceId = resourceCapacityList.First().ResourceId;
                while (currentDate.Date <= week.EndDate.Date)
                {
                    var resourceCapacity = resourceCapacityList.Find(x => x.Day.HasValue && x.Day.Value.Date == currentDate.Date);

                    if (resourceCapacity != null && resourceCapacity.AwayHours.HasValue)
                    {
                        weekUnavailableHours.Add((resourceId, currentDate.DayOfWeek, resourceCapacity.AwayHours.Value));
                    }

                    currentDate = currentDate.AddDays(1);
                }
            }
            return weekUnavailableHours;
        }
    }
}
