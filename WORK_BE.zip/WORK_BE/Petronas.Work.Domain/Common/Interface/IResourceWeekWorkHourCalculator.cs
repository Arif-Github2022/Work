﻿using Petronas.Work.Core.Model;
using Petronas.Work.Data.Entities.dbo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Domain.Common.Interface
{
    public interface IResourceWeekWorkHourCalculator
    {
        public int CalculateAndGetAvailableHours(WeekInfo week, List<DefaultResourceWorkPlan> defaultResourceWorkPlanList);

        public int CalculateAndGetPlannedHours(WeekInfo week, List<ResourceSchedule> ResourceScheduleList, List<DefaultResourceWorkPlan> defaultResourceWorkPlanList);

        public int CalculateAndGetActualHours(WeekInfo week, List<ResourceSchedule> ResourceScheduleList, List<DefaultResourceWorkPlan> defaultResourceWorkPlanList);

        public int CalculateAndGetPlannedOvertimeHours(WeekInfo week, List<ResourceSchedule> ResourceScheduleList, List<DefaultResourceWorkPlan> defaultResourceWorkPlanList, List<ResourceCapacity> resourceCapacityList);

        public int CalculateAndGetActualOvertimeHours(WeekInfo week, List<ResourceSchedule> ResourceScheduleList, List<DefaultResourceWorkPlan> defaultResourceWorkPlanList, List<ResourceCapacity> resourceCapacityList);

        public int CalculateAndGetUnavailableHours(WeekInfo week, List<ResourceCapacity> resourceCapacityList);

        public List<(Guid ResourceId, DayOfWeek WeekDay, int AvailableHours)> CalculateAndGetWeekDayAvailableHours(WeekInfo week, List<DefaultResourceWorkPlan> defaultResourceWorkPlanList, List<DayOfWeek> dayOfWeekList);
        
        public List<(Guid ResourceId, DayOfWeek WeekDay, int PlannedHours)> CalculateAndGetWeekDayPlannedHours(WeekInfo week, List<ResourceSchedule> ResourceScheduleList, List<DefaultResourceWorkPlan> defaultResourceWorkPlanList, List<DayOfWeek> dayOfWeekList);

        public List<(Guid ResourceId, DayOfWeek WeekDay, int ActualHours)> CalculateAndGetWeekDayActualHours(WeekInfo week, List<ResourceSchedule> ResourceScheduleList, List<DefaultResourceWorkPlan> defaultResourceWorkPlanList, List<DayOfWeek> dayOfWeekList);

        public List<(Guid ResourceId, DayOfWeek WeekDay, int PlannedOvertimeHours)> CalculateAndGetWeekDayPlannedOvertimeHours(WeekInfo week, List<ResourceSchedule> ResourceScheduleList, List<DefaultResourceWorkPlan> defaultResourceWorkPlanList, List<ResourceCapacity> resourceCapacityList, List<DayOfWeek> dayOfWeekList);

        public List<(Guid ResourceId, DayOfWeek WeekDay, int ActualOvertimeHours)> CalculateAndGetWeekDayActualOvertimeHours(WeekInfo week, List<ResourceSchedule> ResourceScheduleList, List<DefaultResourceWorkPlan> defaultResourceWorkPlanList, List<ResourceCapacity> resourceCapacityList, List<DayOfWeek> dayOfWeekList);

        public List<(Guid ResourceId, DayOfWeek WeekDay, int UnavailableHours)> CalculateAndGetWeekDayUnavailableHours(WeekInfo week, List<ResourceCapacity> resourceCapacityList, List<DayOfWeek> dayOfWeekList);
    }
}
