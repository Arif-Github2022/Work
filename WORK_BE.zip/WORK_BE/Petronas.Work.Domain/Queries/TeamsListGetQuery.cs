﻿using MediatR;
using Petronas.Work.Domain.Models;

namespace Petronas.Work.Domain.Queries
{
    public class TeamsListGetQuery : IRequest<List<TeamsListQueryResult>>
    {
        public int Id { get; set; }

        public string? Name { get; set; }

        public string? Description { get; set; }

    }

    //public class RoleListGetQuery : IRequest<List<RoleListGetQueryResult>>
    //{
    //    public int Id { get; set; }

    //    public string? Name { get; set; }

    //    public string? Description { get; set; }

    //}
}
