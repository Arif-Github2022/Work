﻿using MediatR;
using Petronas.Work.Domain.Models;

namespace Petronas.Work.Domain.Queries
{
    public class ResourceScheduleGetWeeklyPlanChartQuery: IRequest<ResourceScheduleGetWeeklyPlanChartQueryResult>
    {
        public Guid TeamId { get; set; }

        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }
    }
}
