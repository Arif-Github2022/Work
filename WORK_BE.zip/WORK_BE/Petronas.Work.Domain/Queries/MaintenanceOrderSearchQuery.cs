﻿using MediatR;
using Petronas.Work.Core.Enumerations;
using Petronas.Work.Domain.Models;

namespace Petronas.Work.Domain.Queries
{
    public class MaintenanceOrderSearchQuery : IRequest<MaintenanceOrderSearchResult>
    {
        public string? OrderNumber { get; set; }

        public string? OrderDescription { get; set; }

        public List<string>? WorkCenters { get; set; }

        public string? FunctionalLocation { get; set; }

        public List<string>? UserStatuses { get; set; }

        public List<string>? SystemStatuses { get; set; }

        public List<string> OrderTypes { get; set; }

        public List<string> Priorities { get; set; }

        public Guid TeamId { get; set; }

        public int Page { get; set; }

        public int PageSize { get; set; }
    }
}
