﻿using MediatR;
using Petronas.Work.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Domain.Queries
{
    public class ManageTeamGetDefaultTeamQuery : IRequest<List<ManageTeamGetDefaultTeamQueryResult>>
    {
        public Guid TeamId { get; set; }
    }
}
