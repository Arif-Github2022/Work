﻿using MediatR;
using Petronas.Work.Domain.Models;
namespace Petronas.Work.Domain.Queries
{
    public class GetTeamResourcesQuery:IRequest<List<GetTeamResourcesQueryResult>>
    {
        public Guid TeamId { get; set; }
    }
}
