﻿using MediatR;
using Petronas.Work.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Domain.Queries
{
    public class GetExternalTeamResourcesQuery : IRequest<List<GetTeamResourcesQueryResult>>
    {
        public string Name { get; set; }
    }
}
