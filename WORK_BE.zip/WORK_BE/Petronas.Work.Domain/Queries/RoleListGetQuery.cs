﻿using MediatR;
using Petronas.Work.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Domain.Queries
{
   
    public class RoleListGetQuery : IRequest<List<RoleListGetQuery>>
    {
        public int Id { get; set; }

        public string? Name { get; set; }

        public string? Description { get; set; }

    }
}
