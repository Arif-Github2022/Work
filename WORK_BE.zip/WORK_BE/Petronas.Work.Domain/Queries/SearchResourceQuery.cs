﻿using MediatR;
using Petronas.Work.Domain.Models;

namespace Petronas.Work.Domain.Queries
{
    public class SearchResourceQuery : IRequest<SearchResourceResult>
    {
        public string? Name { get; set; }
    }
}
