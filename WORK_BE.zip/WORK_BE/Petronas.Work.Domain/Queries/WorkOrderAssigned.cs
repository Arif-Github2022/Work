﻿using MediatR;
using Petronas.Work.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Domain.Queries;
 public class WorkOrderAssigned : IRequest<List<WorkOrderAssigned>>
{
    public int Id { get; set; }

    public string? OrderNumber { get; set; }

    public string? OrderDescription { get; set; }

    public string? ActualStartDate { get; set; }

    public string? ActualFinishDate { get; set; }
    public string? IsActive { get; set; }

}
