﻿using MediatR;
using Petronas.Work.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Domain.Queries
{
    public class GetWeekNonWorkHoursQuery : IRequest<List<GetWeekNonWorkHoursQueryResult>>
    {
        public Guid TeamID { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
}
