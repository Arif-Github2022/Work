﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Petronas.Work.Data.Infrastructure.Interface;
using Petronas.Work.Domain.Commands;
using Petronas.Work.Domain.Models;

namespace Petronas.Work.Domain.Handlers.CommadHandlers
{
    public class UpdateScheduleCommandHandler : BaseHandler, IRequestHandler<UpdateScheduleCommand, DefaultResponseResult>
    {
        private readonly IMapper _mapper;
        private readonly ILogger<UpdateScheduleCommandHandler> _logger;

        public UpdateScheduleCommandHandler(IWorkDbUnitOfWork unitOfWork, IMapper mapper, ILogger<UpdateScheduleCommandHandler> logger) : base(unitOfWork)
        {
            _mapper = mapper;
            _logger = logger;
        }

        public async Task<DefaultResponseResult>? Handle(UpdateScheduleCommand request, CancellationToken cancellationToken)
        {
            dynamic response;
            _logger.LogInformation($"Handler Call : {nameof(UpdateScheduleCommandHandler)}");

            var item = await UnitOfWork.OrderScheduleRepository.GetQuery().Where(_ =>_.WorkOrderId == request.WorkOrderId).FirstOrDefaultAsync();
            if (item == null)
            {
                throw new ArgumentException("The Schedule is not valid!");
            }
            item.ScheduleStartDate = request.ScheduleStartDate;
            item.ScheduleEndDate = request.ScheduleEndDate;
            item.RecordUpdatedOn = DateTime.Now;
            
            UnitOfWork.OrderScheduleRepository.Update(item);
            await UnitOfWork.SaveChangesAsync();
            var respone = new DefaultResponseResult
            {
                IsError = false,
                Message = "OrderSchedule Updated",
                TraceId = request.TraceID
            };
            _logger.LogInformation($"Handler Call : {nameof(CreatreScheduleCommandHandler)} Completed");
            return respone;
        }
    }
}
