﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Petronas.Work.Data.Entities.dbo;
using Petronas.Work.Data.Infrastructure.Interface;
using Petronas.Work.Domain.Commands;
using Petronas.Work.Domain.Models;

namespace Petronas.Work.Domain.Handlers.CommadHandlers
{
    internal class CreateResourceCommandHandler : BaseHandler, IRequestHandler<CreateResourceCommand, DefaultResponseResult>
    {
        private readonly ILogger<CreateResourceCommandHandler> _logger;

        public CreateResourceCommandHandler(ILogger<CreateResourceCommandHandler> logger, IWorkDbUnitOfWork unitOfWork) : base(unitOfWork)
        {
            _logger = logger;
        }

        public async Task<DefaultResponseResult> Handle(CreateResourceCommand request, CancellationToken cancellationToken)
        {
            _logger.LogInformation($"Handler Call : {nameof(CreateResourceCommandHandler)}");

            if (request == null || request.ResourceInformation == null || !request.ResourceInformation.Any())
            {
                throw new ArgumentException("Request cannot be null or empty.");
            }

            var roleTechnician = await UnitOfWork.RoleRepository.GetQuery()
               .Where(x => x.Name != null && x.Name.ToLower().Equals(Core.Constants.Role.Technician)).FirstOrDefaultAsync();

            var teamId = request.TeamId;
            var requestResourcesIds = request.ResourceInformation.Select(x => x.ResourceId).Distinct().ToList();

            var resourceIdsinDb = UnitOfWork.ResourceRepository.GetQuery()
                .Include(nameof(ResourceRole))
                .AsEnumerable()
                .Where(t => t.ResourceRole.Any(r => r.RoleId == roleTechnician.Id) && t.IsActive == true)
                .Select(x => x.Id).ToList();

            // to identify new resource
            var nonExistingResources = request.ResourceInformation.FindAll(x => !resourceIdsinDb.Any(i => i == x.ResourceId));

            if (nonExistingResources != null && nonExistingResources.Any())
            {
                var resources = CreateResources(nonExistingResources);

                CreateDefaultResourceWorkPlan(resources);

                CreateResourceRole(resources);

                if (!string.IsNullOrWhiteSpace(teamId) && Guid.TryParse(teamId, out _))
                {
                    AddTeamMembers(nonExistingResources, Guid.Parse(teamId));
                }
            }

            if (!string.IsNullOrWhiteSpace(teamId) && Guid.TryParse(teamId, out _))
            {
                // Absolute new team memebers
                var allTeamResourceIds = UnitOfWork.ResourceTeamRepository.GetQuery()
               .Select(i => i.ResourceId).ToList();

                var resoucesInRequestAndDbButNotInAnyTeam = request.ResourceInformation
                    .FindAll(x => resourceIdsinDb.Any(i => i == x.ResourceId) && !allTeamResourceIds.Any(r => r == x.ResourceId));

                AddTeamMembers(resoucesInRequestAndDbButNotInAnyTeam, Guid.Parse(teamId));

                // to identify existing team member 
                var inActive_existingTeamMember = UnitOfWork.ResourceTeamRepository.GetQuery()
                    .Include(nameof(Resource))
                    .Include($"{nameof(Resource)}.{nameof(ResourceRole)}")
                    .AsEnumerable()
                    .Where(a => a.TeamId == Guid.Parse(teamId) &&
                                a.Resource.ResourceRole.Any(r => r.RoleId == roleTechnician.Id) &&
                                requestResourcesIds.Any(b => b == a.ResourceId) && a.IsActive == false).ToList();

                // to identify remove resource
                var removeTeamMembers = UnitOfWork.ResourceTeamRepository.GetQuery()
                    .Include(nameof(Resource))
                    .Include($"{nameof(Resource)}.{nameof(ResourceRole)}")
                    .AsEnumerable()
                    .Where(a => a.TeamId == Guid.Parse(teamId) &&
                                a.Resource.ResourceRole.Any(r => r.RoleId == roleTechnician.Id) &&
                                !requestResourcesIds.Any(b => b == a.ResourceId) && a.IsActive == true).ToList();

                //to identify additional team member
                var addnewTeamMembers = UnitOfWork.ResourceTeamRepository.GetQuery()
                    .Include(nameof(Resource))
                    .Include($"{nameof(Resource)}.{nameof(ResourceRole)}")
                    .AsEnumerable()
                    .Where(a => a.TeamId != Guid.Parse(teamId) &&
                                a.Resource.ResourceRole.Any(r => r.RoleId == roleTechnician.Id) &&
                                requestResourcesIds.Any(b => b == a.ResourceId) && a.IsActive == true).ToList();

                var active_existingTeamMembers = UnitOfWork.ResourceTeamRepository.GetQuery()
                    .Include(nameof(Resource))
                    .Include($"{nameof(Resource)}.{nameof(ResourceRole)}")
                    .AsEnumerable()
                    .Where(a => a.TeamId == Guid.Parse(teamId) &&
                                a.Resource.ResourceRole.Any(r => r.RoleId == roleTechnician.Id) &&
                                requestResourcesIds.Any(b => b == a.ResourceId) &&
                                a.IsActive == true
                          ).ToList();

                foreach (var teamMember in active_existingTeamMembers)
                {
                    if (addnewTeamMembers != null && addnewTeamMembers.Any())
                        addnewTeamMembers.RemoveAll(a => a.ResourceId == teamMember.ResourceId);
                }

                // update resource team           
                UpdateTeamMembers(inActive_existingTeamMember);

                // add new resource to team
                if (addnewTeamMembers != null && addnewTeamMembers.Any())
                {
                    var addNewTeamMember = addnewTeamMembers.FindAll(x => resourceIdsinDb.Any(i => i == x.ResourceId));

                    var resourceInformationList = addNewTeamMember.Select(i => new ResourceInformation
                    {
                        ResourceId = i.ResourceId
                    }).ToList();

                    AddTeamMembers(resourceInformationList, Guid.Parse(teamId));
                }

                // remove resources
                RemoveTeamMembers(removeTeamMembers);
            }

            await UnitOfWork.SaveChangesAsync();
            _logger.LogInformation($"Handler Call : {nameof(CreateResourceCommandHandler)} Completed");

            return new DefaultResponseResult
            {
                IsError = false,
                Message = "Manage Team Members Updated Successfully",
                TraceId = TraceId
            };
        }

        public List<Data.Entities.dbo.Resource> CreateResources(List<ResourceInformation> nonExistingResources)
        {
            List<Data.Entities.dbo.Resource> resources = new();

            if (nonExistingResources != null && nonExistingResources.Any())
            {
                resources = nonExistingResources.Select(x => new Data.Entities.dbo.Resource
                {
                    Id = x.ResourceId == Guid.Empty ? Guid.NewGuid() : x.ResourceId,
                    Name = x.ResourceName,
                    Company = x.ResourceCompany,
                    AceId = x.ResourceAceId.ToString(),
                    IsContractor = x.IsResourceContractor,
                    RecordCreatedById = Guid.Empty,
                    RecordCreatedOn = DateTime.Now,
                    RecordUpdatedById = Guid.Empty,
                    IsActive = true,
                    IsDeleted = false
                }).ToList();

                UnitOfWork.ResourceRepository.AddRange(resources);
            }

            return resources;
        }

        public void CreateDefaultResourceWorkPlan(List<Data.Entities.dbo.Resource> resources)
        {
            if (resources != null && resources.Any())
            {
                var dayOfWeekList = Enumerable.Range(0, Enum.GetNames(typeof(DayOfWeek)).Length)
                    .Select(i => (DayOfWeek)i)
                    .OrderBy(x => ((int)x + 6) % 7)
                    .ToList();

                List<DefaultResourceWorkPlan> defaultResourceWorkPlans = new();

                dayOfWeekList.ForEach((dayOfWeek) =>
                {
                    var defaultResourceWorkPlan = resources.Select(x => new Data.Entities.dbo.DefaultResourceWorkPlan
                    {
                        Id = Guid.NewGuid(),
                        ResourceId = x.Id,
                        WeekDay = Enum.GetName(dayOfWeek),
                        WorkHours = (dayOfWeek == DayOfWeek.Saturday || dayOfWeek == DayOfWeek.Sunday) ? 0 : (dayOfWeek == DayOfWeek.Friday) ? 7 : 8,
                        RecordCreatedById = Guid.Empty,
                        RecordCreatedOn = DateTime.Now,
                        RecordUpdatedById = Guid.Empty,
                        IsActive = true,
                        IsDeleted = false
                    }).ToList();

                    defaultResourceWorkPlans.AddRange(defaultResourceWorkPlan);
                });

                UnitOfWork.DefaultResourceWorkPlanRepository.AddRange(defaultResourceWorkPlans);
            }
        }

        public void CreateResourceRole(List<Data.Entities.dbo.Resource> resources)
        {
            if (resources != null && resources.Any())
            {
                var roleTechnician = UnitOfWork.RoleRepository.GetQuery()
                    .FirstOrDefault(x => x.Name != null && x.Name.ToLower().Equals(Core.Constants.Role.Technician));

                var resourceRoles = resources.Select(x => new ResourceRole
                {
                    Id = Guid.NewGuid(),
                    ResourceId = x.Id,
                    RoleId = roleTechnician.Id,
                    RecordCreatedById = Guid.Empty,
                    RecordCreatedOn = DateTime.Now,
                    RecordUpdatedById = Guid.Empty,
                    IsActive = true,
                    IsDeleted = false
                }).ToList();

                UnitOfWork.ResourceRoleRepository.AddRange(resourceRoles);
            }
        }

        public void AddTeamMembers(List<ResourceInformation> nonExistingTeamMembers, Guid teamId)
        {
            if (nonExistingTeamMembers != null && nonExistingTeamMembers.Any())
            {
                var resourcesTeam = nonExistingTeamMembers.Select(x => new ResourceTeam
                {
                    Id = x.ResourceId == Guid.Empty ? Guid.NewGuid() : x.ResourceId,
                    ResourceId = x.ResourceId,
                    TeamId = teamId,
                    RecordCreatedById = Guid.Empty,
                    RecordCreatedOn = DateTime.Now,
                    RecordUpdatedById = Guid.Empty,
                    IsActive = true,
                    IsDeleted = false
                }).ToList();

                UnitOfWork.ResourceTeamRepository.AddRange(resourcesTeam);
            }
        }

        public void UpdateTeamMembers(List<ResourceTeam> teamMembers)
        {
            if (teamMembers != null && teamMembers.Any())
            {
                teamMembers.ForEach((item) =>
                {
                    item.IsActive = true;
                    item.RecordUpdatedOn = DateTime.Now;
                });
                UnitOfWork.ResourceTeamRepository.UpdateRange(teamMembers);
            }
        }

        public void RemoveTeamMembers(List<Data.Entities.dbo.ResourceTeam> removeTeamMember)
        {
            if (removeTeamMember != null && removeTeamMember.Any())
            {
                if (removeTeamMember.Any())
                {
                    removeTeamMember.ForEach((item) =>
                    {
                        item.IsActive = false;
                        item.RecordUpdatedOn = DateTime.Now;
                    });
                    UnitOfWork.ResourceTeamRepository.UpdateRange(removeTeamMember);
                }
            }
        }
    }
}
