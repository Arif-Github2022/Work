﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using Petronas.Work.Data.Entities.dbo;
using Petronas.Work.Data.Infrastructure.Interface;
using Petronas.Work.Domain.Commands;
using Petronas.Work.Domain.Models;

namespace Petronas.Work.Domain.Handlers.CommadHandlers
{
    public class UpdateWeekNonWorkHoursCommandHandler : BaseHandler, IRequestHandler<UpdateWeekNonWorkHoursCommand, DefaultResponseResult>
    {
        private readonly IMapper _mapper;
        private readonly ILogger<UpdateWeekNonWorkHoursCommandHandler> _logger;

        public UpdateWeekNonWorkHoursCommandHandler(IWorkDbUnitOfWork unitOfWork, IMapper mapper, ILogger<UpdateWeekNonWorkHoursCommandHandler> logger) : base(unitOfWork)
        {
            _mapper = mapper;
            _logger = logger;
        }

        public async Task<DefaultResponseResult> Handle(UpdateWeekNonWorkHoursCommand requestList, CancellationToken cancellationToken)
        {
            _logger.LogInformation($"Handler Call : {nameof(UpdateWeekNonWorkHoursCommandHandler)} Started");

            List<ResourceCapacity> resourceCapacityToUpdate = new();
            List<ResourceCapacity> resourceCapacityToAdd = new();

            requestList.ResourceNonWorkHours.ForEach((request) =>
            {
                DateTime currentDate = requestList.StartDate;
                while (currentDate <= requestList.EndDate)
                {
                    var weekNonWorkHours = UnitOfWork.ResourceCapacityRepository.GetQuery()
                        .Where(t => t.ResourceId == request.Id && t.Day == currentDate)
                          .ToList();
                    var defaultWorkHours = UnitOfWork.DefaultResourceWorkPlanRepository.GetQuery()
                        .Where(t => t.ResourceId == request.Id && t.WeekDay == currentDate.DayOfWeek.ToString())
                          .ToList();

                    if (weekNonWorkHours != null&& weekNonWorkHours.Any())
                    {
                        weekNonWorkHours.ForEach(t =>
                        {
                            var awayHoursUpdate = request.WeekDayNonWorkHours.Find(x => x.WeekDay == currentDate.DayOfWeek.ToString());
                            var defaultWorkHrs = defaultWorkHours.Select(x => x.WorkHours).FirstOrDefault();
                            if (awayHoursUpdate != null && defaultWorkHrs != null)
                            {
                                var awayHrs = awayHoursUpdate.AwayHours > defaultWorkHrs ? defaultWorkHrs : awayHoursUpdate.AwayHours;
                                var workHrs = defaultWorkHrs - awayHoursUpdate.AwayHours < 0 ? 0 : defaultWorkHrs - awayHoursUpdate.AwayHours;

                                t.AwayHours = awayHrs;
                                t.WorkHours = workHrs;
                                t.RecordUpdatedById = Guid.Empty;
                                t.RecordUpdatedOn = DateTime.Now;
                            }
                            resourceCapacityToUpdate.Add(t);
                        });
                    }
                    else
                    {
                        var awayHrsUpdate = request.WeekDayNonWorkHours.Find(x => x.WeekDay == currentDate.DayOfWeek.ToString());
                        var defaultWorkHrs = defaultWorkHours.Select(x => x.WorkHours).FirstOrDefault();

                        if (awayHrsUpdate != null && defaultWorkHrs != null)
                        {
                            var awayHrs = awayHrsUpdate.AwayHours > defaultWorkHrs ? defaultWorkHrs : awayHrsUpdate.AwayHours;
                            var workHrs = defaultWorkHrs - awayHrsUpdate.AwayHours < 0 ? 0 : defaultWorkHrs - awayHrsUpdate.AwayHours;

                            var resourceCapacity = new ResourceCapacity
                            {
                                Id = Guid.NewGuid(),
                                Day = currentDate,
                                AwayHours = awayHrs,
                                IsActive = true,
                                IsDeleted = false,
                                ResourceId = request.Id,
                                WorkHours = workHrs,
                                RecordCreatedById = Guid.Empty,
                                RecordCreatedOn = currentDate,
                                RecordUpdatedById = Guid.Empty,
                                RecordUpdatedOn = currentDate
                            };
                            resourceCapacityToAdd.Add(resourceCapacity);
                        }
                    }
                    currentDate = currentDate.AddDays(1);
                }
            });

            if (resourceCapacityToUpdate != null && resourceCapacityToUpdate.Any())
            {
                UnitOfWork.ResourceCapacityRepository.UpdateRange(resourceCapacityToUpdate);
            }

            if (resourceCapacityToAdd != null && resourceCapacityToAdd.Any())
            {
                UnitOfWork.ResourceCapacityRepository.AddRange(resourceCapacityToAdd);
            }

            await UnitOfWork.SaveChangesAsync();
            var response = new DefaultResponseResult
            {
                IsError = false,
                Message = "Resource NonWork Hours Updated",
                TraceId = requestList.TraceId
            };
            _logger.LogInformation($"Handler Call : {nameof(UpdateWeekNonWorkHoursCommandHandler)} Completed");

            return response;
        }
    }
}
