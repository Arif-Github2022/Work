﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using Petronas.Work.Data.Infrastructure.Interface;
using Petronas.Work.Domain.Commands;
using Petronas.Work.Domain.Models;

namespace Petronas.Work.Domain.Handlers.CommadHandlers
{
    public class CreateUpdateResourceScheduleCommandHandler : BaseHandler, IRequestHandler<CreateUpdateResourceScheduleCommand, DefaultResponseResult>
    {
        private readonly IMapper _mapper;
        private readonly IMediator _mediator;
        private readonly ILogger<CreateUpdateResourceScheduleCommandHandler> _logger;

        public CreateUpdateResourceScheduleCommandHandler(IWorkDbUnitOfWork unitOfWork, IMapper mapper, IMediator mediator, ILogger<CreateUpdateResourceScheduleCommandHandler> logger) : base(unitOfWork)
        {
            _mapper = mapper;
            _logger = logger;
            _mediator = mediator;
        }

        public async Task<DefaultResponseResult> Handle(CreateUpdateResourceScheduleCommand requestList, CancellationToken cancellationToken)
        {
            _logger.LogInformation($"Handler Call : {nameof(CreateUpdateResourceScheduleCommandHandler)}");

            try
            {
                if (requestList.ResourceSchedule.Any(i => i.PlannedWorkHours == null || i.PlannedDate <= DateTime.MinValue))
                {
                    throw new ArgumentException("Invalid date in request.");
                }

                var requestWorkOrderIds = requestList.ResourceSchedule.Select(x => x.WorkOrderId).Distinct().ToList();

                var isWorkOrdersExistInDb = UnitOfWork.WorkOrderRepository.GetQuery().AsEnumerable()
                    .Any(i => requestWorkOrderIds.Contains(i.Id));

                if (!isWorkOrdersExistInDb)
                {
                    throw new ArgumentException("Invalid work order Ids in request.");
                }

                var requestResourceIds = requestList.ResourceSchedule.Select(x => x.ResourceId).Distinct().ToList();

                var existingResouceIds = UnitOfWork.ResourceRepository.GetQuery().AsEnumerable()
                    .Where(x => requestResourceIds.Contains(x.Id))
                    .Select(x => x.Id).ToList();


                var distinctResourceScheduleList = requestList.ResourceSchedule
                        .GroupBy(i => i.ResourceId, (key, list) => list.OrderBy(x => x.ResourceName).First())
                        .Select(g => g).ToList();

                var nonExistingResouces = distinctResourceScheduleList.FindAll(x => !existingResouceIds.Any(i => i == x.ResourceId));

                if (nonExistingResouces != null && nonExistingResouces.Any())
                {
                    // Create new resources
                    var resourceInformationList = nonExistingResouces.Select(x => new ResourceInformation
                    {
                        ResourceId = x.ResourceId,
                        ResourceName = x.ResourceName,
                        ResourceCompany = x.ResourceCompany,
                        ResourceAceId = string.IsNullOrWhiteSpace(x.ResourceAceId) ? Guid.Empty : Guid.Parse(x.ResourceAceId),
                        IsResourceContractor = x.IsResourceContractor
                    }).ToList();

                    CreateResourceCommand createResourceCommand = new()
                    {
                        ResourceInformation = new List<ResourceInformation>(resourceInformationList)
                    };

                    var createResourceResponse = await _mediator.Send(createResourceCommand);
                }

                var existingResourceScheduleList = UnitOfWork.ResourceScheduleRepository
                    .GetQuery()
                    .AsEnumerable()
                    .Where(x => requestList.ResourceSchedule.Any(i => i.WorkOrderId == x.WorkOrderId)
                            && requestList.ResourceSchedule.Any(i => i.PlannedDate == x.PlannedDate)
                            && requestList.ResourceSchedule.Any(i => i.ResourceId == x.ResourceId)
                            ).ToList();


                var existingInDb = requestList.ResourceSchedule.FindAll(i => existingResourceScheduleList
                                    .Any(x => i.WorkOrderId == x.WorkOrderId && i.PlannedDate == x.PlannedDate && i.ResourceId == x.ResourceId)
                                    ).ToList();

                var nonExistingResourceScheduleList = requestList.ResourceSchedule
                            .FindAll(i => !existingInDb
                                    .Any(x => i.WorkOrderId == x.WorkOrderId && i.PlannedDate == x.PlannedDate && i.ResourceId == x.ResourceId)
                                    ).ToList();

                if (nonExistingResourceScheduleList != null && nonExistingResourceScheduleList.Any())
                {
                    AddResourceSchedule(nonExistingResourceScheduleList);
                }

                if (existingResourceScheduleList != null && existingResourceScheduleList.Any())
                {
                    UpdateResource(existingResourceScheduleList, requestList.ResourceSchedule);
                }

                await UnitOfWork.SaveChangesAsync();

                var response = new DefaultResponseResult
                {
                    IsError = false,
                    Message = "Resource Schedule Created/Updated",
                    TraceId = requestList.TraceID
                };
                _logger.LogInformation($"Handler Call : {nameof(CreateUpdateResourceScheduleCommandHandler)} Completed");

                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.ToString());
                throw;
            }
        }

        private void AddResourceSchedule(List<ResourceScheduleDetails> nonExistingresourceScheduleList)
        {
            var newScheduleList = nonExistingresourceScheduleList.Select(x => new Data.Entities.dbo.ResourceSchedule
            {
                Id = x.Id == Guid.Empty ? Guid.NewGuid() : x.Id,
                WorkOrderId = x.WorkOrderId,
                ResourceId = x.ResourceId,
                PlannedDate = x.PlannedDate,
                PlannedWorkHours = x.PlannedWorkHours,
                RecordCreatedOn = DateTime.Now,
                RecordCreatedById = Guid.Empty,
                RecordUpdatedOn = DateTime.Now,
                RecordUpdatedById = Guid.Empty,
                IsDeleted = false,
                IsActive = true
            }).ToList();

            if (!newScheduleList.Any())
            {
                throw new Exception("Unable to create New Resource Schedule.");
            }

            UnitOfWork.ResourceScheduleRepository.AddRange(newScheduleList);
        }

        private void UpdateResource(List<Data.Entities.dbo.ResourceSchedule> existingResourceScheduleList, List<ResourceScheduleDetails> resourceSchedule)
        {
            List<Data.Entities.dbo.ResourceSchedule> resourceSchedulesToUpdate = new();

            foreach (var resourceScheduleItem in resourceSchedule)
            {
                var resourceScheduleToUpdate = existingResourceScheduleList.Find(i => i.PlannedDate == resourceScheduleItem.PlannedDate
                                                                            && i.ResourceId == resourceScheduleItem.ResourceId
                                                                            && i.WorkOrderId == resourceScheduleItem.WorkOrderId
                                                                            );
                if (resourceScheduleToUpdate != null)
                {
                    resourceScheduleToUpdate.PlannedWorkHours = resourceScheduleItem.PlannedWorkHours;
                    resourceSchedulesToUpdate.Add(resourceScheduleToUpdate);
                }
            }

            UnitOfWork.ResourceScheduleRepository.UpdateRange(resourceSchedulesToUpdate);
        }
    }
}
