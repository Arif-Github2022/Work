﻿using AutoMapper;
using Azure.Core;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.VisualBasic;
using Petronas.Work.Data.Entities.dbo;
using Petronas.Work.Data.Infrastructure.Interface;
using Petronas.Work.Domain.Commands;
using Petronas.Work.Domain.Models;
using Petronas.Work.Domain.Queries;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Domain.Handlers.CommadHandlers
{
    public class UpdateTeamDefaultHoursQueryHandler : BaseHandler, IRequestHandler<UpdateTeamDefaultHoursCommand, DefaultResponseResult>
    {
        private readonly IMapper _mapper;
        private readonly ILogger<UpdateTeamDefaultHoursQueryHandler> _logger;

        public UpdateTeamDefaultHoursQueryHandler(IWorkDbUnitOfWork unitOfWork, IMapper mapper, ILogger<UpdateTeamDefaultHoursQueryHandler> logger) : base(unitOfWork)
        {
            _mapper = mapper;
            _logger = logger;
        }

        public async Task<DefaultResponseResult> Handle(UpdateTeamDefaultHoursCommand requestList, CancellationToken cancellationToken)
        {
            requestList.ResourceDefaultWorkHours.ForEach((request) =>
                {
                    var defaultScheduleList = UnitOfWork.DefaultResourceWorkPlanRepository.GetQuery()
                      .Where(t => t.ResourceId == request.Id)
                      .ToList();
                    if (defaultScheduleList != null)
                    {
                        var updateValue = new DefaultResourceWorkPlan();
                        defaultScheduleList.ForEach(t =>
                        {
                            var workHoursupdate = request.WeekDayDefaultWorkHours.Find(x => x.WeekDay == t.WeekDay);

                            if (workHoursupdate != null)
                            {
                                t.WorkHours = workHoursupdate.WorkHours;
                            }
                            UnitOfWork.DefaultResourceWorkPlanRepository.Update(t);
                        });

                    }
                });
            await UnitOfWork.SaveChangesAsync();
            var response = new DefaultResponseResult
            {
                IsError = false,
                Message = "Default Resource Schedule Updated",
                TraceId = requestList.TraceId
            };
            _logger.LogInformation($"Handler Call : {nameof(CreateUpdateResourceScheduleCommandHandler)} Completed");

            return response;

        }
    }
}

