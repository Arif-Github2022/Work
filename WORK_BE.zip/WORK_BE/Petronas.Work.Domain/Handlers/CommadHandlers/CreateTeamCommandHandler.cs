﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using Petronas.Work.Data.Infrastructure.Interface;
using Petronas.Work.Domain.Commands;
using Petronas.Work.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Domain.Handlers.CommadHandlers
{
    public class CreateTeamCommandHandler : BaseHandler, IRequestHandler<CreateTeamCommand, DefaultResponseResult>
    {
        private readonly IMapper _mapper;
        private readonly ILogger<CreateTeamCommandHandler> _logger;

        public CreateTeamCommandHandler(IWorkDbUnitOfWork unitOfWork, IMapper mapper, ILogger<CreateTeamCommandHandler> logger) : base(unitOfWork)
        {
            _mapper = mapper;
            _logger = logger;
        }

        public async Task<DefaultResponseResult>? Handle(CreateTeamCommand request, CancellationToken cancellationToken)
        {
            dynamic response;
            _logger.LogInformation($"Handler Call : {nameof(CreateTeamCommandHandler)}");

            if (request.Id == Guid.Empty)
            {
                request.Id = Guid.NewGuid();
            }
            try
            {
                var item = new Data.Entities.dbo.Team
                {
                    Id = request.Id,
                    Name = request.Name,
                    Description = request.Description,
                    RecordCreatedOn = DateTime.Now,
                    RecordCreatedById = Guid.Empty,
                    RecordUpdatedOn = DateTime.Now,
                    RecordUpdatedById = Guid.Empty,
                    IsDeleted = false,
                    IsActive = true
                };
                UnitOfWork.TeamRepository.Add(item);
                await UnitOfWork.SaveChangesAsync();
            }
            catch (Exception ex)
            {

                _logger.LogError(ex.ToString());

            }


            var respone = new DefaultResponseResult
            {
                IsError = false,
                Message = "Team Created",
                TraceId = request.TraceID
            };
            _logger.LogInformation($"Handler Call : {nameof(CreateTeamCommandHandler)} Completed");
            return respone;
        }
    }
}
