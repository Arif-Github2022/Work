﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using Petronas.Work.Data.Entities.dbo;
using Petronas.Work.Data.Infrastructure.Interface;
using Petronas.Work.Domain.Commands;
using Petronas.Work.Domain.Models;

namespace Petronas.Work.Domain.Handlers.CommadHandlers
{
    public class CreatreScheduleCommandHandler : BaseHandler, IRequestHandler<CreateScheduleCommand, DefaultResponseResult>
    {
        private readonly IMapper _mapper;
        private readonly ILogger<CreatreScheduleCommandHandler> _logger;

        public CreatreScheduleCommandHandler(IWorkDbUnitOfWork unitOfWork, IMapper mapper, ILogger<CreatreScheduleCommandHandler> logger) : base(unitOfWork)
        {
            _mapper = mapper;
            _logger = logger;
        }

        public async Task<DefaultResponseResult>? Handle(CreateScheduleCommand request, CancellationToken cancellationToken)
        {
            dynamic response;
            _logger.LogInformation($"Handler Call : {nameof(CreatreScheduleCommandHandler)}");

            if (request.Id == Guid.Empty)
            {
                request.Id = Guid.NewGuid();
            }
            var item = new OrderSchedule
            {
                Id = request.Id,
                WorkOrderId = request.WorkOrderId,
                ScheduleStartDate = request.ScheduleStartDate,
                ScheduleEndDate = request.ScheduleEndDate,
                RecordCreatedOn = DateTime.Now,
                RecordCreatedById= Guid.Empty,
                RecordUpdatedOn= DateTime.Now,
                RecordUpdatedById= Guid.Empty,
                IsDeleted = false,
                IsActive = true
            };
            UnitOfWork.OrderScheduleRepository.Add(item);
            await UnitOfWork.SaveChangesAsync();

            var respone = new DefaultResponseResult{ 
             IsError = false,  
             Message= "OrderSchedule Created",
             TraceId= request.TraceID
            };
            _logger.LogInformation($"Handler Call : {nameof(CreatreScheduleCommandHandler)} Completed");
            return respone;
        }
    }
}
