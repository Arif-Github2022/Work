﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Petronas.Work.Data.Entities.dbo;
using Petronas.Work.Data.Infrastructure.Interface;
using Petronas.Work.Domain.Models;
using Petronas.Work.Domain.Queries;

namespace Petronas.Work.Domain.Handlers.QueryHandlers
{
    public class GetWeekNonWorkHoursQueryHandler : BaseHandler, IRequestHandler<GetWeekNonWorkHoursQuery, List<GetWeekNonWorkHoursQueryResult>>
    {
        private readonly IMapper _mapper;
        private readonly ILogger<GetWeekNonWorkHoursQueryHandler> _logger;

        public GetWeekNonWorkHoursQueryHandler(IWorkDbUnitOfWork unitOfWork, IMapper mapper, ILogger<GetWeekNonWorkHoursQueryHandler> logger) : base(unitOfWork)
        {
            _mapper = mapper;
            _logger = logger;
        }
        public async Task<List<GetWeekNonWorkHoursQueryResult>> Handle(GetWeekNonWorkHoursQuery request, CancellationToken cancellationToken)
        {
            List<GetWeekNonWorkHoursQueryResult> result = new();
            var roleTechnician = await UnitOfWork.RoleRepository.GetQuery()
                   .Where(x => x.Name != null && x.Name.ToLower().Equals(Core.Constants.Role.Technician)).FirstOrDefaultAsync();
            var teamResources = await UnitOfWork.ResourceTeamRepository.GetQuery()
                                   .Include(nameof(Resource))
                                   .Include($"{nameof(Resource)}.{nameof(ResourceTeam)}")
                                   .Include($"{nameof(Resource)}.{nameof(ResourceRole)}")
                                   .Include($"{nameof(Resource)}.{nameof(ResourceCapacity)}")
                                   .Where(t => t.TeamId == request.TeamID && t.IsActive == true && t.Resource.ResourceRole.Any(r => r.RoleId == roleTechnician.Id))
                                   .OrderBy(o => o.Resource.Name)
                                   .ToListAsync();

            if (teamResources != null && teamResources.Any())
            {
                foreach (var teamResource in teamResources)
                {
                    if (teamResource.Resource != null)
                    {

                        DateTime currentDate = request.StartDate;
                        while (currentDate.Date <= request.EndDate.Date)
                        {
                            if (teamResource.Resource.ResourceCapacity != null && teamResource.Resource.ResourceCapacity.Any())
                            {
                                var resourceCapacity = teamResource.Resource.ResourceCapacity
                                    .FirstOrDefault(x => x.Day.Value.Date == currentDate.Date);

                                if (resourceCapacity != null)
                                {
                                    var newObj = new GetWeekNonWorkHoursQueryResult
                                    {
                                        ResourceUnavailableHours = new List<ResourceUnavailableHours>()
                                        {
                                            new ResourceUnavailableHours
                                            {
                                                Id = resourceCapacity.ResourceId,
                                                Name = resourceCapacity.Resource.Name,
                                                AwayHours = resourceCapacity.AwayHours,
                                                WeekDay = resourceCapacity.Day.Value.DayOfWeek.ToString()
                                            }
                                        }
                                    };

                                    result.Add(newObj);
                                }
                                else
                                {
                                    var newObj = await GetResourceDefaultNonWorkHours(teamResource, currentDate);
                                    result.Add(newObj);
                                }
                            }
                            else
                            {
                                var newObj = await GetResourceDefaultNonWorkHours(teamResource, currentDate);
                                result.Add(newObj);
                            }
                            currentDate = currentDate.AddDays(1);
                        }
                    }
                }
            }
            return result;
        }

        private async Task<GetWeekNonWorkHoursQueryResult> GetResourceDefaultNonWorkHours(ResourceTeam teamResource, DateTime currentDate)
        {
            return await Task.Run(() =>
            {
                return new GetWeekNonWorkHoursQueryResult
                {
                    ResourceUnavailableHours = new List<ResourceUnavailableHours>
                    {
                        new ResourceUnavailableHours
                        {
                            Id = teamResource.Resource.Id,
                            Name = teamResource.Resource.Name,
                            AwayHours = 0,
                            WeekDay = currentDate.DayOfWeek.ToString()
                        }
                    }
                };
            });
        }
    }
}
