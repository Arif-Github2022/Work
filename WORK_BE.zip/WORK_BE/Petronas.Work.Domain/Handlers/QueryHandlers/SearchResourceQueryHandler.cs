﻿using MediatR;
using Microsoft.Extensions.Logging;
using Petronas.Work.Data.Infrastructure.Interface;
using Petronas.Work.Domain.Models;
using Petronas.Work.Domain.Queries;
using Petronas.Work.Integration.Ace.Interface;
using System.Globalization;
using System.Text.RegularExpressions;

namespace Petronas.Work.Domain.Handlers.QueryHandlers
{
    public class SearchResourceQueryHandler : BaseHandler, IRequestHandler<SearchResourceQuery, SearchResourceResult>
    {
        private readonly ILogger<SearchResourceQueryHandler> _logger;
        private readonly IAceHttpClientProxy _aceHttpClientProxy;

        public SearchResourceQueryHandler(IAceHttpClientProxy aceHttpClientProxy, ILogger<SearchResourceQueryHandler> logger, IWorkDbUnitOfWork unitOfWork) : base(unitOfWork)
        {
            _aceHttpClientProxy = aceHttpClientProxy;
            _logger = logger;
        }

        public async Task<SearchResourceResult> Handle(SearchResourceQuery request, CancellationToken cancellationToken)
        {
            _logger.LogInformation($"Handler Call : {nameof(SearchResourceQueryHandler)}");

            SearchResourceResult response = new()
            {
                Resources = new List<ResourceInformation>()
            };

            if (request == null || string.IsNullOrWhiteSpace(request.Name))
            {
                throw new ArgumentException("Parameter : name is null or empty");
            }

            var aceSearchResult = await _aceHttpClientProxy.Search(request.Name);

            if (aceSearchResult == null || !aceSearchResult.Any())
            {
                // return empty response
                return response;
            }

            TextInfo usEnTextInfo = new CultureInfo("en-US", false).TextInfo;

            var resources = aceSearchResult.Select(x => new ResourceInformation
            {
                ResourceId = x.ACMSGuid,
                ResourceAceId = x.ACMSGuid,
                ResourceCompany = x.Company ?? string.Empty,
                IsResourceContractor = !string.IsNullOrWhiteSpace(x.Company) && !x.Company.Contains(Core.Constants.Company.Petronas, StringComparison.CurrentCultureIgnoreCase) ?
                                        true : string.IsNullOrWhiteSpace(x.Company) || x.Company.Contains(Core.Constants.Company.Petronas, StringComparison.CurrentCultureIgnoreCase) ? false : false,
                ResourceName = string.IsNullOrWhiteSpace(x.FullName) ? string.Empty : usEnTextInfo.ToTitleCase(x.FullName.ToLower())
            }).ToList();

            response.Resources.AddRange(resources);

            _logger.LogInformation($"Handler Call : {nameof(SearchResourceQueryHandler)} Completed");

            return response;
        }
    }
}
