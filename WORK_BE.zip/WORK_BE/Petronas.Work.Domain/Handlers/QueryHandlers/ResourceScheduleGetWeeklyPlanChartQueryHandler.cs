﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Petronas.Work.Core.Utilities;
using Petronas.Work.Data.Entities.dbo;
using Petronas.Work.Data.Infrastructure.Interface;
using Petronas.Work.Domain.Common.Interface;
using Petronas.Work.Domain.Models;
using Petronas.Work.Domain.Queries;

namespace Petronas.Work.Domain.Handlers.QueryHandlers
{
    public class ResourceScheduleGetWeeklyPlanChartQueryHandler : BaseHandler, IRequestHandler<ResourceScheduleGetWeeklyPlanChartQuery, ResourceScheduleGetWeeklyPlanChartQueryResult>
    {
        private readonly ILogger<ResourceScheduleGetWeeklyPlanChartQueryHandler> _logger;
        private readonly WeekCalculator _weekCalculator;
        private readonly IResourceWeekWorkHourCalculator _resourceWeekWorkHourCalculator;

        public ResourceScheduleGetWeeklyPlanChartQueryHandler(ILogger<ResourceScheduleGetWeeklyPlanChartQueryHandler> logger, IResourceWeekWorkHourCalculator resourceWeekWorkHourCalculator, WeekCalculator weekCalculator, IWorkDbUnitOfWork unitOfWork) : base(unitOfWork)
        {
            _logger = logger;
            _weekCalculator = weekCalculator;
            _resourceWeekWorkHourCalculator = resourceWeekWorkHourCalculator;
        }

        public async Task<ResourceScheduleGetWeeklyPlanChartQueryResult> Handle(ResourceScheduleGetWeeklyPlanChartQuery request, CancellationToken cancellationToken)
        {
            _logger.LogInformation($"Handler Call : {nameof(ResourceScheduleGetWeeklyPlanChartQueryHandler)}");

            ResourceScheduleGetWeeklyPlanChartQueryResult result = new();

            if (!request.StartDate.HasValue || request.StartDate == DateTime.MinValue || !request.EndDate.HasValue || request.EndDate == DateTime.MinValue)
            {
                throw new ArgumentException("Start date and end date cannot be null");
            }

            var roleTechnician = await UnitOfWork.RoleRepository.GetQuery()
                .Where(x => x.Name != null && x.Name.ToLower().Equals(Core.Constants.Role.Technician)).FirstOrDefaultAsync();

            var teamResources = await UnitOfWork.ResourceTeamRepository.GetQuery()
                .Include(nameof(Resource))
                .Include($"{nameof(Resource)}.{nameof(ResourceRole)}")
                .Include($"{nameof(Resource)}.{nameof(Data.Entities.dbo.ResourceSchedule)}")
                .Include($"{nameof(Resource)}.{nameof(DefaultResourceWorkPlan)}")
                .Include($"{nameof(Resource)}.{nameof(ResourceCapacity)}")
                .Where(t => t.TeamId == request.TeamId && t.IsActive == true
                        && t.Resource.ResourceRole.Any(r => r.RoleId == roleTechnician.Id))
                .ToListAsync();

            var weeks = await _weekCalculator.GetWeeks(request.StartDate.Value, request.EndDate.Value);

            List<ResourceScheduleWeekChartData>? resourceScheduleWeekChartDataList = new();

            if (teamResources != null && teamResources.Any())
            {
                result.WeekChartDataList = new();

                var resourceWeekDayAvailableHours = new List<(Guid ResourceId, DayOfWeek WeekDay, int AvailableHours)>();
                var resourceWeekDayPlannedHours = new List<(Guid ResourceId, DayOfWeek WeekDay, int PlannedHours)>();
                var resourceWeekDayPlannedOvertimeHours = new List<(Guid ResourceId, DayOfWeek WeekDay, int PlannedOvertimeHours)>();
                var resourceWeekDayActualOvertimeHours = new List<(Guid ResourceId, DayOfWeek WeekDay, int ActualOvertimeHours)>();
                var resourceWeekDayUnavailableHours = new List<(Guid ResourceId, DayOfWeek WeekDay, int UnavailableHours)>();
                var resourceWeekDayActualHours = new List<(Guid ResourceId, DayOfWeek WeekDay, int ActualHours)>();

                var dayOfWeekList = Enumerable.Range(0, Enum.GetNames(typeof(DayOfWeek)).Length)
                    .Select(i => (DayOfWeek)i)
                    .OrderBy(x => ((int)x + 6) % 7)
                    .ToList();

                weeks.ForEach((week) =>
                {
                    teamResources.ForEach((teamResource) =>
                    {
                        if (teamResource.Resource != null)
                        {
                            int availableHours = 0;
                            int plannedHours = 0;
                            int plannedOvertimeHours = 0;
                            int unavailableHours = 0;
                            int actualHours = 0;
                            int actualAvailableHours = 0;
                            int actualOvertimeHours = 0;

                            if (teamResource.Resource.DefaultResourceWorkPlan != null && teamResource.Resource.DefaultResourceWorkPlan.Any())
                            {
                                availableHours = _resourceWeekWorkHourCalculator.CalculateAndGetAvailableHours(week, teamResource.Resource.DefaultResourceWorkPlan.ToList());

                                var resourceWeekDayAvailableHoursList = _resourceWeekWorkHourCalculator.CalculateAndGetWeekDayAvailableHours(week, teamResource.Resource.DefaultResourceWorkPlan.ToList(), dayOfWeekList);
                                resourceWeekDayAvailableHours.AddRange(resourceWeekDayAvailableHoursList);

                                if (teamResource.Resource.ResourceSchedule != null && teamResource.Resource.ResourceSchedule.Any())
                                {
                                    var resourceScheduleList = teamResource.Resource.ResourceSchedule
                                                                                .Where(x => x.PlannedDate.HasValue &&
                                                                                            x.PlannedDate.Value.Date >= request.StartDate.Value.Date &&
                                                                                            x.PlannedDate.Value.Date <= request.EndDate.Value.Date).ToList();

                                    var resourceCapacityList = teamResource.Resource.ResourceCapacity != null && teamResource.Resource.ResourceCapacity.Any() ? teamResource.Resource.ResourceCapacity.Where(i => i.Day.Value.Date >= week.StartDate.Date && i.Day.Value.Date <= week.EndDate.Date).ToList() : null;


                                    plannedHours = _resourceWeekWorkHourCalculator.CalculateAndGetPlannedHours(week, resourceScheduleList, teamResource.Resource.DefaultResourceWorkPlan.ToList());
                                    plannedOvertimeHours = _resourceWeekWorkHourCalculator.CalculateAndGetPlannedOvertimeHours(week, resourceScheduleList, teamResource.Resource.DefaultResourceWorkPlan.ToList(), resourceCapacityList);

                                    actualHours = _resourceWeekWorkHourCalculator.CalculateAndGetActualHours(week, resourceScheduleList, teamResource.Resource.DefaultResourceWorkPlan.ToList());
                                    actualOvertimeHours = _resourceWeekWorkHourCalculator.CalculateAndGetActualOvertimeHours(week, resourceScheduleList, teamResource.Resource.DefaultResourceWorkPlan.ToList(), resourceCapacityList);

                                    var resourceWeekDayPlannedHoursList = _resourceWeekWorkHourCalculator.CalculateAndGetWeekDayPlannedHours(week, resourceScheduleList, teamResource.Resource.DefaultResourceWorkPlan.ToList(), dayOfWeekList);
                                    resourceWeekDayPlannedHours.AddRange(resourceWeekDayPlannedHoursList);

                                    var resourceWeekDayPlannedOvertimeHoursList = _resourceWeekWorkHourCalculator.CalculateAndGetWeekDayPlannedOvertimeHours(week, resourceScheduleList, teamResource.Resource.DefaultResourceWorkPlan.ToList(), resourceCapacityList, dayOfWeekList);
                                    resourceWeekDayPlannedOvertimeHours.AddRange(resourceWeekDayPlannedOvertimeHoursList);

                                    var resourceWeekDayActualHoursList = _resourceWeekWorkHourCalculator.CalculateAndGetWeekDayActualHours(week, resourceScheduleList, teamResource.Resource.DefaultResourceWorkPlan.ToList(), dayOfWeekList);
                                    resourceWeekDayActualHours.AddRange(resourceWeekDayActualHoursList);

                                    var resourceWeekDayActualOvertimeHoursList = _resourceWeekWorkHourCalculator.CalculateAndGetWeekDayActualOvertimeHours(week, resourceScheduleList, teamResource.Resource.DefaultResourceWorkPlan.ToList(), resourceCapacityList, dayOfWeekList);
                                    resourceWeekDayActualOvertimeHours.AddRange(resourceWeekDayActualOvertimeHoursList);
                                }
                            }

                            if (teamResource.Resource.ResourceCapacity != null && teamResource.Resource.ResourceCapacity.Any())
                            {
                                unavailableHours = _resourceWeekWorkHourCalculator.CalculateAndGetUnavailableHours(week, teamResource.Resource.ResourceCapacity.ToList());

                                var resourceWeekDayUnavailableHoursList = _resourceWeekWorkHourCalculator.CalculateAndGetWeekDayUnavailableHours(week, teamResource.Resource.ResourceCapacity.ToList(), dayOfWeekList);
                                resourceWeekDayUnavailableHours.AddRange(resourceWeekDayUnavailableHoursList);
                            }

                            var netAvailableHours = availableHours - (plannedHours + unavailableHours);
                            actualAvailableHours = (availableHours - (actualHours + unavailableHours)) < 0 ? 0 : (availableHours - (actualHours + unavailableHours));

                            var netCapacity = availableHours - unavailableHours;

                            ResourceScheduleWeekChartData resourceScheduleWeekChartData = new()
                            {
                                ResourceId = teamResource.Resource.Id,
                                ResourceName = teamResource.Resource.Name,
                                AvailableHours = netAvailableHours < 0 ? 0 : netAvailableHours,
                                AssignedHours = netCapacity > 0 && plannedHours > netCapacity ? netCapacity : plannedHours,
                                AssignedOvertimeHours = plannedOvertimeHours,
                                UnavailableHours = unavailableHours,
                                TotalActualHours = netCapacity > 0 && actualHours > netCapacity ? netCapacity : actualHours,
                                TotalActualAvailableHours = actualAvailableHours,
                                ActualOvertimeHours = actualOvertimeHours
                            };

                            resourceScheduleWeekChartDataList.Add(resourceScheduleWeekChartData);
                        }
                    }); // each resource

                    var weekChartData = new WeekChartData
                    {
                        StartDate = week.StartDate,
                        EndDate = week.EndDate,
                        ResourceScheduleWeekChartDataList = new List<ResourceScheduleWeekChartData>(resourceScheduleWeekChartDataList),
                        weekDayChartDataList = new List<WeekDayChartData>()
                    };

                    var weekAvailableHours = resourceWeekDayAvailableHours.GroupBy(x => x.WeekDay)
                    .Select(x => new
                    {
                        DayOfWeek = x.Key,
                        TotalAvailableHours = x.Sum(x => x.AvailableHours)
                    }).ToList();

                    var weekAssignedHours = resourceWeekDayPlannedHours.GroupBy(x => x.WeekDay)
                    .Select(x => new
                    {
                        DayOfWeek = x.Key,
                        TotalPlannedHours = x.Sum(x => x.PlannedHours)
                    }).ToList();

                    var weekPlannedOvertimeHours = resourceWeekDayPlannedOvertimeHours.GroupBy(x => x.WeekDay)
                    .Select(x => new
                    {
                        DayOfWeek = x.Key,
                        TotalOvertimeHours = x.Sum(x => x.PlannedOvertimeHours)
                    }).ToList();

                    var weekUnavailableHours = resourceWeekDayUnavailableHours.GroupBy(x => x.WeekDay)
                    .Select(x => new
                    {
                        DayOfWeek = x.Key,
                        TotalUnavailableHours = x.Sum(x => x.UnavailableHours)
                    }).ToList();

                    var weekActualHours = resourceWeekDayActualHours.GroupBy(x => x.WeekDay)
                    .Select(x => new
                    {
                        DayOfWeek = x.Key,
                        TotalActualHours = x.Sum(x => x.ActualHours)
                    }).ToList();

                    var weekActualOvertimeHours = resourceWeekDayActualOvertimeHours.GroupBy(x => x.WeekDay)
                    .Select(x => new
                    {
                        DayOfWeek = x.Key,
                        TotalOvertimeHours = x.Sum(x => x.ActualOvertimeHours)
                    }).ToList();

                    dayOfWeekList.ForEach((weekDay) =>
                    {
                        switch (weekDay)
                        {
                            case DayOfWeek.Monday:
                                {
                                    var availableHoursData = weekAvailableHours.Find(x => x.DayOfWeek == weekDay);
                                    var assignedHoursData = weekAssignedHours.Find(x => x.DayOfWeek == weekDay);
                                    var plannedOvertimeHoursData = weekPlannedOvertimeHours.Find(x => x.DayOfWeek == weekDay);
                                    var actualOvertimeHoursData = weekActualOvertimeHours.Find(x => x.DayOfWeek == weekDay);
                                    var unavailableHoursData = weekUnavailableHours.Find(x => x.DayOfWeek == weekDay);
                                    var actualHoursData = weekActualHours.Find(x => x.DayOfWeek == weekDay);

                                    CreateWeekDayChartData(weekChartData, weekDay, availableHoursData, assignedHoursData, plannedOvertimeHoursData, unavailableHoursData, actualHoursData, actualOvertimeHoursData);
                                    break;
                                }
                            case DayOfWeek.Tuesday:
                                {
                                    var availableHoursData = weekAvailableHours.Find(x => x.DayOfWeek == weekDay);
                                    var assignedHoursData = weekAssignedHours.Find(x => x.DayOfWeek == weekDay);
                                    var plannedOvertimeHoursData = weekPlannedOvertimeHours.Find(x => x.DayOfWeek == weekDay);
                                    var actualOvertimeHoursData = weekActualOvertimeHours.Find(x => x.DayOfWeek == weekDay);
                                    var unavailableHoursData = weekUnavailableHours.Find(x => x.DayOfWeek == weekDay);
                                    var actualHoursData = weekActualHours.Find(x => x.DayOfWeek == weekDay);

                                    CreateWeekDayChartData(weekChartData, weekDay, availableHoursData, assignedHoursData, plannedOvertimeHoursData, unavailableHoursData, actualHoursData, actualOvertimeHoursData);
                                    break;
                                }
                            case DayOfWeek.Wednesday:
                                {
                                    var availableHoursData = weekAvailableHours.Find(x => x.DayOfWeek == weekDay);
                                    var assignedHoursData = weekAssignedHours.Find(x => x.DayOfWeek == weekDay);
                                    var plannedOvertimeHoursData = weekPlannedOvertimeHours.Find(x => x.DayOfWeek == weekDay);
                                    var actualOvertimeHoursData = weekActualOvertimeHours.Find(x => x.DayOfWeek == weekDay);
                                    var unavailableHoursData = weekUnavailableHours.Find(x => x.DayOfWeek == weekDay);
                                    var actualHoursData = weekActualHours.Find(x => x.DayOfWeek == weekDay);

                                    CreateWeekDayChartData(weekChartData, weekDay, availableHoursData, assignedHoursData, plannedOvertimeHoursData, unavailableHoursData, actualHoursData, actualOvertimeHoursData);
                                    break;
                                }
                            case DayOfWeek.Thursday:
                                {
                                    var availableHoursData = weekAvailableHours.Find(x => x.DayOfWeek == weekDay);
                                    var assignedHoursData = weekAssignedHours.Find(x => x.DayOfWeek == weekDay);
                                    var plannedOvertimeHoursData = weekPlannedOvertimeHours.Find(x => x.DayOfWeek == weekDay);
                                    var actualOvertimeHoursData = weekActualOvertimeHours.Find(x => x.DayOfWeek == weekDay);
                                    var unavailableHoursData = weekUnavailableHours.Find(x => x.DayOfWeek == weekDay);
                                    var actualHoursData = weekActualHours.Find(x => x.DayOfWeek == weekDay);

                                    CreateWeekDayChartData(weekChartData, weekDay, availableHoursData, assignedHoursData, plannedOvertimeHoursData, unavailableHoursData, actualHoursData, actualOvertimeHoursData);
                                    break;
                                }
                            case DayOfWeek.Friday:
                                {
                                    var availableHoursData = weekAvailableHours.Find(x => x.DayOfWeek == weekDay);
                                    var assignedHoursData = weekAssignedHours.Find(x => x.DayOfWeek == weekDay);
                                    var plannedOvertimeHoursData = weekPlannedOvertimeHours.Find(x => x.DayOfWeek == weekDay);
                                    var actualOvertimeHoursData = weekActualOvertimeHours.Find(x => x.DayOfWeek == weekDay);
                                    var unavailableHoursData = weekUnavailableHours.Find(x => x.DayOfWeek == weekDay);
                                    var actualHoursData = weekActualHours.Find(x => x.DayOfWeek == weekDay);

                                    CreateWeekDayChartData(weekChartData, weekDay, availableHoursData, assignedHoursData, plannedOvertimeHoursData, unavailableHoursData, actualHoursData, actualOvertimeHoursData);
                                    break;
                                }
                            case DayOfWeek.Saturday:
                                {
                                    var availableHoursData = weekAvailableHours.Find(x => x.DayOfWeek == weekDay);
                                    var assignedHoursData = weekAssignedHours.Find(x => x.DayOfWeek == weekDay);
                                    var plannedOvertimeHoursData = weekPlannedOvertimeHours.Find(x => x.DayOfWeek == weekDay);
                                    var actualOvertimeHoursData = weekActualOvertimeHours.Find(x => x.DayOfWeek == weekDay);
                                    var unavailableHoursData = weekUnavailableHours.Find(x => x.DayOfWeek == weekDay);
                                    var actualHoursData = weekActualHours.Find(x => x.DayOfWeek == weekDay);

                                    CreateWeekDayChartData(weekChartData, weekDay, availableHoursData, assignedHoursData, plannedOvertimeHoursData, unavailableHoursData, actualHoursData, actualOvertimeHoursData);
                                    break;
                                }
                            case DayOfWeek.Sunday:
                                {
                                    var availableHoursData = weekAvailableHours.Find(x => x.DayOfWeek == weekDay);
                                    var assignedHoursData = weekAssignedHours.Find(x => x.DayOfWeek == weekDay);
                                    var plannedOvertimeHoursData = weekPlannedOvertimeHours.Find(x => x.DayOfWeek == weekDay);
                                    var actualOvertimeHoursData = weekActualOvertimeHours.Find(x => x.DayOfWeek == weekDay);
                                    var unavailableHoursData = weekUnavailableHours.Find(x => x.DayOfWeek == weekDay);
                                    var actualHoursData = weekActualHours.Find(x => x.DayOfWeek == weekDay);

                                    CreateWeekDayChartData(weekChartData, weekDay, availableHoursData, assignedHoursData, plannedOvertimeHoursData, unavailableHoursData, actualHoursData, actualOvertimeHoursData);
                                    break;
                                }
                        }
                    }); // each day of week


                    weekChartData.TotalAvailableHours = weekChartData.weekDayChartDataList.Sum(x => x.TotalAvailableHours);
                    weekChartData.TotalAssignedHours = weekChartData.weekDayChartDataList.Sum(x => x.TotalAssignedHours);
                    weekChartData.TotalActualHours = weekChartData.weekDayChartDataList.Sum(x => x.TotalActualHours);
                    weekChartData.TotalActualAvailableHours = weekChartData.weekDayChartDataList.Sum(x => x.TotalActualAvailableHours);
                    weekChartData.TotalAssignedOvertimeHours = weekChartData.weekDayChartDataList.Sum(x => x.TotalAssignedOvertimeHours);
                    weekChartData.TotalUnavailableHours = weekChartData.weekDayChartDataList.Sum(x => x.TotalUnavailableHours);
                    weekChartData.TotalActualOvertimeHours = weekChartData.weekDayChartDataList.Sum(x => x.TotalActualOvertimeHours);

                    result.WeekChartDataList.Add(weekChartData);

                    // Clear resourceScheduleWeekChartDataList after adding to WeekChartDataList.
                    resourceScheduleWeekChartDataList.Clear();

                    resourceWeekDayAvailableHours.Clear();
                    resourceWeekDayPlannedHours.Clear();
                    resourceWeekDayPlannedOvertimeHours.Clear();
                    resourceWeekDayUnavailableHours.Clear();
                    resourceWeekDayActualHours.Clear();

                }); // each week
            }

            _logger.LogInformation($"Handler Call : {nameof(ResourceScheduleGetWeeklyPlanChartQueryHandler)} Completed");
            return result;
        }

        private void CreateWeekDayChartData(WeekChartData weekChartData, DayOfWeek weekDay, dynamic availableHoursData, dynamic assignedHoursData, dynamic plannedOvertimeHoursData, dynamic unavailableHoursData, dynamic actualHoursData, dynamic actualOvertimeHoursData)
        {
            var plannedHours = assignedHoursData != null ? assignedHoursData.TotalPlannedHours : 0;
            var unavailableHours = unavailableHoursData != null ? unavailableHoursData.TotalUnavailableHours : 0;
            var plannedOvertimeHours = plannedOvertimeHoursData != null ? plannedOvertimeHoursData.TotalOvertimeHours : 0;
            var actualHours = actualHoursData != null ? actualHoursData.TotalActualHours : 0;
            var actualOvertimeHours = actualOvertimeHoursData != null ? actualOvertimeHoursData.TotalOvertimeHours : 0;

            var netAvailableHours = availableHoursData != null ? availableHoursData.TotalAvailableHours - (plannedHours + unavailableHours) < 0 ? 0 : availableHoursData.TotalAvailableHours - (plannedHours + unavailableHours) : 0;
            var actualAvailableHours = availableHoursData != null ? availableHoursData.TotalAvailableHours - (actualHours + unavailableHours) < 0 ? 0 : availableHoursData.TotalAvailableHours - (actualHours + unavailableHours) : 0;
            WeekDayChartData weekDayChartData = new WeekDayChartData
            {
                DayOfWeek = Enum.GetName(weekDay),
                TotalAvailableHours = netAvailableHours,
                TotalUnavailableHours = unavailableHours,
                TotalAssignedHours = plannedHours,
                TotalAssignedOvertimeHours = plannedOvertimeHours,
                TotalActualHours = actualHours,
                TotalActualOvertimeHours = actualOvertimeHours,
                TotalActualAvailableHours = actualAvailableHours
            };

            weekChartData.weekDayChartDataList.Add(weekDayChartData);
        }
    }
}
