﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Petronas.Work.Core.Utilities;
using Petronas.Work.Data.Entities.dbo;
using Petronas.Work.Data.Infrastructure.Interface;
using Petronas.Work.Domain.Common.Interface;
using Petronas.Work.Domain.Models;
using Petronas.Work.Domain.Queries;

namespace Petronas.Work.Domain.Handlers.QueryHandlers
{
    public class MaintenanceOrderWeeklyPlanChartGetQueryHandler : BaseHandler, IRequestHandler<MaintenanceOrderWeeklyPlanChartGetQuery, List<MaintenanceOrderWeeklyPlanChartGetQueryResult>>
    {
        private readonly IMapper _mapper;
        private readonly ILogger<MaintenanceOrderSearchQueryHandler> _logger;
        private readonly WeekCalculator _weekCalculator;
        private readonly IResourceWeekWorkHourCalculator _resourceWeekWorkHourCalculator;

        public MaintenanceOrderWeeklyPlanChartGetQueryHandler(IWorkDbUnitOfWork unitOfWork, IMapper mapper, IResourceWeekWorkHourCalculator resourceWeekWorkHourCalculator, WeekCalculator weekCalculator, ILogger<MaintenanceOrderSearchQueryHandler> logger) : base(unitOfWork)
        {
            _mapper = mapper;
            _logger = logger;
            _weekCalculator = weekCalculator;
            _resourceWeekWorkHourCalculator = resourceWeekWorkHourCalculator;
        }

        public async Task<List<MaintenanceOrderWeeklyPlanChartGetQueryResult>> Handle(MaintenanceOrderWeeklyPlanChartGetQuery request, CancellationToken cancellationToken)
        {
            _logger.LogInformation($"Handler Call : {nameof(MaintenanceOrderWeeklyPlanChartGetQueryHandler)}");

            List<MaintenanceOrderWeeklyPlanChartGetQueryResult> result = new();

            var roleTechnician = await UnitOfWork.RoleRepository.GetQuery()
                .Where(x => x.Name != null && x.Name.ToLower().Equals(Core.Constants.Role.Technician)).FirstOrDefaultAsync();

            var teamResources = await UnitOfWork.ResourceTeamRepository.GetQuery()
                .Include(nameof(Resource))
                .Include($"{nameof(Resource)}.{nameof(ResourceRole)}")
                .Include($"{nameof(Resource)}.{nameof(Data.Entities.dbo.ResourceSchedule)}")
                .Include($"{nameof(Resource)}.{nameof(DefaultResourceWorkPlan)}")
                .Include($"{nameof(Resource)}.{nameof(ResourceCapacity)}")
                .Where(t => t.TeamId == request.TeamId && t.IsActive == true
                        && t.Resource.ResourceRole.Any(r => r.RoleId == roleTechnician.Id))
                .ToListAsync();

            var weeks = await _weekCalculator.GetWeeks(request.StartDate, request.EndDate);

            if (teamResources != null && teamResources.Any())
            {
                weeks.ForEach((week) =>
                {
                    bool isCurrentWeek = DateTime.Now >= week.StartDate && DateTime.Now <= week.EndDate;
                    int availableHours = 0;
                    int plannedHours = 0;
                    int overtimeHours = 0;
                    int unavailableHours = 0;
                    teamResources.ForEach((teamResource) =>
                    {
                        if (teamResource.Resource != null)
                        {
                            if (teamResource.Resource.DefaultResourceWorkPlan != null && teamResource.Resource.DefaultResourceWorkPlan.Any())
                            {
                                availableHours += _resourceWeekWorkHourCalculator.CalculateAndGetAvailableHours(week, teamResource.Resource.DefaultResourceWorkPlan.ToList());

                                if (teamResource.Resource.ResourceSchedule != null && teamResource.Resource.ResourceSchedule.Any())
                                {
                                    var resourceScheduleList = teamResource.Resource.ResourceSchedule
                                                                                .Where(x => x.PlannedDate.HasValue &&
                                                                                            x.PlannedDate.Value.Date >= week.StartDate.Date &&
                                                                                            x.PlannedDate.Value.Date <= week.EndDate.Date).ToList();

                                    var resourceCapacityList = teamResource.Resource.ResourceCapacity != null && teamResource.Resource.ResourceCapacity.Any() ? teamResource.Resource.ResourceCapacity.Where(i => i.Day.Value.Date >= week.StartDate.Date && i.Day.Value.Date <= week.EndDate.Date).ToList() : null;

                                    plannedHours += _resourceWeekWorkHourCalculator.CalculateAndGetPlannedHours(week, resourceScheduleList, teamResource.Resource.DefaultResourceWorkPlan.ToList());
                                    overtimeHours += _resourceWeekWorkHourCalculator.CalculateAndGetPlannedOvertimeHours(week, resourceScheduleList, teamResource.Resource.DefaultResourceWorkPlan.ToList(), resourceCapacityList);
                                }
                            }

                            if (teamResource.Resource.ResourceCapacity != null && teamResource.Resource.ResourceCapacity.Any())
                            {
                                var resourceCapacityList = teamResource.Resource.ResourceCapacity != null && teamResource.Resource.ResourceCapacity.Any() ? teamResource.Resource.ResourceCapacity.Where(i => i.Day.Value.Date >= week.StartDate.Date && i.Day.Value.Date <= week.EndDate.Date).ToList() : null;
                                unavailableHours += _resourceWeekWorkHourCalculator.CalculateAndGetUnavailableHours(week, resourceCapacityList);
                            }
                        }
                    });

                    var netAvailableHours = availableHours - (plannedHours + unavailableHours);

                    result.Add(new MaintenanceOrderWeeklyPlanChartGetQueryResult
                    {
                        AvailableHours = netAvailableHours < 0 ? 0 : netAvailableHours,
                        AssignedHours = plannedHours,
                        OvertimeHours = overtimeHours,
                        UnavailableHours = unavailableHours,
                        StartDate = week.StartDate,
                        EndDate = week.EndDate,
                        IsCurrentWeek = isCurrentWeek,
                        WeekNumber = week.WeekNumberOfYear
                    });
                });
            }

            _logger.LogInformation($"Handler Call : {nameof(MaintenanceOrderWeeklyPlanChartGetQueryHandler)} Completed");

            return result;
        }
    }
}
