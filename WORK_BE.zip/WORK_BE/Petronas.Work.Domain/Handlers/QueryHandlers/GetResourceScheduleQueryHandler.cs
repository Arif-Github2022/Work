﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Petronas.Work.Core.Model;
using Petronas.Work.Core.Utilities;
using Petronas.Work.Data.Entities.dbo;
using Petronas.Work.Data.Infrastructure.Interface;
using Petronas.Work.Domain.Models;
using Petronas.Work.Domain.Queries;
using Petronas.Work.Integration.Sap.Interface;

namespace Petronas.Work.Domain.Handlers.QueryHandlers
{
    public class GetResourceScheduleQueryHandler : BaseHandler, IRequestHandler<GetResourceScheduleQuery, List<GetResourceScheduleQueryResult>>
    {
        private readonly IMapper _mapper;
        private readonly ILogger<GetResourceScheduleQueryHandler> _logger;
        private readonly WeekCalculator _weekCalculator;
        private readonly ISapHttpClientProxy _sapHttpClientProxy;

        public GetResourceScheduleQueryHandler(IWorkDbUnitOfWork unitOfWork, IMapper mapper, ILogger<GetResourceScheduleQueryHandler> logger
            , WeekCalculator weekCalculator, ISapHttpClientProxy sapHttpClientProxy) : base(unitOfWork)
        {
            _mapper = mapper;
            _logger = logger;
            _weekCalculator = weekCalculator;
            _sapHttpClientProxy = sapHttpClientProxy;
        }

        public async Task<List<GetResourceScheduleQueryResult>> Handle(GetResourceScheduleQuery request, CancellationToken cancellationToken)
        {
            _logger.LogInformation($"Handler Call : {nameof(GetResourceScheduleQueryHandler)}");

            List<GetResourceScheduleQueryResult> result = new();
            List<ResourceDailySchedule> dailyScheduleList = new();
            List<GetResourceScheduleQueryResult> response = new();

            try
            {
                var weeks = await _weekCalculator.GetWeeks(request.StartDate, request.EndDate);

                var roleTechnician = await UnitOfWork.RoleRepository.GetQuery()
                    .Where(x => x.Name != null && x.Name.ToLower().Equals(Core.Constants.Role.Technician)).FirstOrDefaultAsync();

                var scheduledResources = await UnitOfWork.ResourceScheduleRepository.GetQuery()
                                   .Include(nameof(Resource))
                                   .Include($"{nameof(Resource)}.{nameof(ResourceTeam)}")
                                   .Include($"{nameof(Resource)}.{nameof(Data.Entities.dbo.ResourceSchedule)}")
                                   .Include($"{nameof(Resource)}.{nameof(ResourceCapacity)}")
                                   .Include($"{nameof(Resource)}.{nameof(DefaultResourceWorkPlan)}")
                                   .Where(t =>
                                            t.PlannedDate.HasValue && t.PlannedDate.Value.Date >= request.StartDate.Date && t.PlannedDate.Value.Date <= request.EndDate.Date
                                            && t.Resource != null
                                            && t.Resource.ResourceRole != null
                                            && t.Resource.ResourceRole.Any(r => r.RoleId == roleTechnician.Id)
                                            && t.IsActive == true)
                                   .ToListAsync();

                var currentTeam = await UnitOfWork.ResourceTeamRepository.GetQuery()
                                    .Include(nameof(Resource))
                                    .Include($"{nameof(Resource)}.{nameof(ResourceTeam)}")
                                    .Include($"{nameof(Resource)}.{nameof(Data.Entities.dbo.ResourceSchedule)}")
                                    .Include($"{nameof(Resource)}.{nameof(ResourceCapacity)}")
                                    .Include($"{nameof(Resource)}.{nameof(DefaultResourceWorkPlan)}")
                                    .Where(t => t.TeamId == request.TeamID && t.Resource.ResourceRole != null && t.IsActive == true
                                            && t.Resource.ResourceRole.Any(r => r.RoleId == roleTechnician.Id) && t.IsActive == true).ToListAsync();

                weeks.ForEach((week) =>
                {
                    var workOrders = UnitOfWork.WorkOrderRepository.GetQuery()
                    .Include(nameof(OrderSchedule))
                    .AsEnumerable()
                    .Where(x => x.OrderSchedule
                        .Any(y =>
                                ((y.ScheduleStartDate.Value.Date <= week.StartDate.Date || y.ScheduleStartDate.Value.Date >= week.StartDate.Date) && (y.ScheduleStartDate.Value.Date <= week.EndDate.Date)) &&
                                ((y.ScheduleEndDate.Value.Date <= week.EndDate.Date || y.ScheduleEndDate.Value.Date >= week.EndDate.Date) && (y.ScheduleEndDate.Value.Date >= week.StartDate.Date))
                            )).ToList();
                    if (workOrders != null && workOrders.Any())
                    {
                        workOrders.ForEach((workOrder) =>
                        {
                            var resourceScheduleByWorkOrder = scheduledResources.FindAll(i =>
                                                                                i.WorkOrderId == workOrder.Id
                                                                                && i.PlannedDate.HasValue
                                                                                && i.PlannedDate.Value.Date >= week.StartDate.Date
                                                                                && i.PlannedDate.Value.Date <= week.EndDate.Date);

                            if (resourceScheduleByWorkOrder == null || !resourceScheduleByWorkOrder.Any())
                            {
                                // Create scheduledWorkOrder
                                resourceScheduleByWorkOrder = currentTeam.Select(x => new Data.Entities.dbo.ResourceSchedule
                                {
                                    WorkOrderId = workOrder.Id,
                                    Resource = x.Resource,
                                    ResourceId = x.Resource.Id,
                                    WorkOrder = workOrder
                                }).ToList();
                            }

                            var actualHours = 0;
                            var plannedHours = 0;
                            var awayHours = 0;
                            var overtimeHours = 0;
                            var currentDate = week.StartDate;
                            while (currentDate.Date <= week.EndDate.Date)
                            {
                                var resourceScheduleListByWorkOrder = resourceScheduleByWorkOrder
                                .FindAll(i =>
                                        i.PlannedDate.HasValue && i.PlannedDate.Value.Date == currentDate.Date
                                        || i.ActualDate.HasValue && i.ActualDate.Value.Date == currentDate.Date
                                    );

                                if (resourceScheduleListByWorkOrder != null && resourceScheduleListByWorkOrder.Any())
                                {
                                    foreach (var resourceSchedule in resourceScheduleListByWorkOrder)
                                    {
                                        var resourceCapacity = UnitOfWork.ResourceCapacityRepository.GetQuery()
                                        .Where(x => x.Day.Value.Date == currentDate.Date && x.ResourceId == resourceSchedule.ResourceId).ToList();

                                        var defaultResourceWorkPlanList = UnitOfWork.DefaultResourceWorkPlanRepository.GetQuery()
                                            .Where(x => x.ResourceId == resourceSchedule.ResourceId).ToList();

                                        var defaultPlan = defaultResourceWorkPlanList.Find(x => !string.IsNullOrWhiteSpace(x.WeekDay) && Enum.TryParse<DayOfWeek>(x.WeekDay, out _) && Enum.Parse<DayOfWeek>(x.WeekDay) == currentDate.DayOfWeek);

                                        var dailySchedule = new ResourceDailySchedule();
                                        dailySchedule.WeekDay = currentDate;
                                        dailySchedule.WeekDayName = defaultPlan.WeekDay.ToString();

                                        dailySchedule.PlannedHours = resourceSchedule.PlannedWorkHours.HasValue ? resourceSchedule.PlannedWorkHours.Value : 0;
                                        plannedHours = dailySchedule.PlannedHours;

                                        dailySchedule.ActualHours = resourceSchedule.ActualWorkHours.HasValue ? resourceSchedule.ActualWorkHours.Value : 0;
                                        actualHours = dailySchedule.ActualHours;

                                        dailySchedule.AwayHours = resourceCapacity.Find(i => i.Day.Value.Date == currentDate.Date) != null ? resourceCapacity.Find(i => i.Day.Value.Date == currentDate.Date).AwayHours.Value : 0;

                                        // Calculate overtime
                                        var workHoursCapacityForDay = defaultPlan.WorkHours;
                                        if (resourceCapacity != null && dailySchedule.AwayHours > 0)
                                        {
                                            workHoursCapacityForDay = defaultPlan.WorkHours - dailySchedule.AwayHours;
                                            if (plannedHours > workHoursCapacityForDay)
                                            {
                                                overtimeHours = dailySchedule.OvertimeHours = plannedHours - workHoursCapacityForDay;
                                            }
                                        }
                                        else if (plannedHours > workHoursCapacityForDay)
                                        {
                                            overtimeHours = dailySchedule.OvertimeHours = plannedHours - workHoursCapacityForDay;
                                        }
                                        else
                                        {
                                            overtimeHours = dailySchedule.OvertimeHours = 0;
                                        }

                                        dailyScheduleList.Add(dailySchedule);

                                        if (dailyScheduleList != null && dailyScheduleList.Any())
                                        {
                                            var resourceTeam = resourceSchedule.Resource.ResourceTeam.FirstOrDefault(i => i.TeamId == request.TeamID);

                                            result.Add(BuildResponse(week, workOrder, resourceSchedule, resourceTeam, dailyScheduleList, plannedHours, awayHours, actualHours, overtimeHours));
                                        }
                                    }
                                }
                                else
                                {
                                    resourceScheduleByWorkOrder.ForEach((resourceSchedule) =>
                                    {
                                        var resourceCapacity = UnitOfWork.ResourceCapacityRepository.GetQuery()
                                        .Where(x => x.Day.Value.Date == currentDate.Date && x.ResourceId == resourceSchedule.ResourceId).ToList();

                                        var defaultResourceWorkPlanList = UnitOfWork.DefaultResourceWorkPlanRepository.GetQuery()
                                            .Where(x => x.ResourceId == resourceSchedule.ResourceId).ToList();

                                        var defaultPlan = defaultResourceWorkPlanList.Find(x => !string.IsNullOrWhiteSpace(x.WeekDay) && Enum.TryParse<DayOfWeek>(x.WeekDay, out _) && Enum.Parse<DayOfWeek>(x.WeekDay) == currentDate.DayOfWeek);

                                        plannedHours = defaultPlan.WorkHours;
                                        var dailySchedule = new ResourceDailySchedule();
                                        dailySchedule.ActualHours = 0;
                                        dailySchedule.AwayHours = resourceCapacity.Find(i => i.Day.Value.Date == currentDate.Date) != null ? resourceCapacity.Find(i => i.Day.Value.Date == currentDate.Date).AwayHours.Value : 0;
                                        dailySchedule.PlannedHours = 0;
                                        dailySchedule.OvertimeHours = 0;
                                        dailySchedule.WeekDay = currentDate;
                                        dailySchedule.WeekDayName = defaultPlan.WeekDay;

                                        dailyScheduleList.Add(dailySchedule);

                                        if (dailyScheduleList != null && dailyScheduleList.Any())
                                        {
                                            var resourceTeam = resourceSchedule.Resource.ResourceTeam.FirstOrDefault(i => i.TeamId == request.TeamID);

                                            result.Add(BuildResponse(week, workOrder, resourceSchedule, resourceTeam, dailyScheduleList, plannedHours, awayHours, actualHours, overtimeHours));
                                        }

                                    });
                                }

                                currentDate = currentDate.AddDays(1);
                            }
                        });

                        var listResult = result.SelectMany(i => i.ScheduledOrder).GroupBy(b => b.WorkOrderId)
                        .Select(grouping =>
                            new
                            {
                                ScheduledOrder = new
                                {
                                    WorkOrderId = grouping.Key,
                                    OrderDescription = grouping.First().OrderDescription,
                                    OrderStartDate = grouping.First().OrderStartDate,
                                    OrderEndDate = grouping.First().OrderEndDate,
                                    OrderNumber = grouping.First().OrderNumber,
                                    OrderType = grouping.First().OrderType,
                                    FunctionalLocation = grouping.First().FunctionalLocation,
                                    Priority = grouping.First().Priority,
                                    TotalActualHours = grouping.First().TotalActualHours,
                                    TotalAwayHours = grouping.First().TotalAwayHours,
                                    TotalplannedHours = grouping.First().TotalplannedHours,
                                    TotalOvertimeHours = grouping.First().TotalOvertimeHours,
                                    ResourceSchedule = grouping.SelectMany(i => i.ResourceSchedule)
                                                    .GroupBy(g => g.ResourceId, (k, l) => new ResourceScheduleInfo
                                                    {
                                                        ResourceId = k,
                                                        IsResourceContractor = l.First().IsResourceContractor,
                                                        ResourceAceId = l.First().ResourceAceId,
                                                        ResourceCompany = l.First().ResourceCompany,
                                                        ResourceName = l.First().ResourceName,
                                                        DailySchedule = l.SelectMany(z => z.DailySchedule).ToList()
                                                    }).OrderBy(o => o.ResourceName).ToList(),
                                }
                            }
                         ).ToList();

                        var newObj = new GetResourceScheduleQueryResult
                        {
                            WeekStartDate = week.StartDate,
                            WeekEndDate = week.EndDate,
                            TeamID = request.TeamID,
                            ScheduledOrder = listResult.Select(x => new ScheduledOrderInfo
                            {
                                WorkOrderId = x.ScheduledOrder.WorkOrderId,
                                OrderDescription = x.ScheduledOrder.OrderDescription,
                                OrderStartDate = (DateTime)x.ScheduledOrder.OrderStartDate,
                                OrderEndDate = (DateTime)x.ScheduledOrder.OrderEndDate,
                                OrderNumber = x.ScheduledOrder.OrderNumber,
                                OrderType = x.ScheduledOrder.OrderType,
                                FunctionalLocation = x.ScheduledOrder.FunctionalLocation,
                                Priority = Convert.ToInt32(x.ScheduledOrder.Priority),
                                TotalActualHours = x.ScheduledOrder.ResourceSchedule.SelectMany(i => i.DailySchedule).Sum(s => s.ActualHours),
                                TotalAwayHours = x.ScheduledOrder.ResourceSchedule.SelectMany(i => i.DailySchedule).Sum(s => s.AwayHours),
                                TotalplannedHours = x.ScheduledOrder.ResourceSchedule.SelectMany(i => i.DailySchedule).Sum(s => s.PlannedHours),
                                TotalOvertimeHours = x.ScheduledOrder.ResourceSchedule.SelectMany(i => i.DailySchedule).Sum(s => s.OvertimeHours),
                                ResourceSchedule = x.ScheduledOrder.ResourceSchedule.Select(i => new ResourceScheduleInfo
                                {
                                    ResourceId = i.ResourceId,
                                    ResourceName = i.ResourceName,
                                    DailySchedule = i.DailySchedule,
                                    ResourceCompany = i.ResourceCompany,
                                    ResourceAceId = i.ResourceAceId ?? string.Empty,
                                    IsResourceContractor = i.IsResourceContractor
                                }).ToList(),
                            }).ToList(),

                        };
                        response.Add(newObj);
                    }

                });

                await FillWorkOrderOperationDetails(response);

                _logger.LogInformation($"Handler Call : {nameof(GetResourceScheduleQueryHandler)} Completed");

                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.ToString());
                throw;
            }
        }

        private GetResourceScheduleQueryResult BuildResponse(WeekInfo week, WorkOrder workOrder, ResourceSchedule resourceSchedule, ResourceTeam resourceTeam, List<ResourceDailySchedule> dailyScheduleList, int totalplannedHours, int totalActualHours, int totalAwayHours, int overtimeHours)
        {
            var newList = new List<ResourceDailySchedule>(dailyScheduleList);
            var result = new GetResourceScheduleQueryResult
            {
                WeekStartDate = week.StartDate,
                WeekEndDate = week.EndDate,
                TeamID = resourceTeam == null ? Guid.Empty : resourceTeam.TeamId,
                ScheduledOrder = new List<ScheduledOrderInfo>
                {
                    new ScheduledOrderInfo
                    {
                        WorkOrderId = workOrder.Id,
                        OrderDescription = workOrder.OrderDescription,
                        OrderStartDate = (DateTime)workOrder.BasicStartDate,
                        OrderEndDate = (DateTime)workOrder.BasicFinishDate,
                        OrderNumber = workOrder.OrderNumber,
                        OrderType = workOrder.OrderType,
                        FunctionalLocation = workOrder.FunctionalLocation,
                        Priority = Convert.ToInt32(workOrder.Priority),
                        TotalActualHours = totalActualHours,
                        TotalAwayHours = totalAwayHours,
                        TotalplannedHours = totalplannedHours,
                        TotalOvertimeHours = overtimeHours,
                        ResourceSchedule = new List<ResourceScheduleInfo>
                        {
                            new ResourceScheduleInfo
                            {
                                ResourceId = resourceSchedule.Resource.Id,
                                ResourceName = resourceSchedule.Resource.Name,
                                ResourceCompany = resourceSchedule.Resource.Company,
                                ResourceAceId = resourceSchedule.Resource.AceId,
                                IsResourceContractor = resourceSchedule.Resource.IsContractor.HasValue ? resourceSchedule.Resource.IsContractor.Value : false,
                                DailySchedule = newList
                            }
                        }
                    }
                }
            };
            dailyScheduleList.Clear();
            return result;
        }

        private async Task FillWorkOrderOperationDetails(List<GetResourceScheduleQueryResult> getResourceScheduleQueryResults)
        {
            await Parallel.ForEachAsync(getResourceScheduleQueryResults.SelectMany(i => i.ScheduledOrder).ToList(), async (scheduledOrder, cancellationToken) =>
            {
                try
                {
                    var orderOperations = await _sapHttpClientProxy.GetWorkOrderOperation(scheduledOrder.OrderNumber.Trim());
                    if (orderOperations != null && orderOperations.Any())
                    {
                        var orderOperation = orderOperations.FirstOrDefault(x => x.OpreationNumber == "0010");
                        scheduledOrder.PlannedWork = orderOperation?.PlannedWork?.Trim();
                        scheduledOrder.UnitforWork = orderOperation?.UnitForWork?.Trim();
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, ex.Message);
                }
            });
        }
    }
}
