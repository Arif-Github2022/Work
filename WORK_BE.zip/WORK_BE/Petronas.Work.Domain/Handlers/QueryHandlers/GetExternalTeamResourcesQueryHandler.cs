﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Petronas.Work.Data.Entities.dbo;
using Petronas.Work.Data.Infrastructure.Interface;
using Petronas.Work.Domain.Models;
using Petronas.Work.Domain.Queries;
using Petronas.Work.Integration.Ace.Interface;
using Petronas.Work.Integration.Ace.ResponseModels;
using Petronas.Work.Integration.WebClient.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Domain.Handlers.QueryHandlers
{
    public class GetExternalTeamResourcesQueryHandler : BaseHandler, IRequestHandler<GetExternalTeamResourcesQuery, List<GetTeamResourcesQueryResult>>
    {
        private readonly IMapper _mapper;
        private readonly ILogger<GetExternalTeamResourcesQueryHandler> _logger;
        private readonly IAceHttpClientProxy _iAceHttpClientProxy;

        public GetExternalTeamResourcesQueryHandler(IWorkDbUnitOfWork unitOfWork, IMapper mapper, ILogger<GetExternalTeamResourcesQueryHandler> logger, IAceHttpClientProxy iAceHttpClientProxy) : base(unitOfWork)
        {
            _mapper = mapper;
            _logger = logger;
            _iAceHttpClientProxy = iAceHttpClientProxy;

        }
        public async Task<List<GetTeamResourcesQueryResult>> Handle(GetExternalTeamResourcesQuery request, CancellationToken cancellationToken)
        {
            _logger.LogInformation($"Handler Call : {nameof(GetExternalTeamResourcesQueryHandler)} Started");
            var teamResources = await _iAceHttpClientProxy.Search(request.Name);
            var teamList = await BuildTeamList(teamResources);
            return teamList;
        }

        private async Task<List<GetTeamResourcesQueryResult>> BuildTeamList(List<StaffInformation> resources)
        {
            var result = resources.Select(x => new GetTeamResourcesQueryResult
            {
                ResourceId = x.ACMSGuid,
                Name = x.FullName,
                Company = x.Company
                
            }).ToList();
            _logger.LogInformation($"Handler Call : {nameof(GetExternalTeamResourcesQueryHandler)} Completed");
            return result;
        }
    }
}

