﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Petronas.Work.Core.Enumerations;
using Petronas.Work.Core.Utilities;
using Petronas.Work.Data.Entities.dbo;
using Petronas.Work.Data.Infrastructure.Interface;
using Petronas.Work.Domain.Models;
using Petronas.Work.Domain.Queries;
using Petronas.Work.Integration.Sap.Interface;
using System.Globalization;

namespace Petronas.Work.Domain.Handlers.QueryHandlers
{
    public class MaintenanceOrderSearchQueryHandler : BaseHandler, IRequestHandler<MaintenanceOrderSearchQuery, MaintenanceOrderSearchResult>
    {
        private readonly IMapper _mapper;
        private readonly ILogger<MaintenanceOrderSearchQueryHandler> _logger;
        private readonly WeekCalculator _weekCalculator;
        private readonly ISapHttpClientProxy _sapHttpClientProxy;
        private readonly IMediator _mediator;

        public MaintenanceOrderSearchQueryHandler(IWorkDbUnitOfWork unitOfWork, IMapper mapper, WeekCalculator weekCalculator
            , ILogger<MaintenanceOrderSearchQueryHandler> logger
            , ISapHttpClientProxy sapHttpClientProxy, IMediator mediator) : base(unitOfWork)
        {
            _mapper = mapper;
            _logger = logger;
            _weekCalculator = weekCalculator;
            _sapHttpClientProxy = sapHttpClientProxy;
            _mediator = mediator;
        }

        public async Task<MaintenanceOrderSearchResult> Handle(MaintenanceOrderSearchQuery request, CancellationToken cancellationToken)
        {
            dynamic response;
            _logger.LogInformation($"Handler Call : {nameof(MaintenanceOrderSearchQueryHandler)}");

            response = await SearchWorkOrders(request);

            if (response != null)
            {
                await FillResourceWeeklyAvailability(response.Data, request.TeamId);
                await FillWorkOrderOperationDetails(response.Data);
            }

            _logger.LogInformation($"Handler Call : {nameof(MaintenanceOrderSearchQueryHandler)} Completed");
            return response;
        }

        private async Task<MaintenanceOrderSearchResult> SearchWorkOrders(MaintenanceOrderSearchQuery request)
        {
            bool isRequestUserStatusesHasValues = IsRequest_UserStatusesHasValues(request);
            bool isRequestSystemStatusesHasValues = IsRequest_SystemStatusesHasValues(request);

            bool isRequestOrderTypesHasValues = IsRequest_OrderTypesHasValues(request);
            bool isRequestWorkCentersHasValues = IsRequest_WorkCentersHasValues(request);
            bool isRequestPrioritiesHasValues = IsRequest_PrioritiesHasValues(request);

            //Get all data first and filter, will improve this later
            //var allWorkOrders = await UnitOfWork.WorkOrderRepository.GetQuery().Include(nameof(OrderSchedule)).ToListAsync();

            // Get Count
            var searchQuery = UnitOfWork.WorkOrderRepository.GetQuery()
                .Include(nameof(OrderSchedule))
                .AsEnumerable()
                .Where(x =>
                        (
                            ((request.OrderNumber == null || request.OrderNumber.Trim() == "") ? true : x.OrderNumber.ToLower().Contains(request.OrderNumber.ToLower())) ||
                            ((request.OrderDescription == null || request.OrderDescription.Trim() == "") ? true : ((x.OrderDescription != null && x.OrderDescription.Trim() != "") ? x.OrderDescription.ToLower().Contains(request.OrderDescription.ToLower()) : true)) ||
                            ((request.FunctionalLocation == null || request.FunctionalLocation.Trim() == "") ? true : ((x.FunctionalLocation != null && x.FunctionalLocation.Trim() != "") ? x.FunctionalLocation.ToLower().Contains(request.FunctionalLocation.ToLower()) : true))
                        )
                        &&
                        (
                            (!isRequestOrderTypesHasValues ? true : ((x.OrderType != null && x.OrderType.Trim() != "") ? request.OrderTypes.Any(o => o.ToLower() == x.OrderType.ToLower()) : true)) &&
                            (!isRequestWorkCentersHasValues ? true : ((x.MainWorkCenter != null && x.MainWorkCenter.Trim() != "") ? request.WorkCenters.Any(o => o.ToLower() == x.MainWorkCenter.ToLower()) : true)) &&
                            (!isRequestPrioritiesHasValues ? true : ((x.Priority != null && x.Priority.Trim() != "") ? request.Priorities.Any(o => o.ToLower() == x.Priority.ToLower()) : true)) &&
                            (!isRequestUserStatusesHasValues ? true : ((x.UserStatus != null && x.UserStatus.Trim() != "") ? request.UserStatuses.Any(rs => x.UserStatus.Split(" ", StringSplitOptions.RemoveEmptyEntries).Any(ds => ds.ToLower().Equals(rs.ToLower()))) : true)) &&
                            (!isRequestSystemStatusesHasValues ? true : ((x.SystemStatus != null && x.SystemStatus.Trim() != "") ? request.SystemStatuses.Any(rs => x.SystemStatus.Split(" ", StringSplitOptions.RemoveEmptyEntries).Any(ds => ds.ToLower().Equals(rs.ToLower()))) : true))
                        )
                        );

            var totalRecordCount = searchQuery.Count();

            var workOrders = searchQuery
                            .OrderByDescending(o => o.CreatedOn)
                            .Skip((request.Page - 1) * request.PageSize)
                            .Take(request.PageSize)
                            .ToList();

            var workOrdersList = await BuildOrderSchedule(workOrders, totalRecordCount, request.Page, request.PageSize);

            return workOrdersList;
        }

        private bool IsRequest_SystemStatusesHasValues(MaintenanceOrderSearchQuery request)
        {
            return (
                     request.SystemStatuses != null &&
                     request.SystemStatuses.Any() &&
                     request.SystemStatuses.All(s => !string.IsNullOrWhiteSpace(s))
                   );
        }

        private bool IsRequest_UserStatusesHasValues(MaintenanceOrderSearchQuery request)
        {
            return (
                     request.UserStatuses != null &&
                     request.UserStatuses.Any() &&
                     request.UserStatuses.All(s => !string.IsNullOrWhiteSpace(s))
                   );
        }

        private bool IsRequest_OrderTypesHasValues(MaintenanceOrderSearchQuery request)
        {
            return (
                     request.OrderTypes != null &&
                     request.OrderTypes.Any() &&
                     request.OrderTypes.All(s => !string.IsNullOrWhiteSpace(s))
                   );
        }

        private bool IsRequest_WorkCentersHasValues(MaintenanceOrderSearchQuery request)
        {
            return (
                     request.WorkCenters != null &&
                     request.WorkCenters.Any() &&
                     request.WorkCenters.All(s => !string.IsNullOrWhiteSpace(s))
                   );
        }

        private bool IsRequest_PrioritiesHasValues(MaintenanceOrderSearchQuery request)
        {
            return (
                     request.Priorities != null &&
                     request.Priorities.Any() &&
                     request.Priorities.All(s => !string.IsNullOrWhiteSpace(s))
                   );
        }

        private async Task<MaintenanceOrderSearchResult> BuildOrderSchedule(List<WorkOrder> workOrders, int totalRecordCount, int page, int pageSize)
        {
            return await Task.Run(() =>
            {
                var maintenanceOrderSearchResultData = workOrders.Select(x => new MaintenanceOrderSearchResultData
                {
                    Id = x.Id,
                    EndDate = x.BasicFinishDate,
                    FunctionalLocation = x.FunctionalLocation,
                    IsActive = x.IsActive,
                    MainWorkCenter = x.MainWorkCenter,
                    OrderDescription = x.OrderDescription,
                    OrderNumber = x.OrderNumber,
                    OrderType = x.OrderType,
                    Priority = x.Priority,
                    StartDate = x.BasicStartDate,
                    SystemStatus = x.SystemStatus,
                    UserStatus = x.UserStatus,
                    OrderScheduleStartDate = (x.OrderSchedule != null && x.OrderSchedule.Any() && x.OrderSchedule.All(x => x.ScheduleStartDate.HasValue)) ?
                    x.OrderSchedule.First().ScheduleStartDate.Value : null,
                    OrderScheduleEndDate = (x.OrderSchedule != null && x.OrderSchedule.Any() && x.OrderSchedule.All(x => x.ScheduleEndDate.HasValue)) ?
                    x.OrderSchedule.First().ScheduleEndDate.Value : null,
                    WeeklySchedule = (x.OrderSchedule != null && x.OrderSchedule.Any() && x.OrderSchedule.All(x => x.ScheduleStartDate.HasValue && x.ScheduleEndDate.HasValue)) ?
                    _mapper.Map<List<OrderWeekSchedule>>(_weekCalculator.GetWeeks(x.OrderSchedule.First().ScheduleStartDate.Value, x.OrderSchedule.First().ScheduleEndDate.Value).Result) : null
                }).ToList();

                var maintenanceOrderSearchResult = new MaintenanceOrderSearchResult
                {
                    Data = new List<MaintenanceOrderSearchResultData>(maintenanceOrderSearchResultData),
                    Page = page,
                    PageSize = pageSize,
                    TotalRecords = totalRecordCount
                };

                return maintenanceOrderSearchResult;
            });
        }

        private async Task FillWorkOrderOperationDetails(List<MaintenanceOrderSearchResultData> maintenanceOrderSearchResultDataList)
        {
            await Parallel.ForEachAsync(maintenanceOrderSearchResultDataList, async (maintenanceOrderSearchResult, cancellationToken) =>
            {
                try
                {
                    var orderOperations = await _sapHttpClientProxy.GetWorkOrderOperation(maintenanceOrderSearchResult.OrderNumber.Trim());
                    if (orderOperations != null && orderOperations.Any())
                    {
                        var orderOperation = orderOperations.FirstOrDefault(x => x.OpreationNumber == "0010");
                        maintenanceOrderSearchResult.PlannedWork = orderOperation?.PlannedWork?.Trim();
                        maintenanceOrderSearchResult.UnitforWork = orderOperation?.UnitForWork?.Trim();
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, ex.Message);
                }
            });
        }

        private async Task FillResourceWeeklyAvailability(List<MaintenanceOrderSearchResultData> maintenanceOrderSearchResultDataList, Guid teamId)
        {
            foreach (var searchResult in maintenanceOrderSearchResultDataList)
            {
                var weeklyAvailabilityQuery = new MaintenanceOrderWeeklyAvailabilityQuery
                {
                    TeamId = teamId,
                    StartDate = DateTime.Now,
                    EndDate = CultureInfo.CurrentCulture.Calendar.AddWeeks(DateTime.Now, 6)
                };

                var weeklyAvailabilityQueryResponse = await _mediator.Send(weeklyAvailabilityQuery);
                searchResult.AvailableHours = weeklyAvailabilityQueryResponse;
            }
        }
    }
}
