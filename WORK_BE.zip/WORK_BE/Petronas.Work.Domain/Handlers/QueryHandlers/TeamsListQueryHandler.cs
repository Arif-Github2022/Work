﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Petronas.Work.Data.Entities.dbo;
using Petronas.Work.Data.Infrastructure.Interface;
using Petronas.Work.Domain.Models;
using Petronas.Work.Domain.Queries;

namespace Petronas.Work.Domain.Handlers.QueryHandlers
{
    public class TeamsListQueryHandler : BaseHandler, IRequestHandler<TeamsListGetQuery, List<TeamsListQueryResult>>
    {

        private readonly IMapper _mapper;
        private readonly ILogger<TeamsListQueryHandler> _logger;

        public TeamsListQueryHandler(IWorkDbUnitOfWork unitOfWork, IMapper mapper, ILogger<TeamsListQueryHandler> logger) : base(unitOfWork)
        {
            _mapper = mapper;
            _logger = logger;
           
        }
        public async Task<List<TeamsListQueryResult>> Handle(TeamsListGetQuery request, CancellationToken cancellationToken)
        {
            _logger.LogInformation($"Handler Call : {nameof(TeamsListQueryHandler)} Started");
            var teams = await UnitOfWork.TeamRepository.GetQuery()
                 .Where(x => x.Name != null).ToListAsync();
            var teamList = await BuildTeamList(teams);
            return teamList;
        }
        private async Task<List<TeamsListQueryResult>> BuildTeamList(List<Team> workOrders)
        {
            var result = workOrders.Select(x => new TeamsListQueryResult
            {
                Id = x.Id,
                Name = x.Name,
                Description = x.Description
            }).ToList();
            _logger.LogInformation($"Handler Call : {nameof(TeamsListQueryHandler)} Completed");
            return result;
        }
    }
}
