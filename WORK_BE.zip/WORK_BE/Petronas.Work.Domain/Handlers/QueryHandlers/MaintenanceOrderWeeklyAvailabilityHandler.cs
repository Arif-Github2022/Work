﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Petronas.Work.Core.Model;
using Petronas.Work.Core.Utilities;
using Petronas.Work.Data.Entities.dbo;
using Petronas.Work.Data.Infrastructure.Interface;
using Petronas.Work.Domain.Models;
using Petronas.Work.Domain.Queries;


namespace Petronas.Work.Domain.Handlers.QueryHandlers
{
    public class MaintenanceOrderWeeklyAvailabilityHandler : BaseHandler, IRequestHandler<MaintenanceOrderWeeklyAvailabilityQuery, List<MaintenanceOrderWeeklyAvailabilityQueryResult>>
    {
        private readonly IMapper _mapper;
        private readonly ILogger<MaintenanceOrderWeeklyAvailabilityHandler> _logger;
        private readonly WeekCalculator _weekCalculator;

        public MaintenanceOrderWeeklyAvailabilityHandler(IWorkDbUnitOfWork unitOfWork, IMapper mapper
            , WeekCalculator weekCalculator, ILogger<MaintenanceOrderWeeklyAvailabilityHandler> logger) : base(unitOfWork)
        {
            _mapper = mapper;
            _logger = logger;
            _weekCalculator = weekCalculator;
        }

        public async Task<List<MaintenanceOrderWeeklyAvailabilityQueryResult>> Handle(MaintenanceOrderWeeklyAvailabilityQuery request, CancellationToken cancellationToken)
        {
            _logger.LogInformation($"Handler Call : {nameof(MaintenanceOrderWeeklyAvailabilityHandler)}");

            List<MaintenanceOrderWeeklyAvailabilityQueryResult> result = new();

            var roleTechnician = await UnitOfWork.RoleRepository.GetQuery()
                .Where(x => x.Name != null && x.Name.ToLower().Equals(Core.Constants.Role.Technician)).FirstOrDefaultAsync();

            var teamResources = await UnitOfWork.ResourceTeamRepository.GetQuery()
                .Include(nameof(Resource))
                .Include($"{nameof(Resource)}.{nameof(ResourceRole)}")
                .Include($"{nameof(Resource)}.{nameof(Data.Entities.dbo.ResourceSchedule)}")
                .Include($"{nameof(Resource)}.{nameof(DefaultResourceWorkPlan)}")
                .Where(t => t.TeamId == request.TeamId && t.IsActive == true && t.Resource.ResourceRole.Any(r => r.RoleId == roleTechnician.Id))
                .ToListAsync();

            if (teamResources != null && teamResources.Any())
            {
                DateTime currentDate = request.StartDate;
                while (currentDate.Date <= request.EndDate.Date)
                {
                    int availableHours = 0;
                    int plannedHours = 0;
                    int unavailableHours = 0;

                    if (currentDate.DayOfWeek != DayOfWeek.Saturday || currentDate.DayOfWeek != DayOfWeek.Sunday)
                    {
                        teamResources.ForEach((teamResource) =>
                        {
                            if (teamResource.Resource != null)
                            {
                                if (teamResource.Resource.DefaultResourceWorkPlan != null && teamResource.Resource.DefaultResourceWorkPlan.Any())
                                {
                                    availableHours += CalculateAndGetAvailableHours(currentDate.Date, teamResource.Resource.DefaultResourceWorkPlan.ToList());
                                    if (teamResource.Resource.ResourceSchedule != null && teamResource.Resource.ResourceSchedule.Any())
                                    {
                                        plannedHours += CalculateAndGetPlannedHours(currentDate.Date, teamResource.Resource.ResourceSchedule.ToList(), teamResource.Resource.DefaultResourceWorkPlan.ToList());

                                    }
                                }
                                if (teamResource.Resource.ResourceCapacity != null && teamResource.Resource.ResourceCapacity.Any())
                                {
                                    unavailableHours += CalculateAndGetUnavailableHours(currentDate.Date, teamResource.Resource.ResourceCapacity.ToList());
                                }
                            }
                        });
                        var netAvailableHours = availableHours - (plannedHours + unavailableHours);
                        result.Add(new MaintenanceOrderWeeklyAvailabilityQueryResult
                        {
                            AvailableHours = netAvailableHours < 0 ? 0 : netAvailableHours,
                            Date = currentDate
                        });
                    }
                    currentDate = currentDate.AddDays(1);
                }

                _logger.LogInformation($"Handler Call : {nameof(MaintenanceOrderWeeklyAvailabilityHandler)} Completed");
            }
            return result;
        }

        private int CalculateAndGetAvailableHours(DateTime currentDate, List<DefaultResourceWorkPlan> defaultResourceWorkPlanList)
        {
            int availableHours = 0;
            if (defaultResourceWorkPlanList != null && defaultResourceWorkPlanList.Any())
            {
                var resourceWorkPlan = defaultResourceWorkPlanList.Find(x => !string.IsNullOrWhiteSpace(x.WeekDay) && Enum.TryParse<DayOfWeek>(x.WeekDay, out _) && Enum.Parse<DayOfWeek>(x.WeekDay) == currentDate.DayOfWeek);

                if (resourceWorkPlan != null)
                {
                    availableHours += resourceWorkPlan.WorkHours;
                }
            }
            return availableHours;
        }

        private int CalculateAndGetPlannedHours(DateTime currentDate, List<Data.Entities.dbo.ResourceSchedule> ResourceScheduleList, List<DefaultResourceWorkPlan> defaultResourceWorkPlanList)
        {
            int plannedHours = 0;
            if (ResourceScheduleList != null && ResourceScheduleList.Any())
            {
                var defaultResourceWorkPlan = defaultResourceWorkPlanList.Find(x => !string.IsNullOrWhiteSpace(x.WeekDay) && Enum.TryParse<DayOfWeek>(x.WeekDay, out _) && Enum.Parse<DayOfWeek>(x.WeekDay) == currentDate.DayOfWeek);
                var plannedSchedule = ResourceScheduleList.Find(x => x.PlannedDate.Value.Date == currentDate.Date);

                if (plannedSchedule != null && plannedSchedule.PlannedWorkHours.HasValue)
                {
                    // Remove overtime
                    if (defaultResourceWorkPlan != null && plannedSchedule.PlannedWorkHours.Value > defaultResourceWorkPlan.WorkHours)
                    {
                        plannedHours += defaultResourceWorkPlan.WorkHours;
                    }
                    else
                    {
                        plannedHours += plannedSchedule.PlannedWorkHours.Value;
                    }
                }
            }
            return plannedHours;
        }

        private int CalculateAndGetUnavailableHours(DateTime currentDate, List<ResourceCapacity> resourceCapacityList)
        {
            int unavailableHours = 0;
            if (resourceCapacityList != null && resourceCapacityList.Any())
            {
                var resourceCapacity = resourceCapacityList.Find(x => x.Day.Value.Date == currentDate.Date);

                if (resourceCapacity != null && resourceCapacity.AwayHours.HasValue)
                {
                    unavailableHours += resourceCapacity.AwayHours.Value;
                }
            }
            return unavailableHours;
        }
    }
}
