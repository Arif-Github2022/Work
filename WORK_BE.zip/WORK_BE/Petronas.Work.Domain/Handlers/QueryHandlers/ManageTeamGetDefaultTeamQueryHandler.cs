﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Petronas.Work.Data.Entities.dbo;
using Petronas.Work.Data.Infrastructure.Interface;
using Petronas.Work.Domain.Models;
using Petronas.Work.Domain.Queries;

namespace Petronas.Work.Domain.Handlers.QueryHandlers
{
    public class ManageTeamGetDefaultTeamQueryHandler : BaseHandler, IRequestHandler<ManageTeamGetDefaultTeamQuery, List<ManageTeamGetDefaultTeamQueryResult>>
    {
        private readonly IMapper _mapper;
        private readonly ILogger<ManageTeamGetDefaultTeamQueryHandler> _logger;

        public ManageTeamGetDefaultTeamQueryHandler(IWorkDbUnitOfWork unitOfWork, IMapper mapper, ILogger<ManageTeamGetDefaultTeamQueryHandler> logger) : base(unitOfWork)
        {
            _mapper = mapper;
            _logger = logger;
        }

        public async Task<List<ManageTeamGetDefaultTeamQueryResult>> Handle(ManageTeamGetDefaultTeamQuery request, CancellationToken cancellationToken)
        {
            List<ManageTeamGetDefaultTeamQueryResult> result = new();
            var roleTechnician = await UnitOfWork.RoleRepository.GetQuery()
                   .Where(x => x.Name != null && x.Name.ToLower().Equals(Core.Constants.Role.Technician)).FirstOrDefaultAsync();
            var teamResources = await UnitOfWork.ResourceTeamRepository.GetQuery()
                                   .Include(nameof(Resource))
                                   .Include($"{nameof(Resource)}.{nameof(ResourceTeam)}")
                                   .Include($"{nameof(Resource)}.{nameof(ResourceRole)}")
                                   .Include($"{nameof(Resource)}.{nameof(DefaultResourceWorkPlan)}")
                                   .Where(t => t.TeamId == request.TeamId && t.IsActive==true && t.Resource.ResourceRole.Any(r => r.RoleId == roleTechnician.Id))
                                   .ToListAsync();
            if (teamResources != null && teamResources.Any())
            {
                teamResources.ToList().OrderBy(x=>x.Resource.Name).ToList().ForEach((teamResource) =>
                {
                    if (teamResource.Resource != null)
                    {
                       
                        if (teamResource.Resource.DefaultResourceWorkPlan != null && teamResource.Resource.DefaultResourceWorkPlan.Any())
                        {
                            var listResources = teamResource.Resource.DefaultResourceWorkPlan.ToList();
                            var dayOfWeekList = Enumerable.Range(0, Enum.GetNames(typeof(DayOfWeek)).Length)
                                                .Select(i => (DayOfWeek)i)
                                                .OrderBy(x => ((int)x + 6) % 7)
                                                .Select(i => i.ToString("G").ToLower())
                                                .ToList();
                            var manageTeamGetDefaultTeamQueryResult = new ManageTeamGetDefaultTeamQueryResult
                            {
                                TeamDefaultWorkHours = listResources.Select(x => new ManageTeamDetails
                                {
                                    ResourceId = x.ResourceId,
                                    ResourceName = x.Resource.Name,
                                    ResourceAceId = x.Resource.AceId,
                                    ResourceCompany = x.Resource.Company,
                                    IsResourceContractor = x.Resource.IsContractor,
                                    WorkHours = x.WorkHours,
                                    WeekDay = x.WeekDay,
                                }).ToList().OrderBy(x => dayOfWeekList.IndexOf(x.WeekDay.ToLower())).ToList(),

                            };
                            result.Add(manageTeamGetDefaultTeamQueryResult);
                        }
                    }
                });
            }
           
            return result;
        }
    }
}