﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Petronas.Work.Data.Entities.dbo;
using Petronas.Work.Data.Infrastructure.Interface;
using Petronas.Work.Domain.Models;
using Petronas.Work.Domain.Queries;

namespace Petronas.Work.Domain.Handlers.QueryHandlers
{
    public class GetInternalTeamResourcesQueryHandler : BaseHandler, IRequestHandler<GetInternalTeamResourcesQuery, List<GetTeamResourcesQueryResult>>
    {
        private readonly IMapper _mapper;
        private readonly ILogger<GetInternalTeamResourcesQueryHandler> _logger;

        public GetInternalTeamResourcesQueryHandler(IWorkDbUnitOfWork unitOfWork, IMapper mapper, ILogger<GetInternalTeamResourcesQueryHandler> logger) : base(unitOfWork)
        {
            _mapper = mapper;
            _logger = logger;

        }
        public async Task<List<GetTeamResourcesQueryResult>> Handle(GetInternalTeamResourcesQuery request, CancellationToken cancellationToken)
        {
            _logger.LogInformation($"Handler Call : {nameof(GetCurrentTeamResourcesQueryHandler)} Started");
            var roleTechnician = await UnitOfWork.RoleRepository.GetQuery()
                .Where(x => x.Name != null && x.Name.ToLower().Equals(Core.Constants.Role.Technician)).FirstOrDefaultAsync();

            var teamResources = await UnitOfWork.ResourceTeamRepository.GetQuery()
                .Include(nameof(Resource))
                .Include($"{nameof(Resource)}.{nameof(ResourceTeam)}")
                .Where(t => t.TeamId != request.TeamId && t.IsActive == true && t.Resource.ResourceRole.Any(r => r.RoleId == roleTechnician.Id))
                .ToListAsync();

            var teamList = await BuildTeamList(teamResources);
            return teamList;
        }

        private async Task<List<GetTeamResourcesQueryResult>> BuildTeamList(List<ResourceTeam> resources)
        {
            var result = resources.Select(x => new GetTeamResourcesQueryResult
            {
                ResourceId = x.Resource.Id,
                Name = x.Resource.Name,
                Company = x.Resource.Company,
                AceId = x.Resource.AceId,
                IsContractor = x.Resource.IsContractor
            }).ToList();
            _logger.LogInformation($"Handler Call : {nameof(GetInternalTeamResourcesQueryHandler)} Completed");
            return result;
        }
    }
}
