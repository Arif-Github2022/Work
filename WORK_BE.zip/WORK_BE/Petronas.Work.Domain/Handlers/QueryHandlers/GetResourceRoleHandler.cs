﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Petronas.Work.Core.Utilities;
using Petronas.Work.Data.Entities.dbo;
using Petronas.Work.Data.Infrastructure.Interface;
using Petronas.Work.Domain.Models;
using Petronas.Work.Domain.Queries;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Domain.Handlers.QueryHandlers
{
    public class ResourceRoleHandler : BaseHandler, IRequestHandler<RoleListGetQuery, List<RoleListGetQuery>>
    {
     

            private readonly IMapper _mapper;
        private readonly ILogger<ResourceRoleHandler> _logger;

        public ResourceRoleHandler(IWorkDbUnitOfWork unitOfWork, IMapper mapper, ILogger<ResourceRoleHandler> logger) : base(unitOfWork)
        {
            _mapper = mapper;
            _logger = logger;

        }

        //public Task<List<RoleListGetQuery>> Handle(RoleListGetQuery request, CancellationToken cancellationToken)
        //{
        //    throw new NotImplementedException();
        //}
        public async Task<List<RoleListGetQuery>> Handle(RoleListGetQuery request, CancellationToken cancellationToken)
        {
            _logger.LogInformation($"Handler Call : {nameof(ResourceRoleResult)} Started");
            return _mapper.Map<List<RoleListGetQuery>>(await UnitOfWork.ResourceRoleRepositoryNew.GetQuery().ToListAsync());

        }
        private async Task<List<ResourceRoleResult>> BuildTeamList(List<Role> workOrders)
        {
            var result = workOrders.Select(x => new ResourceRoleResult
            {
                Id = x.Id,
                Name = x.Name,
                IsActive = x.IsActive
            }).ToList();
            _logger.LogInformation($"Handler Call : {nameof(ResourceRoleResult)} Completed");
            return result;
        }
    }
}
