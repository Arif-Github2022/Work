﻿using Petronas.Work.Data.Infrastructure.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Petronas.Work.Domain.Handlers
{
    public abstract class BaseHandler
    {
        private readonly IWorkDbUnitOfWork _unitOfWork;

        protected BaseHandler(IWorkDbUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        protected IWorkDbUnitOfWork UnitOfWork { get { return _unitOfWork; } }
        
        protected string? TraceId { get; set; }
    }
}
