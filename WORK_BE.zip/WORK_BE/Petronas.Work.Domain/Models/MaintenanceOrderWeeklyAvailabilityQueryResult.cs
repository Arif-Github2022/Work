﻿namespace Petronas.Work.Domain.Models
{
    public class MaintenanceOrderWeeklyAvailabilityQueryResult
    {  
        public int AvailableHours { get; set; }
        public DateTime Date { get; set; }
    }

}
