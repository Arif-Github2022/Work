﻿namespace Petronas.Work.Domain.Models
{
    public class ResourceInformation
    {
        public Guid ResourceId { get; set; }

        public string? ResourceName { get; set; }

        public string? ResourceCompany { get; set; }

        public bool IsResourceContractor { get; set; }

        public Guid ResourceAceId { get; set; }
    }
}
