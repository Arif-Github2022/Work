﻿namespace Petronas.Work.Domain.Models
{
    public class ScheduledOrderInfo
    {
        public Guid WorkOrderId { get; set; }
        public string OrderDescription { get; set; }
        public DateTime OrderStartDate { get; set; }
        public DateTime OrderEndDate { get; set; }
        public string OrderNumber { get; set; }
        public string OrderType { get; set; }
        public string FunctionalLocation { get; set; }
        public string? PlannedWork { get; set; }
        public string? UnitforWork { get; set; }
        public int Priority { get; set; }
        public int TotalActualHours { get; set; }
        public int TotalplannedHours { get; set; }
        public int TotalAwayHours { get; set; }
        public int TotalOvertimeHours { get; set; }
        public List<ResourceScheduleInfo> ResourceSchedule { get; set; }
    }
}
