﻿namespace Petronas.Work.Domain.Models
{
    public class GetResourceScheduleQueryResult
    {
        public Guid TeamID { get; set; }
        public DateTime WeekStartDate { get; set; }
        public DateTime WeekEndDate { get; set; }

        public List<ScheduledOrderInfo>? ScheduledOrder { get; set; }
    }
}
