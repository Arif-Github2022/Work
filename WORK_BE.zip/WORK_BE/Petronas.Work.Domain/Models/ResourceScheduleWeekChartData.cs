﻿namespace Petronas.Work.Domain.Models
{
    public class ResourceScheduleWeekChartData
    {
        public Guid ResourceId { get; set; }

        public string? ResourceName { get; set; }

        public int AvailableHours { get; set; }

        public int TotalActualHours { get; set; }

        public int TotalActualAvailableHours { get; set; }

        public int AssignedHours { get; set; }

        public int AssignedOvertimeHours { get; set; }

        public int ActualOvertimeHours { get; set; }

        public int UnavailableHours { get; set; }

        public int ActualUnavailableHours { get; set; }
    }
}

