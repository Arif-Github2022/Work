﻿namespace Petronas.Work.Domain.Models
{
    public class TeamsListQueryResult
    {
        public Guid Id { get; set; }

        public string? Name { get; set; }

        public string? Description { get; set; }
    }

    public class RoleListGetQueryResult
    {
        public Guid Id { get; set; }

        public string? Name { get; set; }

        public bool? isActive { get; set; }
    }
    
}
