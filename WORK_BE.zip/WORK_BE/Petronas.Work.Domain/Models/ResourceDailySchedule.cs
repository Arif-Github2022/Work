﻿namespace Petronas.Work.Domain.Models
{
    public class ResourceDailySchedule
    {
        public int ActualHours { get; set; }
        public int AwayHours { get; set; }
        public int PlannedHours { get; set; }
        public int OvertimeHours { get; set; }
        public DateTime WeekDay { get; set; }
        public string WeekDayName { get; set; }
    }
}
