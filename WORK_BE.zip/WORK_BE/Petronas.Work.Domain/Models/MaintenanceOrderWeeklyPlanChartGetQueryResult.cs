﻿namespace Petronas.Work.Domain.Models
{
    public class MaintenanceOrderWeeklyPlanChartGetQueryResult
    {
        public int WeekNumber { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public bool IsCurrentWeek { get; set; }

        public int AvailableHours { get; set; }

        public int AssignedHours { get; set; }

        public int OvertimeHours { get; set; }

        public int UnavailableHours { get; set; }
    }
}
