﻿namespace Petronas.Work.Domain.Models
{
    public class ResourceScheduleInfo
    {
        public Guid ResourceId { get; set; }
        public string ResourceName { get; set; }
        public string ResourceCompany { get; set; }
        public string ResourceAceId { get; set; }
        public bool IsResourceContractor { get; set; }
        public List<ResourceDailySchedule> DailySchedule { get; set; }
    }
}
