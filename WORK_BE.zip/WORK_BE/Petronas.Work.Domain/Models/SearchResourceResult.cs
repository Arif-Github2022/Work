﻿namespace Petronas.Work.Domain.Models
{
    public class SearchResourceResult
    {
        public List<ResourceInformation>? Resources { get; set; }
    }
}
