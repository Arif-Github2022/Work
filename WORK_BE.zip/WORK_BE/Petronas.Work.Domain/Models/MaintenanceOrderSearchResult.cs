﻿namespace Petronas.Work.Domain.Models
{
    public class MaintenanceOrderSearchResult
    {
        public List<MaintenanceOrderSearchResultData>? Data { get; set; }

        public int Page { get; set; }

        public int PageSize { get; set; }

        public int TotalRecords { get; set; }
    }

    public class MaintenanceOrderSearchResultData
    {
        public string? FunctionalLocation { get; set; }

        public Guid Id { get; set; } = Guid.Empty;

        public bool? IsActive { get; set; }

        public string? MainWorkCenter { get; set; }

        public string? OrderDescription { get; set; }

        public string? OrderNumber { get; set; }

        public string? OrderType { get; set; }

        public string? Priority { get; set; }

        public string? SystemStatus { get; set; }

        public string? UserStatus { get; set; }

        public List<OrderWeekSchedule>? WeeklySchedule { get; set; }

        public DateTime? OrderScheduleStartDate { get; set; }

        public DateTime? OrderScheduleEndDate { get; set; }

        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }

        public string? PlannedWork { get; set; }

        public string? UnitforWork { get; set; }

        public List<MaintenanceOrderWeeklyAvailabilityQueryResult>? AvailableHours { get; set; }
    }
}
