﻿namespace Petronas.Work.Domain.Models
{
    public class OrderWeekSchedule
    {
        public int WeekNumber { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }
    }
}
