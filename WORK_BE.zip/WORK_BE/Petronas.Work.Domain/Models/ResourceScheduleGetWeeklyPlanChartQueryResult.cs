﻿namespace Petronas.Work.Domain.Models
{
    public class ResourceScheduleGetWeeklyPlanChartQueryResult
    {
        public List<WeekChartData>? WeekChartDataList { get; set; }
    }
}

