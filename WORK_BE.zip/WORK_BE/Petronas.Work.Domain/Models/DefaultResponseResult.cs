﻿namespace Petronas.Work.Domain.Models
{
    public class DefaultResponseResult
    {
        public string? TraceId { get; set; }
        
        public string? Message { get; set; }

        public bool IsError { get; set; }
    }
}
