﻿namespace Petronas.Work.Integration.Sap.ResponseModels
{
    public class WorkOrderOperation
    {
        public string? OrderNumber { get; set; }
        public string? OpreationNumber { get; set; }
        public string? SubOpreation { get; set; }
        public string? ControlKey { get; set; }
        public string? WorkCente { get; set; }
        public string? WorkCenterPlant { get; set; }
        public string? OperationDescription { get; set; }
        public string? SystemStatus { get; set; }
        public string? PlannedWork { get; set; }
        public string? UnitForWork { get; set; }
        public string? Duration { get; set; }
        public string? UnitForDuration { get; set; }
        public string? NumberOfPerson { get; set; }
        public string? ActualStartDate { get; set; }
        public string? ActualFinishDate { get; set; }
        public string? ActualWork { get; set; }
        public string? ScheduledStartDate { get; set; }
        public string? ScheduledFinishDate { get; set; }
    }
}
