﻿namespace Petronas.Work.Integration.Sap.ResponseModels
{
    public class GetWorkOperationsResponse
    {
        public List<WorkOrderOperation>? OperationList { get; set; }
    }
}
