﻿namespace Petronas.Work.Integration.Sap.ResponseModels
{
    public class GetWorkOrdersResponseHeader
    {
        public string? ResponseStatus { get; set; }
        public string? Id { get; set; }
        public string? Number { get; set; }
        public string? Message { get; set; }
        public string? LogNo { get; set; }
        public string? LogMsgNo { get; set; }
        public string? MessageV1 { get; set; }
        public string? MessageV2 { get; set; }
        public string? MessageV3 { get; set; }
        public string? Parameter { get; set; }
        public string? Field { get; set; }
        public string? Row { get; set; }
        public string? System { get; set; }
        public string? RefNo { get; set; }
        public string? ObjectNo { get; set; }
    }
}
