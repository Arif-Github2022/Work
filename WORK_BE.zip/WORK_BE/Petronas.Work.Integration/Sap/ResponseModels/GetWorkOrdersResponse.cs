﻿namespace Petronas.Work.Integration.Sap.ResponseModels
{
    public class GetWorkOrdersResponse
    { 
        public GetWorkOrdersResponseHeader Header { get; set; }

        public List<WorkOrder> WorkOrderList { get; set; }

        public string TotalRecords { get; set; }
    }
}
