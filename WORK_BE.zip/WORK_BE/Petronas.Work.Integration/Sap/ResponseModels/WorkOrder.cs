﻿namespace Petronas.Work.Integration.Sap.ResponseModels
{
    public class WorkOrder
    {
        public string? OrderNumber { get; set; }
        public string? OrderType { get; set; }
        public string? WorkOrderDescription { get; set; }
        public string? DefectCode { get; set; }
        public string? MaintenancePlant { get; set; }
        public string? MaintenancePlanningPlant { get; set; }
        public string? LocationOfMaintObject { get; set; }
        public string? SystemStatus { get; set; }
        public string? UserStatus { get; set; }
        public string? PlannerGroup { get; set; }
        public string? MainWorkCenter { get; set; }
        public string? MainWorkCenterPlant { get; set; }
        public string? MaintenanceActivityType { get; set; }
        public string? NotificationNo { get; set; }
        public string? BasicStartDate { get; set; }
        public string? BasicFinishDate { get; set; }
        public string? ScheduledStartDate { get; set; }
        public string? ScheduledFinishDate { get; set; }
        public string? ActualStartDate { get; set; }
        public string? ActualFinishDate { get; set; }
        public string? Priority { get; set; }
        public string? FunctionalLocation { get; set; }
        public string? DescriptionOfFunctionalLocation { get; set; }
        public string? EquipmentNumber { get; set; }
        public string? DescriptionOfEquipment { get; set; }
        public string? SuperiorOrder { get; set; }
        public string? PlannedCost { get; set; }
        public string? ActualCost { get; set; }
        public string? Wbs { get; set; }
        public string? ChangedOn { get; set; }
        public string? CreatedOn { get; set; }
        public string? ScheduledStartTime { get; set; }
        public string? ScheduledFinishTime { get; set; }
    }
}
