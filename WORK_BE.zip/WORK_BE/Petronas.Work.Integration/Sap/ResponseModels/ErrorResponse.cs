﻿namespace Petronas.Work.Integration.Sap.ResponseModels
{
    public class ErrorResponse
    {
        public string? ErrorCode { get; set; }
        public string? ErrorMessage { get; set; }
        public string? TransactionId { get; set; }
        public DateTime? TimeStamp { get; set; }
    }
}
