﻿namespace Petronas.Work.Integration.Sap.Constants
{
    public struct RequestFilters
    {
        public struct GetWorkOrdersRequestFilter
        {
            public const string System = "30";

            public struct CompanyCodeFilter
            {
                public const string CompanyCode = "0004";
                public const string Sign = "I";
                public const string Option = "EQ";
            }

            public struct PlantFilter
            {
                public const string Plant = "M060";
                public const string Sign = "I";
                public const string Option = "EQ";
            }

            public struct StatusExcludedFilter
            {
                public const string Status = "TECO";
                public const string Sign = "I";
                public const string Option = "EQ";
            }

            public struct DateFilter
            {
                public const string Sign = "I";
                public const string Option = "BT";
            }
        }

        public struct GetWorkOperationsRequestFilter
        {
            public const string System = "P30";
            public const string Sign = "I";
            public const string Option = "EQ";
        }
    }
}
