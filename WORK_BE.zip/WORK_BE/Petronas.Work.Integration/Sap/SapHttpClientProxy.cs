﻿using Petronas.Work.Integration.Sap.Configuration;
using Petronas.Work.Integration.Sap.Constants;
using Petronas.Work.Integration.Sap.Interface;
using Petronas.Work.Integration.Sap.RequestModels;
using Petronas.Work.Integration.Sap.ResponseModels;
using Petronas.Work.Integration.WebClient.Interface;
using System.Collections.Specialized;
using System.Text.Json;

namespace Petronas.Work.Integration.Sap
{
    public class SapHttpClientProxy : ISapHttpClientProxy
    {
        private readonly Settings _settings;
        private readonly IHttpClientProxy _httpClientProxy;

        public SapHttpClientProxy(Settings settings, IHttpClientProxy httpClientProxy)
        {
            _settings = settings;
            _httpClientProxy = httpClientProxy;
        }

        public async Task<List<WorkOrderOperation>> GetWorkOrderOperation(string orderNumber)
        {
            List<WorkOrderOperation> workOrderOperations = new List<WorkOrderOperation>();


            var getGetWorkOperationsRequest = new GetWorkOperationsRequest
            {
                System = RequestFilters.GetWorkOperationsRequestFilter.System,
                OrderId = new List<StringFilter>
                {
                    new StringFilter
                    {
                        Value = orderNumber,
                        Sign = RequestFilters.GetWorkOperationsRequestFilter.Sign,
                        Option = RequestFilters.GetWorkOperationsRequestFilter.Option
                    }
                }
            };

            var httpCustomHeaders = new NameValueCollection
            {
                { "client_id", _settings.ClientId },
                { "client_secret", _settings.ClientSecret }
            };

            var response = await _httpClientProxy.PostAsync<GetWorkOperationsRequest, string>(getGetWorkOperationsRequest, _settings.BaseUri, _settings.SapGetWorkOperationsResourceUri, httpCustomHeaders);

            if (response.Contains("errorCode"))
            {
                throw new Exception(response.ToString());
            }

            var responseObject = JsonSerializer.Deserialize<GetWorkOperationsResponse>(response, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

            if (responseObject != null && responseObject.OperationList != null && responseObject.OperationList.Any())
            {
                var workOperations = responseObject.OperationList;
                if (workOperations != null)
                {
                    workOrderOperations.AddRange(workOperations);
                }
            }

            return workOrderOperations;
        }

        public async Task<List<WorkOrder>> GetWorkOrders(DateTime fromDate, DateTime toDate)
        {
            var getWorkOrdersRequest = new GetWorkOrdersRequest
            {
                System = RequestFilters.GetWorkOrdersRequestFilter.System,
                CompanyCode = new List<StringFilter>
                {
                    new StringFilter
                    {
                        Value = RequestFilters.GetWorkOrdersRequestFilter.CompanyCodeFilter.CompanyCode,
                        Sign = RequestFilters.GetWorkOrdersRequestFilter.CompanyCodeFilter.Sign,
                        Option = RequestFilters.GetWorkOrdersRequestFilter.CompanyCodeFilter.Option
                    }
                },
                Plant = new List<StringFilter>
                {
                    new StringFilter
                    {
                        Value = RequestFilters.GetWorkOrdersRequestFilter.PlantFilter.Plant,
                        Sign = RequestFilters.GetWorkOrdersRequestFilter.PlantFilter.Sign,
                        Option = RequestFilters.GetWorkOrdersRequestFilter.PlantFilter.Option
                    }
                },
                CreatedOn = new List<DateFilter>
                {
                    new DateFilter
                    {
                        FromDate = DateOnly.FromDateTime(fromDate).ToString("yyyy-MM-dd"),
                        ToDate = DateOnly.FromDateTime(toDate).ToString("yyyy-MM-dd"),
                        Sign = RequestFilters.GetWorkOrdersRequestFilter.DateFilter.Sign,
                        Option = RequestFilters.GetWorkOrdersRequestFilter.DateFilter.Option
                    }
                },
                StatusExcluded = new List<StringFilter>
                {
                    new StringFilter
                    {
                        Value = RequestFilters.GetWorkOrdersRequestFilter.StatusExcludedFilter.Status,
                        Sign = RequestFilters.GetWorkOrdersRequestFilter.StatusExcludedFilter.Sign,
                        Option = RequestFilters.GetWorkOrdersRequestFilter.StatusExcludedFilter.Option
                    }
                }
            };

            var httpCustomHeaders = new NameValueCollection
            {
                { "client_id", _settings.ClientId },
                { "client_secret", _settings.ClientSecret }
            };

            var response = await _httpClientProxy.PostAsync<GetWorkOrdersRequest, string>(getWorkOrdersRequest, _settings.BaseUri, _settings.SapGetWorkOrdersResourceUri, httpCustomHeaders);

            if (response.Contains("errorCode"))
            {
                throw new Exception(response);
            }

            var responseObject = JsonSerializer.Deserialize<GetWorkOrdersResponse>(response, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

            if (responseObject != null)
            {
                return responseObject.WorkOrderList ?? new List<WorkOrder>();
            }
            else
            {
                return new List<WorkOrder>();
            }
        }
    }
}
