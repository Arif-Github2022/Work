﻿using Petronas.Work.Integration.Sap.ResponseModels;

namespace Petronas.Work.Integration.Sap.Interface
{
    public interface ISapHttpClientProxy
    {
        public Task<List<WorkOrder>> GetWorkOrders(DateTime fromDate, DateTime toDate);

        public Task<List<WorkOrderOperation>> GetWorkOrderOperation(string orderNumber);
    }
}
