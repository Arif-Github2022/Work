﻿namespace Petronas.Work.Integration.Sap.RequestModels
{
    public class StringFilter
    {
        public string? Value { get; set; }

        public string? Sign { get; set; }

        public string? Option { get; set; }
    }
}
