﻿namespace Petronas.Work.Integration.Sap.RequestModels
{
    public class DateFilter
    {
        public string? FromDate { get; set; }

        public string? ToDate { get; set; }

        public string? Sign { get; set; }

        public string? Option { get; set; }
    }
}
