﻿namespace Petronas.Work.Integration.Sap.RequestModels
{
    public class GetWorkOperationsRequest
    {
        public string? System { get; set; }

        public List<StringFilter>? OrderId { get; set; }
    }
}
