﻿namespace Petronas.Work.Integration.Sap.RequestModels
{
    public class GetWorkOrdersRequest
    {
        public string? System { get; set; }

        public List<StringFilter>? CompanyCode { get; set; }

        public List<StringFilter>? Plant { get; set; }

        public List<DateFilter>? CreatedOn { get; set; }

        public List<StringFilter>? StatusExcluded { get; set; }
    }
}
