﻿namespace Petronas.Work.Integration.Sap.Configuration
{
    public class Settings
    {
        public string ClientId { get; private set; }

        public string ClientSecret { get; private set; }

        public Uri BaseUri { get; private set; }

        public Uri SapGetWorkOrdersResourceUri { get; private set; }

        public Uri SapGetWorkOperationsResourceUri { get; private set; }

        public Settings(string baseUri,string clientId, string clientSecret
            ,string sapGetWorkOrdersResourceUri,string sapGetWorkOperationsResourceUri)
        {
            BaseUri = new Uri(baseUri, UriKind.Absolute);
            ClientId = clientId;
            ClientSecret = clientSecret;

            SapGetWorkOrdersResourceUri = new Uri(sapGetWorkOrdersResourceUri, UriKind.Relative);
            SapGetWorkOperationsResourceUri = new Uri(sapGetWorkOperationsResourceUri, UriKind.Relative);
        }
    }
}
