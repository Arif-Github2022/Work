﻿namespace Petronas.Work.Integration.Ace.ResponseModels
{
    public class StaffInformation
    {
        public Guid ACMSGuid { get; set; }
        
        public string? FullName { get; set; }

        public string? Position { get; set; }

        public string? Company { get; set; }

        public string? Department { get; set; }
    }
}
