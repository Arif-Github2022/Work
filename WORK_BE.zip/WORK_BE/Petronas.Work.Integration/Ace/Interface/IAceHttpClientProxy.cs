﻿using Petronas.Work.Integration.Ace.ResponseModels;

namespace Petronas.Work.Integration.Ace.Interface
{
    public interface IAceHttpClientProxy
    {
        public Task<List<StaffInformation>> Search(string staffName, int pageSize = 0, int numberOfRecords = 100);
    }
}
