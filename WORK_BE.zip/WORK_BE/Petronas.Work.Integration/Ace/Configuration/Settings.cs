﻿namespace Petronas.Work.Integration.Ace.Configuration
{
    public class Settings
    {
        public string ClientId { get; private set; }

        public string ClientSecret { get; private set; }

        public string Authorization { get; private set; }

        public string Token { get; private set; }

        public Uri BaseUri { get; private set; }

        public Uri ResourceUri { get; private set; }

        public Settings(string baseUri, string resourceUri, string clientId, string clientSecret, string authorization, string token)
        {
            BaseUri = new Uri(baseUri, UriKind.Absolute);
            ResourceUri = new Uri(resourceUri, UriKind.Relative);
            ClientId = clientId;
            ClientSecret = clientSecret;
            Authorization = authorization;
            Token = token;
        }
    }
}
