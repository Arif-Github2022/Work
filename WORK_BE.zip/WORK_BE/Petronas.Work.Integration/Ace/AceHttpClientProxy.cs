﻿using Petronas.Work.Core.Constants;
using Petronas.Work.Integration.Ace.Configuration;
using Petronas.Work.Integration.Ace.Interface;
using Petronas.Work.Integration.Ace.ResponseModels;
using Petronas.Work.Integration.WebClient.Interface;
using System.Collections.Specialized;
using System.Web;

namespace Petronas.Work.Integration.Ace
{
    public class AceHttpClientProxy : IAceHttpClientProxy
    {
        private readonly Settings _settings;
        private readonly IHttpClientProxy _httpClientProxy;

        public AceHttpClientProxy(Settings settings, IHttpClientProxy httpClientProxy)
        {
            _settings = settings;
            _httpClientProxy = httpClientProxy;
        }

        public async Task<List<StaffInformation>> Search(string staffName, int pageSize = 0, int numberOfRecords = 100)
        {
            var httpCustomHeaders = new NameValueCollection
            {
                { "client_id", _settings.ClientId },
                { "client_secret", _settings.ClientSecret },
                { "Authorization", _settings.Authorization }
            };

            var resourceUri = new Uri(_settings.BaseUri, _settings.ResourceUri);
            var uriBuilder = new UriBuilder(resourceUri);
            var query = HttpUtility.ParseQueryString(resourceUri.Query);
            query.Add("Token", _settings.Token);
            query.Add("Skip", pageSize.ToString());
            query.Add("Take", numberOfRecords.ToString());
            query.Add("FullName", staffName);
            uriBuilder.Query = query.ToString();

            var updatedResourceUriString = uriBuilder.ToString();
            var updatedResourceUri = new Uri(updatedResourceUriString);

            var relativeUri = new Uri(updatedResourceUri.PathAndQuery, UriKind.Relative);

            var response = await _httpClientProxy.GetAsync<StaffInformationResponse>(_settings.BaseUri, relativeUri, httpCustomHeaders);
            return response?.Data?.FindAll(x => !string.IsNullOrWhiteSpace(x.Position) && x.Position.Contains(Role.Technician, StringComparison.CurrentCultureIgnoreCase));
        }
    }
}
