﻿using Petronas.Work.Integration.WebClient.Interface;
using System.Collections.Specialized;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;

namespace Petronas.Work.Integration.WebClient
{
    public class HttpClientProxy : IHttpClientProxy
    {
        private readonly HttpClient _httpClient;

        public HttpClientProxy(HttpClient httpClient)
        {

            _httpClient = httpClient;

        }

        #region---Http GET Implementation---

        public async Task<TResponse> GetAsync<TResponse>(Uri baseAddress, Uri resourceAddress) where TResponse : class
        {
            return await GetAsync<TResponse>(baseAddress, resourceAddress);
        }

        public async Task<TResponse> GetAsync<TResponse>(Uri baseAddress, Uri resourceAddress, NameValueCollection? httpCustomHeaders = null) where TResponse : class
        {
            if (!IsUriValid(baseAddress) || !IsUriValid(resourceAddress))
            {
                throw new ArgumentNullException($"{nameof(baseAddress)} is null or empty.");
            }

            if (!IsUriValid(resourceAddress) || !IsUriValid(resourceAddress))
            {
                throw new ArgumentNullException($"{nameof(baseAddress)} is null or empty.");
            }

            _httpClient.BaseAddress = baseAddress;

            _httpClient.DefaultRequestHeaders.Clear();
            _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            using (var requestMessage = new HttpRequestMessage(HttpMethod.Get, resourceAddress))
            {
                if (httpCustomHeaders != null && httpCustomHeaders.HasKeys())
                {
                    foreach (var key in httpCustomHeaders.AllKeys)
                    {
                        requestMessage.Headers.Add(key!, httpCustomHeaders[key]);
                    }
                }

                var response = await _httpClient.SendAsync(requestMessage);
                response.EnsureSuccessStatusCode();
               
                var responseObject = await response.Content.ReadFromJsonAsync<TResponse>(new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

                return responseObject;
            }
        }

        #endregion

        #region---Http POST Implementation---

        public async Task<TResponse> PostAsync<TRequest, TResponse>(TRequest request, Uri baseAddress, Uri resourceAddress)
            where TRequest : class
            where TResponse : class
        {
            return await PostAsync<TRequest, TResponse>(request, baseAddress, resourceAddress);
        }

        public async Task<TResponse> PostAsync<TRequest, TResponse>(TRequest request, Uri baseAddress, Uri resourceAddress, NameValueCollection? httpCustomHeaders = null)
            where TRequest : class
            where TResponse : class
        {
            if (!IsUriValid(baseAddress) || !IsUriValid(resourceAddress))
            {
                throw new ArgumentNullException($"{nameof(baseAddress)} is null or empty.");
            }

            if (!IsUriValid(resourceAddress) || !IsUriValid(resourceAddress))
            {
                throw new ArgumentNullException($"{nameof(baseAddress)} is null or empty.");
            }

            var requestUri = new Uri(baseAddress, resourceAddress);
            using (var requestMessage = new HttpRequestMessage(HttpMethod.Post, requestUri))
            {
                requestMessage.Headers.Add("Accept", "application/json");

                if (httpCustomHeaders != null && httpCustomHeaders.HasKeys())
                {
                    foreach (var key in httpCustomHeaders.AllKeys)
                    {
                        requestMessage.Headers.Add(key!, httpCustomHeaders[key]);
                    }
                }

                var requestJson = JsonSerializer.Serialize(request, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = false,
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                });

                requestMessage.Content = new StringContent(requestJson, Encoding.UTF8, "application/json");

                var response = await _httpClient.SendAsync(requestMessage);
                response.EnsureSuccessStatusCode();

                dynamic responseObject;

                if (typeof(TResponse) == typeof(string))
                {
                    responseObject = await response.Content.ReadAsStringAsync();
                }
                else
                {
                    responseObject = await response.Content.ReadFromJsonAsync<TResponse>(new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                }

                return responseObject;
            }
        }

        #endregion

        #region---Private Functions---

        private bool IsUriValid(Uri uri)
        {
            return uri != null && !string.IsNullOrWhiteSpace(uri.OriginalString);
        }

        #endregion
    }
}
