﻿using System.Collections.Specialized;

namespace Petronas.Work.Integration.WebClient.Interface
{
    public interface IHttpClientProxy
    {
        Task<TResponse> GetAsync<TResponse>(Uri baseAddress, Uri resourceAddress, NameValueCollection? httpCustomHeaders = null)
            where TResponse : class;

        Task<TResponse> GetAsync<TResponse>(Uri baseAddress, Uri resourceAddress) where TResponse : class;

        Task<TResponse> PostAsync<TRequest, TResponse>(TRequest request, Uri baseAddress, Uri resourceAddress, NameValueCollection? httpCustomHeaders = null)
            where TRequest : class where TResponse : class;

        Task<TResponse> PostAsync<TRequest, TResponse>(TRequest request, Uri baseAddress, Uri resourceAddress)
            where TRequest : class where TResponse : class;
    }
}
