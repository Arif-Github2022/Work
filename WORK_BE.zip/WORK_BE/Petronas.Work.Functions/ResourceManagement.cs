﻿using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Petronas.Work.Core.Utilities;
using Petronas.Work.Data.Entities.dbo;
using Petronas.Work.Domain.Queries;
using Petronas.Work.Functions.Models;
using Petronas.Work.Functions.RequestModels;
using Petronas.Work.Functions.ResponseModels;
using System;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Petronas.Work.Functions
{
    public class ResourceManagement
    {
        private readonly ILogger<ResourceManagement> _logger;
        private readonly HttpRequestBodyReader _httpRequestBodyReader;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public ResourceManagement(ILogger<ResourceManagement> logger, IMediator mediator, IMapper mapper, HttpRequestBodyReader httpRequestBodyReader)
        {
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _httpRequestBodyReader = httpRequestBodyReader ?? throw new ArgumentNullException();
        }



        /// <summary>
        /// /      Testing from Arif

            [Function("ResourceRole")]
            [OpenApiOperation(operationId: "ResourceRole")]
            [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(ResourceRole))]
            public async Task<IActionResult> ResourceRole([HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "resourcemanagement/ResourceRole")] HttpRequest req)
            { 

            _logger.LogInformation("Function Call : SearchTeamMember Started");

               // Send command
            var ResourceRoleList = new ResourceRole();
            var response = await _mediator.Send(ResourceRoleList);

            //if (response == null)
            //{
            //    return new NotFoundResult();
            //}
            //_logger.LogInformation($"Response : {System.Text.Json.JsonSerializer.Serialize(response)}");
            //_logger.LogInformation("Function Call : CreateSchedule Completed");
            //return new OkObjectResult(response);





            //if (string.IsNullOrWhiteSpace(req.Query["name"]))
            //{
            //    return new BadRequestObjectResult("parameter 'name' was not supplied or was empty.");
            //}

            //SearchResourceQuery searchResourceQuery = new()
            //{
            //    Name = req.Query["name"]
            //};
            //string requestBody = await _httpRequestBodyReader.ReadRequestBodyAsync(req, keepStreamOpen: true);
            //var request = JsonConvert.DeserializeObject<ResourceRole>(requestBody);
            //var query = _mapper.Map<ResourceRole>(request);
            //// Send command
            //var searchResult = await _mediator.Send(query);

            //var response = _mapper.Map<SearchResourceResponse>(searchResult);

            //if (response == null || response.Resources == null || !response.Resources.Any())
            //{
            //    return new NotFoundResult();
            //}

            //_logger.LogInformation($"Response : {System.Text.Json.JsonSerializer.Serialize(response)}");
            //_logger.LogInformation("Function Call : SearchTeamMember Completed");
            return new OkObjectResult(response);
        }



        /// </summary>
        /// <param name="req"></param>
        /// <returns></returns>






        [Function("SearchResource")]
        [OpenApiOperation(operationId: "SearchResource")]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(SearchResourceResponse))]
        public async Task<IActionResult> SearchTeamMember([HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "resourcemanagement/searchresource")] HttpRequest req)
        {
            _logger.LogInformation("Function Call : SearchTeamMember Started");

            if (string.IsNullOrWhiteSpace(req.Query["name"]))
            {
                return new BadRequestObjectResult("parameter 'name' was not supplied or was empty.");
            }
            
            SearchResourceQuery searchResourceQuery = new() 
            { 
                Name = req.Query["name"]
            };

            // Send command
            var searchResult = await _mediator.Send(searchResourceQuery);

            var response = _mapper.Map<SearchResourceResponse>(searchResult);

            if (response == null || response.Resources == null || !response.Resources.Any())
            {
                return new NotFoundResult();
            }

            _logger.LogInformation($"Response : {System.Text.Json.JsonSerializer.Serialize(response)}");
            _logger.LogInformation("Function Call : SearchTeamMember Completed");
            return new OkObjectResult(response);
        }
    }
}
