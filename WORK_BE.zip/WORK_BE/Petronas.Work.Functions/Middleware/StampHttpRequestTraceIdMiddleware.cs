﻿using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Middleware;
using Microsoft.Extensions.Logging;
using Serilog.Context;
using System;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading.Tasks;

namespace Petronas.Work.Functions.Middleware
{
    public class StampHttpRequestTraceIdMiddleware : IFunctionsWorkerMiddleware
    {
        private readonly ILogger<ExceptionHandlingMiddleware> _logger;

        public StampHttpRequestTraceIdMiddleware(ILogger<ExceptionHandlingMiddleware> logger)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task Invoke(FunctionContext context, FunctionExecutionDelegate next)
        {
            var request = context.GetHttpContext()?.Request;
            if (request != null)
            {
                var requestBody = request!.Body;
                var orignalReader = new StreamReader(requestBody);
                var requestBodyContent = await orignalReader.ReadToEndAsync();
                string traceId = Guid.NewGuid().ToString().ToLower();
                bool isRequestModified = false;
                try
                {
                    if (request.Query != null)
                    {
                        // Add traceId in request query parameters
                        if (!request.Query.ContainsKey("traceId"))
                        {
                            var modifiedQueryString = request.QueryString.Add("traceId", traceId);
                            request.QueryString = modifiedQueryString;
                        }
                    }

                    if (requestBody != null)
                    {
                        if (!string.IsNullOrWhiteSpace(requestBodyContent))
                        {
                            JsonNode requestJsonNode = JsonNode.Parse(requestBodyContent, new JsonNodeOptions { PropertyNameCaseInsensitive = true })!;

                            var traceIdElement = requestJsonNode["traceId"];

                            if (traceIdElement == null || string.IsNullOrWhiteSpace(traceIdElement.ToString()) || !Guid.TryParse(traceIdElement.ToString(), out _))
                            {
                                requestJsonNode["traceId"] = traceId;
                            }

                            var modifiedRequestBodyJson = JsonSerializer.Serialize
                                (
                                    requestJsonNode,
                                    new JsonSerializerOptions
                                    {
                                        PropertyNamingPolicy = JsonNamingPolicy.CamelCase
                                    }
                                );

                            var memoryStream = new MemoryStream();
                            var modifiedContent = Encoding.UTF8.GetBytes(modifiedRequestBodyJson);
                            memoryStream.Write(modifiedContent, 0, modifiedContent.Length);
                            memoryStream.Seek(0, SeekOrigin.Begin);

                            request.Body = memoryStream;

                            isRequestModified = true;
                            LogContext.PushProperty("TraceId", traceId);

                            _logger.LogInformation("Request body modified, TraceId added to request body");
                        }
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error while modifying request, trying to add TraceId in request");

                    try
                    {
                        // Unable to place trace id in body, put back orignal body content.
                        if (isRequestModified)
                        {
                            var memoryStream = new MemoryStream();
                            var orignalContent = Encoding.UTF8.GetBytes(requestBodyContent);
                            memoryStream.Write(orignalContent, 0, orignalContent.Length);
                            memoryStream.Seek(0, SeekOrigin.Begin);
                            request.Body = memoryStream;
                            _logger.LogInformation("Unable to modify request body, Unable to add TraceId added to request body");
                        }
                    }
                    catch (Exception exp)
                    {
                        _logger.LogError(exp, "Error while resetting request body, unable to reset request body.");
                    }
                }
            }

            await next(context);
        }
    }
}
