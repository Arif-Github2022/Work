﻿using Microsoft.AspNetCore.Http;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Azure.Functions.Worker.Middleware;
using Microsoft.Extensions.Logging;
using Petronas.Work.Core.Utilities;
using Petronas.Work.Functions.ResponseModels;
using Serilog.Context;
using System;
using System.Linq;
using System.Net;
using System.Text.Json;
using System.Threading.Tasks;

namespace Petronas.Work.Functions.Middleware
{
    /// <summary>
    /// This middleware catches any exceptions during function invocations and
    /// returns a response with 500 status code for http invocations.
    /// </summary>
    public class ExceptionHandlingMiddleware : IFunctionsWorkerMiddleware
    {
        private readonly ILogger<ExceptionHandlingMiddleware> _logger;
        private readonly HttpRequestBodyReader _httpRequestBodyReader;

        public ExceptionHandlingMiddleware(ILogger<ExceptionHandlingMiddleware> logger, HttpRequestBodyReader httpRequestBodyReader)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _httpRequestBodyReader = httpRequestBodyReader ?? throw new ArgumentNullException();
        }

        public async Task Invoke(FunctionContext context, FunctionExecutionDelegate next)
        {
            try
            {
                var requestData = context.GetHttpContext()?.Request;

                if (requestData != null)
                {


                    // Log incoming request body
                    var requestBody = await _httpRequestBodyReader.ReadRequestBodyAsync(requestData, keepStreamOpen: true);

                    if ((requestData.Query != null && requestData.Query.Any()) ||
                        !string.IsNullOrWhiteSpace(requestBody))
                    {
                        string logTraceId = string.Empty;
                        var traceId = requestData.Query["traceId"];
                        if (traceId.Any())
                        {
                            logTraceId = traceId.ToString();
                        }
                        // Get TraceId from request body
                        if (!string.IsNullOrWhiteSpace(requestBody))
                        {
                            JsonDocument requestJsonDoc = JsonDocument.Parse(requestBody);

                            if (requestJsonDoc.RootElement.TryGetProperty("traceId", out JsonElement traceIdJson))
                            {
                                logTraceId = traceIdJson.ToString();
                            }
                        }
                        if (!string.IsNullOrWhiteSpace(logTraceId))
                        {
                            LogContext.PushProperty("TraceId", logTraceId);
                        }
                    }

                    if (!string.IsNullOrWhiteSpace(requestBody))
                    {
                        _logger.LogInformation($"Request:{requestBody}");
                    }

                    // Log request query parameters
                    if (requestData.Query != null && requestData.Query.Any())
                    {
                        _logger.LogInformation($"RequestQueryParameters:{requestData.QueryString}");
                    }
                }
                await next(context);
            }
            catch (Exception ex)
            {
                string? traceId = null;

                var requestData = context.GetHttpContext()?.Request;

                if (requestData != null)
                {
                    // Get TraceId from query parameter
                    if (requestData.Query != null && requestData.Query.Any())
                    {
                        traceId = requestData.Query["traceId"];
                    }

                    // Log incoming request body
                    var requestBody = await _httpRequestBodyReader.ReadRequestBodyAsync(requestData, keepStreamOpen: false);

                    // Get TraceId from request body
                    if (!string.IsNullOrWhiteSpace(requestBody))
                    {
                        JsonDocument requestJsonDoc = JsonDocument.Parse(requestBody);

                        if (requestJsonDoc.RootElement.TryGetProperty("traceId", out JsonElement traceIdJson))
                        {
                            traceId = traceIdJson.ToString();
                        }
                    }

                    // TODO : Add traceId in log
                    _logger.LogError(ex, "Error processing the request");

                    // Create an instance of HttpResponse with 500 status code.
                    var errorResponse = context.GetHttpContext()!.Response;
                    errorResponse.StatusCode = (int)HttpStatusCode.InternalServerError;

                    // Need to explicitly pass the status code in WriteAsJsonAsync method.
                    await errorResponse.WriteAsJsonAsync(
                        new DefaultResponseModel
                        {
                            Message = "Error occured while processing the request. Please try after some time.",
                            TraceId = traceId ?? string.Empty,
                            IsError = true,
                            Exception = ex
                        },
                        new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase },
                        contentType: "application/json");

                    var invocationResult = context.GetInvocationResult();

                    var httpOutputBindingFromMultipleOutputBindings = GetHttpOutputBindingFromMultipleOutputBinding(context);

                    if (httpOutputBindingFromMultipleOutputBindings != null)
                    {
                        httpOutputBindingFromMultipleOutputBindings.Value = errorResponse;
                    }
                    else
                    {
                        invocationResult.Value = errorResponse;
                    }
                }
            }
        }

        private OutputBindingData<HttpResponse> GetHttpOutputBindingFromMultipleOutputBinding(FunctionContext context)
        {
            // The output binding entry name will be "$return" only when the function return type is HttpResponse
            var httpOutputBinding = context.GetOutputBindings<HttpResponse>().FirstOrDefault(b => b.BindingType == "http" && b.Name != "$return");

            return httpOutputBinding!;
        }
    }
}
