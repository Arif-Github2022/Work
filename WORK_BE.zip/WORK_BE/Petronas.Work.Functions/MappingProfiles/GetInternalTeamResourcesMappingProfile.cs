﻿using AutoMapper;
using Petronas.Work.Domain.Models;
using Petronas.Work.Domain.Queries;
using Petronas.Work.Functions.RequestModels;
using Petronas.Work.Functions.ResponseModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Functions.MappingProfiles
{
    public class GetInternalTeamResourcesMappingProfile : Profile
    {
        public GetInternalTeamResourcesMappingProfile()
        {
            // Request to Query mapping
            CreateMap<GetTeamResourcesRequest, GetInternalTeamResourcesQuery>()
                .ReverseMap();

            // Query result to response mapping
            CreateMap<GetTeamResourcesQueryResult, GetTeamResourcesRespose>()
                .ReverseMap();
        }
    }
}
