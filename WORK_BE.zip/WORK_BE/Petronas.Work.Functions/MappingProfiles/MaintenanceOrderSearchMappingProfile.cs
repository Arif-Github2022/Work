﻿using AutoMapper;
using Petronas.Work.Domain.Models;
using Petronas.Work.Domain.Queries;
using Petronas.Work.Functions.Models;
using Petronas.Work.Functions.ResponseModels;

namespace Petronas.Work.Functions.MappingProfile
{
    public class MaintenanceOrderSearchMappingProfile : Profile
    {
        public MaintenanceOrderSearchMappingProfile()
        {
            // Request to Query mapping
            CreateMap<MaintenanceOrderSearchRequest, MaintenanceOrderSearchQuery>()
                .ReverseMap();

            // Query result to response mapping
            CreateMap<MaintenanceOrderSearchResult, MaintenanceOrderSearchResponse>()
                .ForMember(response => response.Data, opt => opt.MapFrom(result => result.Data))
                .ForMember(response => response.TotalRecords, opt => opt.MapFrom(result => result.TotalRecords))
                .ForMember(response => response.PageSize, opt => opt.MapFrom(result => result.PageSize))
                .ForMember(response => response.Page, opt => opt.MapFrom(result => result.Page))
                .ReverseMap();

            CreateMap<Domain.Models.MaintenanceOrderSearchResultData, ResponseModels.MaintenanceOrderSearchResultData>()
                .ForMember(response => response.PlannedWork, opt => opt.MapFrom(result => $"{result.PlannedWork} {result.UnitforWork}"));

            CreateMap<OrderWeekSchedule, MaintenanceOrderSchedule>()
                .ReverseMap();
        }
    }
}
