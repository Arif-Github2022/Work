﻿using AutoMapper;
using Petronas.Work.Domain.Models;
using Petronas.Work.Domain.Queries;
using Petronas.Work.Functions.Models;
using Petronas.Work.Functions.ResponseModels;

namespace Petronas.Work.Functions.MappingProfile
{
    public class MaintenanceOrderWeeklyPlanChartMappingProfile : Profile
    {
        public MaintenanceOrderWeeklyPlanChartMappingProfile()
        {
            // Request to Query mapping
            CreateMap<MaintenanceOrderWeeklyPlanChartGetRequest, MaintenanceOrderWeeklyPlanChartGetQuery>()
                .ReverseMap();

            // Query result to response mapping
            CreateMap<MaintenanceOrderWeeklyPlanChartGetQueryResult, MaintenanceOrderWeeklyPlanChartGetResponse>()
                .ReverseMap();
        }
    }
}
