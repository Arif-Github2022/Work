﻿using AutoMapper;
using Petronas.Work.Domain.Commands;
using Petronas.Work.Domain.Models;
using Petronas.Work.Functions.RequestModels;
using Petronas.Work.Functions.ResponseModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Functions.MappingProfiles
{
    public class CreateUpdateResourceScheduleMappingProfile : Profile
    {
        public CreateUpdateResourceScheduleMappingProfile()
        { 




            // Request to Query mapping
            CreateMap<CreateUpdateResourceScheduleRequest, CreateUpdateResourceScheduleCommand>()
                .ForMember(command => command.ResourceSchedule, opt => opt.MapFrom(request => request.ResourceSchedule))
                .ReverseMap();


            CreateMap<RequestModels.ResourceScheduleDetails, Domain.Commands.ResourceScheduleDetails>()
                .ReverseMap();

            // Query result to response mapping
            CreateMap<DefaultResponseResult, DefaultResponseModel>()
                .ReverseMap();
        }
    }
}
