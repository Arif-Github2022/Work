﻿using AutoMapper;
using Petronas.Work.Domain.Models;
using Petronas.Work.Domain.Queries;
using Petronas.Work.Functions.Models;
using Petronas.Work.Functions.RequestModels;
using Petronas.Work.Functions.ResponseModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Functions.MappingProfiles
{
    public class MaintenanceOrderWeeklyAvailabilityMappingProfile : Profile
    {
        public MaintenanceOrderWeeklyAvailabilityMappingProfile()
        {
            // Request to Query mapping
            CreateMap<MaintenanceOrderWeeklyAvailabilityRequest, MaintenanceOrderWeeklyAvailabilityQuery>()
                .ReverseMap();

            // Query result to response mapping
            CreateMap<MaintenanceOrderWeeklyAvailabilityQueryResult, MaintenanceOrderWeeklyAvailabilityResponse>()
                .ReverseMap();
        }
    }
}
