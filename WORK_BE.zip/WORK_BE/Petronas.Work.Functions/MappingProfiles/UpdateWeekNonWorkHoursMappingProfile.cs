﻿using AutoMapper;
using Petronas.Work.Domain.Commands;
using Petronas.Work.Functions.RequestModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Functions.MappingProfiles
{
    public class UpdateWeekNonWorkHoursMappingProfile : Profile
    {
        public UpdateWeekNonWorkHoursMappingProfile()
        {

            // Request to Query mapping
            CreateMap<UpdateWeekNonWorkHoursRequest, UpdateWeekNonWorkHoursCommand>()
                .ReverseMap();

            CreateMap<RequestModels.ResourceNonWorkHours, Domain.Commands.ResourceNonWorkHours>()
                .ReverseMap();

            CreateMap<RequestModels.WeekDayNonWorkHours, Domain.Commands.WeekDayNonWorkHours>()
            .ReverseMap();

        }
    }
}
