﻿using AutoMapper;
using Petronas.Work.Domain.Models;
using Petronas.Work.Domain.Queries;
using Petronas.Work.Functions.RequestModels;
using Petronas.Work.Functions.ResponseModels;

namespace Petronas.Work.Functions.MappingProfiles
{
    public class ResourceManagementMappingProfile : Profile
    {
        public ResourceManagementMappingProfile()
        {
            CreateMap<SearchResourceRequest, SearchResourceQuery>()
                .ReverseMap();

            CreateMap<SearchResourceResult, SearchResourceResponse>()
                .ReverseMap();

            CreateMap<Domain.Models.ResourceInformation, ResponseModels.ResourceInformation>()
                .ForMember(responseResourceInfo => responseResourceInfo.Id, opt => opt.MapFrom(domainResourceInfo => domainResourceInfo.ResourceId))
                .ForMember(responseResourceInfo => responseResourceInfo.Name, opt => opt.MapFrom(domainResourceInfo => domainResourceInfo.ResourceName))
                .ForMember(responseResourceInfo => responseResourceInfo.Company, opt => opt.MapFrom(domainResourceInfo => domainResourceInfo.ResourceCompany))
                .ForMember(responseResourceInfo => responseResourceInfo.IsContractor, opt => opt.MapFrom(domainResourceInfo => domainResourceInfo.IsResourceContractor))
                .ForMember(responseResourceInfo => responseResourceInfo.AceId, opt => opt.MapFrom(domainResourceInfo => domainResourceInfo.ResourceAceId))
                .ReverseMap();
        }
    }
}
