﻿using AutoMapper;
using Petronas.Work.Domain.Commands;
using Petronas.Work.Domain.Models;
using Petronas.Work.Domain.Queries;
using Petronas.Work.Functions.RequestModels;
using Petronas.Work.Functions.ResponseModels;



namespace Petronas.Work.Functions.MappingProfiles
{
    public class GetResourceScheduleMappingProfile: Profile
    {
        public GetResourceScheduleMappingProfile()
        {
            // Request to Query mapping
            CreateMap<GetResourceScheduleRequest, GetResourceScheduleQuery>()
                .ReverseMap();

            // Query result to response mapping
            CreateMap<GetResourceScheduleQueryResult, GetResourceScheduleResponse>()
                .ReverseMap();

            CreateMap<ScheduledOrderInfo, ScheduledOrder>()
                .ForMember(scheduledOrderInfo => scheduledOrderInfo.PlannedWork, opt => opt.MapFrom(scheduledOrder => $"{scheduledOrder.PlannedWork} {scheduledOrder.UnitforWork}"));

            CreateMap<ResourceScheduleInfo, ResourceSchedule>()
                .ReverseMap();
            CreateMap<Domain.Models.ResourceDailySchedule, ResponseModels.ResourceDailySchedule>()
               .ReverseMap();
        }
    }
}
