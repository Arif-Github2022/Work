﻿using AutoMapper;
using Petronas.Work.Domain.Models;
using Petronas.Work.Domain.Queries;
using Petronas.Work.Functions.RequestModels;
using Petronas.Work.Functions.ResponseModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Functions.MappingProfiles
{
    public class GetCurrentTeamResourcesMappingProfile : Profile
    {
        public GetCurrentTeamResourcesMappingProfile()
        {
            // Request to Query mapping
            CreateMap<GetTeamResourcesRequest, GetTeamResourcesQuery>()
                .ReverseMap();

            // Query result to response mapping
            CreateMap<GetTeamResourcesQueryResult, GetTeamResourcesRespose>()
                .ReverseMap();
        }
    }
}
