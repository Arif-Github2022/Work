﻿using AutoMapper;
using Petronas.Work.Domain.Models;
using Petronas.Work.Domain.Queries;
using Petronas.Work.Functions.RequestModels;
using Petronas.Work.Functions.ResponseModels;

namespace Petronas.Work.Functions.MappingProfiles
{
    public class ResourceScheduleGetWeeklyPlanChartMappingProfile : Profile
    {
        public ResourceScheduleGetWeeklyPlanChartMappingProfile()
        {
            // Request to Query mapping
            CreateMap<ResourceScheduleGetWeeklyPlanChartRequest, ResourceScheduleGetWeeklyPlanChartQuery>()
                .ReverseMap();

            // Query result to response mapping
            CreateMap<ResourceScheduleGetWeeklyPlanChartQueryResult, ResourceScheduleGetWeeklyPlanChartResponse>()
                .ReverseMap();

            CreateMap<Domain.Models.WeekChartData, ResponseModels.WeekChartData>()
                .ReverseMap();

            CreateMap<Domain.Models.ResourceScheduleWeekChartData, ResponseModels.ResourceScheduleWeekChartData>()
                .ForMember(response => response.ResourceId, opt => opt.MapFrom(result => result.ResourceId))
                .ForMember(response => response.ResourceName, opt => opt.MapFrom(result => result.ResourceName))
                .ForMember(response => response.AvailableHours, opt => opt.MapFrom(result => result.AvailableHours))
                .ForMember(response => response.AssignedHours, opt => opt.MapFrom(result => result.AssignedHours))
                .ForMember(response => response.UnavailableHours, opt => opt.MapFrom(result => result.UnavailableHours))
                .ForMember(response => response.OvertimeHours, opt => opt.MapFrom(result => result.AssignedOvertimeHours))
                .ForMember(response => response.ReportedAvailableHours, opt => opt.MapFrom(result => result.TotalActualAvailableHours))
                .ForMember(response => response.ReportedAssignedHours, opt => opt.MapFrom(result => result.TotalActualHours))
                .ForMember(response => response.ReportedUnavailableHours, opt => opt.MapFrom(result => result.ActualUnavailableHours))
                .ForMember(response => response.ReportedOvertimeHours, opt => opt.MapFrom(result => result.ActualOvertimeHours))
                .ReverseMap();

            CreateMap<Domain.Models.WeekDayChartData, ResponseModels.WeekDayChartData>()
                .ReverseMap();
        }
    }
}
