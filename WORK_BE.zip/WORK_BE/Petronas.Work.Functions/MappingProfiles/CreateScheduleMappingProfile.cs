﻿using AutoMapper;
using Petronas.Work.Domain.Commands;
using Petronas.Work.Domain.Models;
using Petronas.Work.Functions.RequestModels;
using Petronas.Work.Functions.ResponseModels;

namespace Petronas.Work.Functions.MappingProfiles
{
    public class CreateScheduleMappingProfile :Profile
    {
        public CreateScheduleMappingProfile()
        {
            // Request to Query mapping
            CreateMap<CreateScheduleRequest, CreateScheduleCommand>()
                .ReverseMap();

            // Query result to response mapping
            CreateMap<DefaultResponseResult, DefaultResponseModel>()
                .ReverseMap();
        }
    }
}
