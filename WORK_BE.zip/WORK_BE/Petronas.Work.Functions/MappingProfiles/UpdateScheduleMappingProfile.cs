﻿using AutoMapper;
using Petronas.Work.Domain.Commands;
using Petronas.Work.Domain.Models;
using Petronas.Work.Functions.RequestModels;
using Petronas.Work.Functions.ResponseModels;

namespace Petronas.Work.Functions.MappingProfiles
{
    public class UpdateScheduleMappingProfile :Profile
    {
        public UpdateScheduleMappingProfile()
        {
            // Request to Query mapping
            CreateMap<UpdateScheduleRequest, UpdateScheduleCommand>()
                .ReverseMap();

            // Query result to response mapping
            CreateMap<DefaultResponseResult, UpdateScheduleResponse>()
                .ReverseMap();
        }
    }
}
