﻿using AutoMapper;
using Petronas.Work.Domain.Commands;
using Petronas.Work.Domain.Models;
using Petronas.Work.Functions.RequestModels;
using Petronas.Work.Functions.ResponseModels;

namespace Petronas.Work.Functions.MappingProfiles
{
    public class CreateTeamMemberMappingProfile : Profile
    {
        public CreateTeamMemberMappingProfile()
        {
            // Request to Query mapping
            CreateMap<CreateTeamMemberRequest, CreateResourceCommand>()
                .ReverseMap();

            // Query result to response mapping
            CreateMap<DefaultResponseResult, DefaultResponseModel>()
                    .ReverseMap();
        }
    }
}
