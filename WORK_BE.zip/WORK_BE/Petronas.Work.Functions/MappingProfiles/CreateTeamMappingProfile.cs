﻿using AutoMapper;
using Petronas.Work.Domain.Commands;
using Petronas.Work.Domain.Models;
using Petronas.Work.Functions.RequestModels;
using Petronas.Work.Functions.ResponseModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Functions.MappingProfiles
{
    public class CreateTeamMappingProfile:Profile
    {
        public CreateTeamMappingProfile()
        {
            // Request to Query mapping
            CreateMap<CreateTeamRequest, CreateTeamCommand>()
                .ReverseMap();

            // Query result to response mapping
            CreateMap<DefaultResponseResult, DefaultResponseModel>()
                .ReverseMap();
        }
    }
}
