﻿using Petronas.Work.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Functions.ResponseModels
{
    public class ScheduledOrder
    {
        public Guid WorkOrderId { get; set; }
        public string OrderDescription { get; set; }
        public DateTime OrderStartDate { get; set; }
        public DateTime OrderEndDate { get; set; }
        public string OrderNumber { get; set; }
        public string OrderType { get; set; }
        public string FunctionalLocation { get; set; }
        public string PlannedWork { get; set; }
        public int Priority { get; set; }
        public int TotalActualHours { get; set; }
        public int TotalplannedHours { get; set; }
        public int TotalAwayHours { get; set; }
        public int TotalOvertimeHours { get; set; }
        public List<ResourceSchedule> ResourceSchedule { get; set; }
    }
}
