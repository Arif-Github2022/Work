﻿using System;
using System.Collections.Generic;

namespace Petronas.Work.Functions.ResponseModels
{
    public class GetResourceScheduleResponse
    {
        public Guid TeamID { get; set; }
        public DateTime WeekStartDate { get; set; }
        public DateTime WeekEndDate { get; set; }
        public List<ScheduledOrder> ScheduledOrder { get; set; }
    }
}
