﻿using System.Collections.Generic;

namespace Petronas.Work.Functions.ResponseModels
{
    public class ResourceScheduleGetWeeklyPlanChartResponse
    {
        public List<WeekChartData> WeekChartDataList { get; set; }
    }
}
