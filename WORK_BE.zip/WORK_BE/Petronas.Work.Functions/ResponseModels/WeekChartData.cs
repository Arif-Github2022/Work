﻿using System;
using System.Collections.Generic;

namespace Petronas.Work.Functions.ResponseModels
{
    public class WeekChartData
    {
        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public int TotalAvailableHours { get; set; }

        public int TotalAssignedHours { get; set; }

        public int TotalActualHours { get; set; }

        public int TotalActualAvailableHours { get; set; }

        public int TotalAssignedOvertimeHours { get; set; }

        public int TotalActualOvertimeHours { get; set; }

        public int TotalUnavailableHours { get; set; }

        public List<WeekDayChartData> weekDayChartDataList { get; set; }

        public List<ResourceScheduleWeekChartData> ResourceScheduleWeekChartDataList { get; set; }
    }

    public class WeekDayChartData
    {
        public string? DayOfWeek { get; set; }

        public int TotalAvailableHours { get; set; }

        public int TotalAssignedHours { get; set; }

        public int TotalActualHours { get; set; }

        public int TotalActualAvailableHours { get; set; }

        public int TotalAssignedOvertimeHours { get; set; }

        public int TotalActualOvertimeHours { get; set; }

        public int TotalUnavailableHours { get; set; }
    }
}
