﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Functions.ResponseModels
{
    public class GetTeamResourcesRespose
    {
        public Guid ResourceId { get; set; }
        public string Name { get; set; }
        public string Company { get; set; }
        public bool IsContractor { get; set; }
        public string AceId { get; set; }

    }
}
      
