﻿using System;

namespace Petronas.Work.Functions.ResponseModels
{
    public class UpdateScheduleResponse
    {
        public Guid WorkOrderId { get; set; }
        public DateTime ScheduleStartDate { get; set; }
        public DateTime ScheduleEndDate { get; set; }
        public DateTime RecordCreatedOn { get; set; }
        public Guid RecordCreatedById { get; set; }
        public DateTime RecordUpdatedOn { get; set; }
        public Guid RecordUpdatedById { get; set; }
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }
    }
}
