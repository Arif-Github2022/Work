﻿using System;

namespace Petronas.Work.Functions.ResponseModels
{
    public class MaintenanceOrderWeeklyAvailabilityResponse
    {
        public int AvailableHours { get; set; }
        public DateTime date { get; set; }
    }
}