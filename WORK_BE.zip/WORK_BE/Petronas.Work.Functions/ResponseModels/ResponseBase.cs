﻿namespace Petronas.Work.Functions.ResponseModels
{
    public abstract class ResponseBase
    {
        public string TraceId { get; set; }
    }
}
