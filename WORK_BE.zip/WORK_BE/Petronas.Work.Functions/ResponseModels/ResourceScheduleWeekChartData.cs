﻿using System;

namespace Petronas.Work.Functions.ResponseModels
{
    public class ResourceScheduleWeekChartData
    {
        public Guid ResourceId { get; set; }

        public string? ResourceName { get; set; }

        public int AvailableHours { get; set; }

        public int AssignedHours { get; set; }

        public int OvertimeHours { get; set; }

        public int UnavailableHours { get; set; }

        public int ReportedAvailableHours { get; set; }

        public int ReportedAssignedHours { get; set; }

        public int ReportedOvertimeHours { get; set; }

        public int ReportedUnavailableHours { get; set; }
    }
}
