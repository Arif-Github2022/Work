﻿using Petronas.Work.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Functions.ResponseModels
{
    public class GetWeekNonWorkHoursResponse
    {
        public List<ResourceUnavailableHours> ResourceUnavailableHours { get; set; }
    }
    public class ResourceUnavailableHours
    {
        public Guid Id { get; set; }

        public string Name { get; set; }

        public int WorkHours { get; set; }

        public int AwayHours { get; set; }

        public string WeekDay { get; set; }
    }
}
