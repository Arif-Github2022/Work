﻿using System;
using System.Collections.Generic;

namespace Petronas.Work.Functions.ResponseModels
{
    public class ResourceSchedule
    {
        public Guid ResourceId { get; set; }
        public string ResourceName { get; set; }
        public string ResourceCompany { get; set; }
        public string ResourceAceId { get; set; }
        public bool IsResourceContractor { get; set; }
        public List<ResourceDailySchedule> DailySchedule { get; set; }
    }
}
