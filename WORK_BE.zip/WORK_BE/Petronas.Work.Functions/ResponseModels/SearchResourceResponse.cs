﻿using System.Collections.Generic;

namespace Petronas.Work.Functions.ResponseModels
{
    public class SearchResourceResponse
    {
        public List<ResourceInformation> Resources { get; set; }
    }
}
