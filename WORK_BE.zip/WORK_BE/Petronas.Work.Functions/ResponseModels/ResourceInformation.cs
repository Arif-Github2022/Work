﻿using System;

namespace Petronas.Work.Functions.ResponseModels
{
    public class ResourceInformation
    {
        public Guid Id { get; set; }

        public string Name { get; set; }

        public string Company { get; set; }

        public bool IsContractor { get; set; }

        public Guid AceId { get; set; }
    }
}
