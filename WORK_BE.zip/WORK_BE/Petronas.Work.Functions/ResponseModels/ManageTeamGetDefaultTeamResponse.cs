﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Functions.ResponseModels
{
    public class ManageTeamGetDefaultTeamResponse
    {
        public List<ManageTeamDetails> TeamDefaultWorkHours { get; set; }
    }

    public class ManageTeamDetails
    {
        public Guid ResourceId { get; set; }

        public string ResourceAceId { get; set; }

        public bool IsResourceContractor { get; set; }

        public string ResourceCompany { get; set; }

        public string ResourceName { get; set; }

        public int WorkHours { get; set; }

        public string WeekDay { get; set; }
    }
}

