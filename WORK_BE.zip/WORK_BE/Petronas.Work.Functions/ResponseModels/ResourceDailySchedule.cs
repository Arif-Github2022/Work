﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Functions.ResponseModels
{
    public class ResourceDailySchedule
    {
        public int ActualHours { get; set; }
        public int AwayHours { get; set; }
        public int PlannedHours { get; set; }
        public int OvertimeHours { get; set; }
        public DateTime WeekDay { get; set; }
        public string weekDayName { get; set; }
    }
}
