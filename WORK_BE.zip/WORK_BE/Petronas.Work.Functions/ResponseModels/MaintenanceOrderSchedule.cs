﻿using System;

namespace Petronas.Work.Functions.ResponseModels
{
    public class MaintenanceOrderSchedule
    {
        public int WeekNumber { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }
    }
}
