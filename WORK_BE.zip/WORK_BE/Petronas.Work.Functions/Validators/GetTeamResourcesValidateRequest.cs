﻿using FluentValidation;
using Petronas.Work.Functions.RequestModels;

namespace Petronas.Work.Functions.Validators
{
    public class GetTeamResourcesValidateRequest : AbstractValidator<GetTeamResourcesRequest>
    {
        public GetTeamResourcesValidateRequest()
        {
            RuleFor(x => x.TeamID).NotEmpty().WithMessage("TeamID is required");
        }
    }
}
