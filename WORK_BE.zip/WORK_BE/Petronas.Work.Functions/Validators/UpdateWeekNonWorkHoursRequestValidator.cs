﻿using FluentValidation;
using Petronas.Work.Functions.RequestModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Functions.Validators
{
    public class UpdateWeekNonWorkHoursRequestValidator : AbstractValidator<UpdateWeekNonWorkHoursRequest>
    {
        public UpdateWeekNonWorkHoursRequestValidator()
        {

            RuleFor(x => x.StartDate).NotEmpty();
            RuleFor(x => x.EndDate).NotEmpty();
            RuleFor(x => x.ResourceNonWorkHours)
               .NotEmpty().When(x => x.ResourceNonWorkHours != null)
               .WithMessage("Resource Schedule Status must not be empty");
        }
    }
}
