﻿using FluentValidation;
using Petronas.Work.Functions.RequestModels;
using System;

namespace Petronas.Work.Functions.Validators
{
    public class ResourceScheduleGetWeeklyPlanChartRequestValidator : AbstractValidator<ResourceScheduleGetWeeklyPlanChartRequest>
    {
        public ResourceScheduleGetWeeklyPlanChartRequestValidator()
        {
            RuleFor(x => x.StartDate)
                .NotEmpty()
                .LessThan(x => x.EndDate);

            RuleFor(x => x.EndDate)
                .NotEmpty()
                .GreaterThan(x => x.StartDate);

            RuleFor(x => x.TeamId)
                .NotEmpty()
                .NotEqual(Guid.Empty);
        }
    }
}
