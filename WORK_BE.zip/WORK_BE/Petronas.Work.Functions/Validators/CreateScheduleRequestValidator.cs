﻿using FluentValidation;
using Petronas.Work.Functions.RequestModels;
using System;

namespace Petronas.Work.Functions.Validators
{
    public class CreateScheduleRequestValidator : AbstractValidator<CreateScheduleRequest>
    {

        public CreateScheduleRequestValidator()
        {
            RuleFor(x => x.WorkOrderId).NotEqual(Guid.Empty);

            RuleFor(x => x.ScheduleStartDate).NotEmpty().WithMessage("Schedule StartDate is required");
            
            RuleFor(x => x.ScheduleEndDate).NotEmpty().WithMessage("Schedule EndDate is required");
        }
    }
}
