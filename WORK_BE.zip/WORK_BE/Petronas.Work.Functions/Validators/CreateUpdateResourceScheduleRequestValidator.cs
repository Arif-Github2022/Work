﻿using FluentValidation;
using Petronas.Work.Functions.RequestModels;
using System;
using System.Linq;

namespace Petronas.Work.Functions.Validators
{
    public class CreateUpdateResourceScheduleRequestValidator : AbstractValidator<CreateUpdateResourceScheduleRequest>
    {
        public CreateUpdateResourceScheduleRequestValidator()
        {
            RuleFor(x => x.ResourceSchedule)
               .NotNull()
               .NotEmpty()
               .WithMessage("Resource Schedule must not be empty");

            RuleFor(x => x.ResourceSchedule)
                .Must(i => !i.Any(x => x.WorkOrderId == Guid.Empty))
                .WithMessage("WorkOrderId parameter is invalid");

            RuleFor(x => x.ResourceSchedule)
                .Must(i => !i.Any(x => x.ResourceId == Guid.Empty))
                .WithMessage("ResourceId parameter is invalid");

            RuleFor(x => x.ResourceSchedule)
                .Must(i => !i.Any(x => x.PlannedWorkHours < 0))
                .WithMessage("PlannedWorkHours parameter is invalid, must be a positive integer.");

            RuleFor(x => x.ResourceSchedule)
                .Must(i => !i.Any(x => x.PlannedDate == null || x.PlannedDate <= DateTime.MinValue))
                .WithMessage("PlannedDate parameter is invalid.");

            RuleFor(x => x.ResourceSchedule)
                .Must(i => !i.Any(x => string.IsNullOrWhiteSpace(x.ResourceName)))
                .WithMessage("ResourceName parameter must not be empty or null");

            RuleFor(x => x.ResourceSchedule)
                .Must(i => !i.Any(x => string.IsNullOrWhiteSpace(x.ResourceCompany)))
                .WithMessage("ResourceCompany parameter must not be empty or null");
        }
    }
}
