﻿using FluentValidation;
using Petronas.Work.Functions.RequestModels;
using System;

namespace Petronas.Work.Functions.Validators
{
    public class GetResourceScheduleGetRequestValidator : AbstractValidator<GetResourceScheduleRequest>
    {
        public GetResourceScheduleGetRequestValidator()
        {
            RuleFor(x => x.TeamId).NotEqual(Guid.Empty);

            RuleFor(x => x.StartDate).NotEmpty().WithMessage("Schedule StartDate is required");

            RuleFor(x => x.EndDate).NotEmpty().WithMessage("Schedule EndDate is required");
        }
    }
}
