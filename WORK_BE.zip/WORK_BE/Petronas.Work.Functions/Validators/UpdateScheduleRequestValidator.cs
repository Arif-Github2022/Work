﻿using FluentValidation;
using Petronas.Work.Functions.RequestModels;
using System;

namespace Petronas.Work.Functions.Validators
{
    public class UpdateScheduleRequestValidator : AbstractValidator<UpdateScheduleRequest>
    {
        public UpdateScheduleRequestValidator()
        {
            RuleFor(x => x.WorkOrderId).NotEqual(Guid.Empty);

            RuleFor(x => x.ScheduleStartDate).NotEmpty().WithMessage("Schedule StartDate is required");

            RuleFor(x => x.ScheduleEndDate).NotEmpty().WithMessage("Schedule EndDate is required");
        }
    }
}
