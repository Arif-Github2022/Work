﻿using FluentValidation;
using Petronas.Work.Functions.RequestModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Functions.Validators
{
    public class GetWeekNonWorkHoursRequestValidator : AbstractValidator<GetWeekNonWorkHoursRequest>
    {

        public GetWeekNonWorkHoursRequestValidator()
        {
            RuleFor(x => x.TeamId).NotEqual(Guid.Empty);

            RuleFor(x => x.StartDate).NotEmpty().WithMessage("StartDate is required");

            RuleFor(x => x.EndDate).NotEmpty().WithMessage("EndDate is required");
        }
    }
}
