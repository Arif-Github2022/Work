﻿using FluentValidation;
using Petronas.Work.Functions.RequestModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Functions.Validators
{
    public class UpdateTeamDefaultHoursRequestValidate : AbstractValidator<UpdateTeamDefaultHoursRequest>
    {
        public UpdateTeamDefaultHoursRequestValidate()
        {
            RuleFor(x => x.ResourceDefaultWorkHours)
               .NotEmpty().When(x => x.ResourceDefaultWorkHours != null)
               .WithMessage("Resource Schedule Status must not be empty");
        }
    }
}
