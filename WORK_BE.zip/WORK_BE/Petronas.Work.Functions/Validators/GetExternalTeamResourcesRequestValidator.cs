﻿using FluentValidation;
using Petronas.Work.Functions.RequestModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Functions.Validators
{
    public class GetExternalTeamResourcesRequestValidator : AbstractValidator<GetExternalTeamResourcesRequest>
    {
        public GetExternalTeamResourcesRequestValidator()
        {
            RuleFor(x => x.Name).NotEmpty().WithMessage("TeamID is required");
        }
    }
}
