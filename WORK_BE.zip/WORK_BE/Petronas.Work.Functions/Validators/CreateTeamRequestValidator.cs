﻿using FluentValidation;
using Petronas.Work.Functions.RequestModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Functions.Validators
{
    public class CreateTeamRequestValidator : AbstractValidator<CreateTeamRequest>
    {

        public CreateTeamRequestValidator()
        {
            RuleFor(x => x.Name).NotEmpty().WithMessage("Name is required");

            RuleFor(x => x.Description).NotEmpty().WithMessage("Description is required");
        }
    }
}
