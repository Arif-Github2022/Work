﻿using FluentValidation;
using Petronas.Work.Functions.RequestModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Functions.Validators
{
    public class ManageTeamGetDefaultTeamRequestValidator : AbstractValidator<ManageTeamGetDefaultTeamRequest>
    {
        public ManageTeamGetDefaultTeamRequestValidator()
        {
            RuleFor(x => x.TeamId).NotEqual(Guid.Empty);
        }
    }
}
