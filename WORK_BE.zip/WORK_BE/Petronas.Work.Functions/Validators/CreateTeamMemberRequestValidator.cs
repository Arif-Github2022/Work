﻿using FluentValidation; 
using Petronas.Work.Functions.RequestModels; 

namespace Petronas.Work.Functions.Validators
{
    public class CreateTeamMemberRequestValidator : AbstractValidator<CreateTeamMemberRequest>
    {
        public CreateTeamMemberRequestValidator()
        {
            //  RuleFor(x => x.TeamId);
            RuleFor(x => x.ResourceInformation)
               .NotEmpty().When(x => x.ResourceInformation != null)
               .WithMessage("Resource Information must not be empty");
        }
    }
}
