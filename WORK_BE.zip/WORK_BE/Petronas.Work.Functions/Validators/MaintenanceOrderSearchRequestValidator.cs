﻿using FluentValidation;
using Petronas.Work.Functions.Models;

namespace Petronas.Work.Functions.Validators
{
    public class MaintenanceOrderSearchRequestValidator : AbstractValidator<MaintenanceOrderSearchRequest>
    {
        public MaintenanceOrderSearchRequestValidator()
        {
            RuleFor(x => x.Page)
                .GreaterThan(0)
                .WithMessage("Page must be grater than 0");

            RuleFor(x => x.PageSize)
                .GreaterThan(0)
                .LessThanOrEqualTo(50)
                .WithMessage("Page Size must be grater than 0 and less than or equal to 50");

            RuleFor(x => x.TeamId)
                .NotEmpty()
                .WithMessage("Team Id must not be null or empty");
        }
    }

    public class MaintenanceOrderWeeklyPlanChartGetRequestValidator : AbstractValidator<MaintenanceOrderWeeklyPlanChartGetRequest>
    {
        public MaintenanceOrderWeeklyPlanChartGetRequestValidator()
        {
            RuleFor(x => x.TeamId)
                .NotEmpty()
                .WithMessage("TeamId must not be null or empty");
        }
    }
}
