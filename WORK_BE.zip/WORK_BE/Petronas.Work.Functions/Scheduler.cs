﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using AutoMapper;
using FluentValidation;
using FluentValidation.Results;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using Petronas.Work.Core.Utilities;
using Petronas.Work.Domain.Commands;
using Petronas.Work.Domain.Models;
using Petronas.Work.Domain.Queries;
using Petronas.Work.Functions.RequestModels;
using Petronas.Work.Functions.ResponseModels;

namespace Petronas.Work.Functions
{
    public class Scheduler
    {
        private readonly ILogger<Scheduler> _logger;
        private readonly HttpRequestBodyReader _httpRequestBodyReader;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private readonly IValidator<GetResourceScheduleRequest> _getResourceScheduleGetRequestValidator;
        private readonly IValidator<CreateUpdateResourceScheduleRequest> _createResourceScheduleRequestValidator;
        private readonly IValidator<GetTeamResourcesRequest> _getTeamResourcesRequestValidator;
        private readonly IValidator<GetExternalTeamResourcesRequest> _getExternalTeamResourcesRequestValidator;
        private readonly IValidator<ResourceScheduleGetWeeklyPlanChartRequest> _resourceScheduleGetWeeklyPlanChartRequestValidator;


        public Scheduler(ILogger<Scheduler> logger, IMediator mediator, IMapper mapper, HttpRequestBodyReader httpRequestBodyReader,
            IValidator<GetResourceScheduleRequest> getResourceScheduleGetRequestValidator, IValidator<CreateUpdateResourceScheduleRequest> createResourceScheduleRequest,
            IValidator<GetTeamResourcesRequest> getTeamResourcesRequest
            , IValidator<GetExternalTeamResourcesRequest> getExternalTeamResourcesRequest
            , IValidator<ResourceScheduleGetWeeklyPlanChartRequest> resourceScheduleGetWeeklyPlanChartRequestValidator)
        {
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _httpRequestBodyReader = httpRequestBodyReader ?? throw new ArgumentNullException();
            _getResourceScheduleGetRequestValidator = getResourceScheduleGetRequestValidator;
            _createResourceScheduleRequestValidator = createResourceScheduleRequest;
            _getTeamResourcesRequestValidator = getTeamResourcesRequest;
            _getExternalTeamResourcesRequestValidator = getExternalTeamResourcesRequest;
            _resourceScheduleGetWeeklyPlanChartRequestValidator = resourceScheduleGetWeeklyPlanChartRequestValidator;
        }
        [Function("GetResourceSchedule")]
        [OpenApiOperation(operationId: "GetResourceSchedule")]
        [OpenApiRequestBody("application/json", typeof(GetResourceScheduleRequest), Required = true)]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(GetResourceScheduleResponse))]
        public async Task<IActionResult> GetResourceSchedule([HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "Scheduler/getresourceschedule")] HttpRequest req)
        {
            _logger.LogInformation("Function Call : GetResourceSchedule Started");

            // Get request body
            string requestBody = await _httpRequestBodyReader.ReadRequestBodyAsync(req, keepStreamOpen: true);

            // Get request object
            var request = JsonConvert.DeserializeObject<GetResourceScheduleRequest>(requestBody);

            //  Validate request and return if request is invalid
            ValidationResult validationResult = await _getResourceScheduleGetRequestValidator.ValidateAsync(request);
            if (!validationResult.IsValid)
            {
                return new BadRequestObjectResult(validationResult.Errors.Select(e => new
                {
                    e.ErrorCode,
                    e.PropertyName,
                    e.ErrorMessage
                }));
            }

            // Send command
            var query = _mapper.Map<GetResourceScheduleQuery>(request);
            var queryResponse = await _mediator.Send(query);

            var response = _mapper.Map<List<GetResourceScheduleResponse>>(queryResponse);

            if (response == null || !response.Any())
            {
                return new NotFoundResult();
            }

            _logger.LogInformation($"Response : {System.Text.Json.JsonSerializer.Serialize(response)}");
            _logger.LogInformation("Function Call : GetResourceSchedule Completed");

            return new OkObjectResult(response);
        }

        [Function("CreateUpdateResourceSchedule")]
        [OpenApiOperation(operationId: "CreateUpdateResourceSchedule")]
        [OpenApiRequestBody("application/json", typeof(List<CreateUpdateResourceScheduleRequest>), Required = true)]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(DefaultResponseModel))]
        public async Task<IActionResult> CreateResourceSchedule([HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "Scheduler/createupdateresourceschedule")] HttpRequest req)
        {
            _logger.LogInformation("Function Call : CreateUpdateResourceSchedule Started");


            // Get request body
           string requestBody = await _httpRequestBodyReader.ReadRequestBodyAsync(req, keepStreamOpen: true);

            // Get request object
            var request = JsonConvert.DeserializeObject<CreateUpdateResourceScheduleRequest>(requestBody);

            //  Validate request and return if request is invalid
            ValidationResult validationResult = await _createResourceScheduleRequestValidator.ValidateAsync(request);
            if (!validationResult.IsValid)
            {
                return new BadRequestObjectResult(validationResult.Errors.Select(e => new
                {
                    e.ErrorCode,
                    e.PropertyName,
                    e.ErrorMessage
                }));
            }

            // Send command
            var query = _mapper.Map<CreateUpdateResourceScheduleCommand>(request);
            var queryResponse = await _mediator.Send(query);

            var response = _mapper.Map<DefaultResponseModel>(queryResponse); ;

            if (response == null)
            {
                return new NotFoundResult();
            }

            _logger.LogInformation($"Response : {System.Text.Json.JsonSerializer.Serialize(response)}");
            _logger.LogInformation("Function Call : CreateUpdateResourceSchedule Completed");

            return new OkObjectResult(response);
        }

        [Function("GetCurrentTeamResources")]
        [OpenApiOperation(operationId: "GetCurrentTeamResources")]
        [OpenApiRequestBody("application/json", typeof(GetTeamResourcesRequest), Required = true)]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(GetTeamResourcesRespose))]
        public async Task<IActionResult> GetCurrentTeamResources([HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "Scheduler/getcurrentteamresources")] HttpRequest req)
        {
            _logger.LogInformation("Function Call : GetCurrentTeamResources Started");

            // Get request body
            string requestBody = await _httpRequestBodyReader.ReadRequestBodyAsync(req, keepStreamOpen: true);

            // Get request object
            var request = JsonConvert.DeserializeObject<GetTeamResourcesRequest>(requestBody);

            //  Validate request and return if request is invalid
            ValidationResult validationResult = await _getTeamResourcesRequestValidator.ValidateAsync(request);
            if (!validationResult.IsValid)
            {
                return new BadRequestObjectResult(validationResult.Errors.Select(e => new
                {
                    e.ErrorCode,
                    e.PropertyName,
                    e.ErrorMessage
                }));
            }

            // Send command
            var query = _mapper.Map<GetTeamResourcesQuery>(request);
            var queryResponse = await _mediator.Send(query);

            var response = _mapper.Map<List<GetTeamResourcesRespose>>(queryResponse); ;

            if (response == null)
            {
                return new NotFoundResult();
            }

            _logger.LogInformation($"Response : {System.Text.Json.JsonSerializer.Serialize(response)}");
            _logger.LogInformation("Function Call : GetCurrentTeamResources Completed");

            return new OkObjectResult(response);
        }

        [Function("GetInternalTeamResources")]
        [OpenApiOperation(operationId: "GetInternalTeamResources")]
        [OpenApiRequestBody("application/json", typeof(GetTeamResourcesRequest), Required = true)]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(GetTeamResourcesRespose))]
        public async Task<IActionResult> GetInternalTeamResources([HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "Scheduler/getinternalteamresources")] HttpRequest req)
        {
            _logger.LogInformation("Function Call : GetCurrentTeamResources Started");

            // Get request body
            string requestBody = await _httpRequestBodyReader.ReadRequestBodyAsync(req, keepStreamOpen: true);

            // Get request object
            var request = JsonConvert.DeserializeObject<GetTeamResourcesRequest>(requestBody);

            //  Validate request and return if request is invalid
            ValidationResult validationResult = await _getTeamResourcesRequestValidator.ValidateAsync(request);
            if (!validationResult.IsValid)
            {
                return new BadRequestObjectResult(validationResult.Errors.Select(e => new
                {
                    e.ErrorCode,
                    e.PropertyName,
                    e.ErrorMessage
                }));
            }

            // Send command
            var query = _mapper.Map<GetInternalTeamResourcesQuery>(request);
            var queryResponse = await _mediator.Send(query);

            var response = _mapper.Map<List<GetTeamResourcesRespose>>(queryResponse); ;

            if (response == null)
            {
                return new NotFoundResult();
            }

            _logger.LogInformation($"Response : {System.Text.Json.JsonSerializer.Serialize(response)}");
            _logger.LogInformation("Function Call : GetCurrentTeamResources Completed");

            return new OkObjectResult(response);
        }

        [Function("GetExternalTeamResources")]
        [OpenApiOperation(operationId: "GetExternalTeamResources")]
        [OpenApiRequestBody("application/json", typeof(GetExternalTeamResourcesRequest), Required = true)]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(GetTeamResourcesRespose))]
        public async Task<IActionResult> GetExternalTeamResources([HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "Scheduler/getexternalteamresources")] HttpRequest req)
        {
            _logger.LogInformation("Function Call : GetExternalTeamResources Started");

            // Get request body
            string requestBody = await _httpRequestBodyReader.ReadRequestBodyAsync(req, keepStreamOpen: true);

            // Get request object
            var request = JsonConvert.DeserializeObject<GetExternalTeamResourcesRequest>(requestBody);

            //  Validate request and return if request is invalid
            ValidationResult validationResult = await _getExternalTeamResourcesRequestValidator.ValidateAsync(request);
            if (!validationResult.IsValid)
            {
                return new BadRequestObjectResult(validationResult.Errors.Select(e => new
                {
                    e.ErrorCode,
                    e.PropertyName,
                    e.ErrorMessage
                }));
            }

            // Send command
            var query = _mapper.Map<GetExternalTeamResourcesQuery>(request);
            var queryResponse = await _mediator.Send(query);

            var response = _mapper.Map<List<GetTeamResourcesRespose>>(queryResponse); ;

            if (response == null)
            {
                return new NotFoundResult();
            }

            _logger.LogInformation($"Response : {System.Text.Json.JsonSerializer.Serialize(response)}");
            _logger.LogInformation("Function Call : GetExternalTeamResources Completed");

            return new OkObjectResult(response);
        }

        [Function("GetWeeklyPlanChart")]
        [OpenApiOperation(operationId: "GetWeeklyPlanChart")]
        [OpenApiRequestBody("application/json", typeof(ResourceScheduleGetWeeklyPlanChartRequest), Required = true)]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(ResourceScheduleGetWeeklyPlanChartResponse))]
        public async Task<IActionResult> GetWeeklyPlanChart([HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "Scheduler/getweeklyplanchart")] HttpRequest req)
        {
            _logger.LogInformation("Function Call : GetWeeklyPlanChart Started");

            // Get request body
            string requestBody = await _httpRequestBodyReader.ReadRequestBodyAsync(req, keepStreamOpen: true);

            // Get request object
            var request = JsonConvert.DeserializeObject<ResourceScheduleGetWeeklyPlanChartRequest>(requestBody);

            //  Validate request and return if request is invalid
            ValidationResult validationResult = await _resourceScheduleGetWeeklyPlanChartRequestValidator.ValidateAsync(request);
            if (!validationResult.IsValid)
            {
                return new BadRequestObjectResult(validationResult.Errors.Select(e => new
                {
                    e.ErrorCode,
                    e.PropertyName,
                    e.ErrorMessage
                }));
            }

            // Send command
            var query = _mapper.Map<ResourceScheduleGetWeeklyPlanChartQuery>(request);
            var queryResponse = await _mediator.Send(query);

            var response = _mapper.Map<ResourceScheduleGetWeeklyPlanChartResponse>(queryResponse); ;

            if (response == null || response.WeekChartDataList == null || !response.WeekChartDataList.Any())
            {
                return new NotFoundResult();
            }

            var responseAsArray = response.WeekChartDataList;

            _logger.LogInformation($"Response : {System.Text.Json.JsonSerializer.Serialize(responseAsArray)}");
            _logger.LogInformation("Function Call : GetWeeklyPlanChart Completed");

            return new OkObjectResult(responseAsArray);
        }
    }
}
