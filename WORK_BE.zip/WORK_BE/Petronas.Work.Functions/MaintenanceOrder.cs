using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using AutoMapper;
using FluentValidation;
using FluentValidation.Results;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using Petronas.Work.Core.Enumerations;
using Petronas.Work.Core.Utilities;
using Petronas.Work.Domain.Commands;
using Petronas.Work.Domain.Queries;
using Petronas.Work.Functions.Models;
using Petronas.Work.Functions.RequestModels;
using Petronas.Work.Functions.ResponseModels;

namespace Petronas.Work.Functions
{
    public class MaintenanceOrder
    {
        private readonly ILogger<MaintenanceOrder> _logger;
        private readonly HttpRequestBodyReader _httpRequestBodyReader;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private IValidator<MaintenanceOrderSearchRequest> _maintenanceOrderSearchRequestModelValidator;
        private IValidator<CreateScheduleRequest> _createScheduleRequestModelValidator;
        private IValidator<UpdateScheduleRequest> _updateScheduleRequestModelValidator;
        private IValidator<MaintenanceOrderWeeklyAvailabilityRequest> _maintenanceOrderWeeklyAvailabilityModelValidator;
        private IValidator<MaintenanceOrderWeeklyPlanChartGetRequest> _maintenanceOrderWeeklyPlanChartGetRequestValidator;

        public MaintenanceOrder(ILogger<MaintenanceOrder> logger, IMediator mediator, IMapper mapper, HttpRequestBodyReader httpRequestBodyReader,
            IValidator<MaintenanceOrderSearchRequest> maintenanceOrderSearchRequestModelValidator, IValidator<CreateScheduleRequest> createScheduleRequestModelValidator
            , IValidator<UpdateScheduleRequest> updateScheduleRequestModelValidator, IValidator<MaintenanceOrderWeeklyAvailabilityRequest> maintenanceOrderWeeklyAvailabilityRequest
            , IValidator<MaintenanceOrderWeeklyPlanChartGetRequest> maintenanceOrderWeeklyPlanChartGetRequestValidator
            )
        {
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _httpRequestBodyReader = httpRequestBodyReader ?? throw new ArgumentNullException();
            _maintenanceOrderSearchRequestModelValidator = maintenanceOrderSearchRequestModelValidator;
            _createScheduleRequestModelValidator = createScheduleRequestModelValidator;
            _updateScheduleRequestModelValidator = updateScheduleRequestModelValidator;
            _maintenanceOrderWeeklyAvailabilityModelValidator = maintenanceOrderWeeklyAvailabilityRequest;
            _maintenanceOrderWeeklyPlanChartGetRequestValidator = maintenanceOrderWeeklyPlanChartGetRequestValidator;
        }

        [Function("SearchMaintenanceOrder")]
        [OpenApiOperation(operationId: "SearchMaintenanceOrder")]
        [OpenApiRequestBody("application/json", typeof(MaintenanceOrderSearchRequest), Required = true)]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(MaintenanceOrderSearchResponse))]
        public async Task<IActionResult> SearchMaintenanceOrder([HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "maintenanceorder/search")] HttpRequest req)
        {
            _logger.LogInformation("Function Call : SearchMaintenanceOrder Started");

            // Get request body
            string requestBody = await _httpRequestBodyReader.ReadRequestBodyAsync(req, keepStreamOpen: true);

            // Get request object
            var request = JsonConvert.DeserializeObject<MaintenanceOrderSearchRequest>(requestBody);

            // Validate request and return if request is invalid
            ValidationResult validationResult = await _maintenanceOrderSearchRequestModelValidator.ValidateAsync(request);
            if (!validationResult.IsValid)
            {
                return new BadRequestObjectResult(validationResult.Errors.Select(e => new
                {
                    e.ErrorCode,
                    e.PropertyName,
                    e.ErrorMessage
                }));
            }

            // Send command
            var searchQuery = _mapper.Map<MaintenanceOrderSearchQuery>(request);
            var queryResponse = await _mediator.Send(searchQuery);

            var response = _mapper.Map<MaintenanceOrderSearchResponse>(queryResponse);

            if (response == null || response.Data == null || !response.Data.Any())
            {
                return new NotFoundResult();
            }

            _logger.LogInformation($"Response : {System.Text.Json.JsonSerializer.Serialize(response)}");
            _logger.LogInformation("Function Call : SearchMaintenanceOrder Completed");

            return new OkObjectResult(response);
        }

        [Function("CreateSchedule")]
        [OpenApiOperation(operationId: "CreateSchedule")]
        [OpenApiRequestBody("application/json", typeof(CreateScheduleRequest), Required = true)]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(DefaultResponseModel))]
        public async Task<IActionResult> CreateSchedule([HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "maintenanceorder/create")] HttpRequest req)
        {
            _logger.LogInformation("Function Call : CreateSchedule Started");

            // Get request body
            string requestBody = await _httpRequestBodyReader.ReadRequestBodyAsync(req, keepStreamOpen: true);

            // Get request object
            var request = JsonConvert.DeserializeObject<CreateScheduleRequest>(requestBody);

            // Validate request and return if request is invalid
            ValidationResult validationResult = await _createScheduleRequestModelValidator.ValidateAsync(request);
            if (!validationResult.IsValid)
            {
                return new BadRequestObjectResult(validationResult.Errors.Select(e => new
                {
                    e.ErrorCode,
                    e.PropertyName,
                    e.ErrorMessage
                }));
            }

            // Send command
            var createScheduleQuery = _mapper.Map<CreateScheduleCommand>(request);
            var queryResponse = await _mediator.Send(createScheduleQuery);

            var response = _mapper.Map<DefaultResponseModel>(queryResponse);



            if (response == null)
            {
                return new NotFoundResult();
            }
            _logger.LogInformation($"Response : {System.Text.Json.JsonSerializer.Serialize(response)}");
            _logger.LogInformation("Function Call : CreateSchedule Completed");
            return new OkObjectResult(response);
        }

        [Function("UpdateSchedule")]
        [OpenApiOperation(operationId: "UpdateSchedule")]
        [OpenApiRequestBody("application/json", typeof(UpdateScheduleRequest), Required = true)]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(UpdateScheduleResponse))]
        public async Task<IActionResult> UpdateSchedule([HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "maintenanceorder/update")] HttpRequest req)
        {
            _logger.LogInformation("Function Call : UpdateSchedule Started");

            // Get request body
            string requestBody = await _httpRequestBodyReader.ReadRequestBodyAsync(req, keepStreamOpen: true);

            // Get request object
            var request = JsonConvert.DeserializeObject<UpdateScheduleRequest>(requestBody);

            // Validate request and return if request is invalid
            ValidationResult validationResult = await _updateScheduleRequestModelValidator.ValidateAsync(request);
            if (!validationResult.IsValid)
            {
                return new BadRequestObjectResult(validationResult.Errors.Select(e => new
                {
                    e.ErrorCode,
                    e.PropertyName,
                    e.ErrorMessage
                }));
            }

            // Send command
            var updateScheduleQuery = _mapper.Map<UpdateScheduleCommand>(request);
            var queryResponse = await _mediator.Send(updateScheduleQuery);

            var response = _mapper.Map<DefaultResponseModel>(queryResponse);

            _logger.LogInformation($"Response : {System.Text.Json.JsonSerializer.Serialize(response)}");
            _logger.LogInformation("Function Call : UpdateSchedule Completed");

            if (response == null)
            {
                return new NotFoundResult();
            }

            return new OkObjectResult(response);
        }

        [Function("GetMaintenanceOrderWeeklyPlanChart")]
        [OpenApiOperation(operationId: "GetMaintenanceOrderWeeklyPlanChart")]
        [OpenApiRequestBody("application/json", typeof(MaintenanceOrderWeeklyPlanChartGetRequest), Required = true)]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(MaintenanceOrderWeeklyPlanChartGetResponse))]
        public async Task<IActionResult> GetMaintenanceOrderWeeklyPlanChart([HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "maintenanceorder/getweeklyplanchart")] HttpRequest req)
        {
            _logger.LogInformation("Function Call : GetMaintenanceOrderWeeklyPlanChart Started");

            // Get request body
            string requestBody = await _httpRequestBodyReader.ReadRequestBodyAsync(req, keepStreamOpen: true);

            // Get request object
            var request = JsonConvert.DeserializeObject<MaintenanceOrderWeeklyPlanChartGetRequest>(requestBody);

            if ((request.StartDate.HasValue && request.EndDate.HasValue) ||
                (request.StartDate.HasValue && !request.EndDate.HasValue) ||
                (!request.StartDate.HasValue && request.EndDate.HasValue)
                )
            {
                // Validate request and return if request is invalid
                ValidationResult validationResult = await _maintenanceOrderWeeklyPlanChartGetRequestValidator.ValidateAsync(request);
                if (!validationResult.IsValid)
                {
                    return new BadRequestObjectResult(validationResult.Errors.Select(e => new
                    {
                        e.ErrorCode,
                        e.PropertyName,
                        e.ErrorMessage
                    }));
                }
            }
            else
            {
                if (!request.StartDate.HasValue || request.StartDate.Value == DateTime.MinValue)
                {
                    request.StartDate = DateTime.Now;
                }

                switch (request.WeekOperator)
                {
                    case (WeekOperator.Next):
                        {
                            request.StartDate = DateTime.Now;
                            request.EndDate = CultureInfo.CurrentCulture.Calendar.AddWeeks(DateTime.Now, request.NumberOfWeeks);
                            break;
                        }
                    case (WeekOperator.Previous):
                        {
                            request.StartDate = CultureInfo.CurrentCulture.Calendar.AddWeeks(DateTime.Now, (request.NumberOfWeeks * -1));
                            request.EndDate = DateTime.Now;
                            break;
                        }
                    default:
                        {
                            if ((!request.EndDate.HasValue || request.EndDate == DateTime.MinValue) && request.StartDate.HasValue)
                            {
                                request.EndDate = CultureInfo.CurrentCulture.Calendar.AddWeeks(request.StartDate.Value, 5);
                            }
                            break;
                        }
                }
            }

            // Send command
            var query = _mapper.Map<MaintenanceOrderWeeklyPlanChartGetQuery>(request);
            var queryResponse = await _mediator.Send(query);

            var response = _mapper.Map<List<MaintenanceOrderWeeklyPlanChartGetResponse>>(queryResponse);

            if (response == null || !response.Any())
            {
                return new NotFoundResult();
            }

            _logger.LogInformation($"Response : {System.Text.Json.JsonSerializer.Serialize(response)}");
            _logger.LogInformation("Function Call : GetMaintenanceOrderWeeklyPlanChart Completed");

            return new OkObjectResult(response);
        }

        [Function("GetMaintenanceOrderWeeklyAvailability")]
        [OpenApiOperation(operationId: "GetMaintenanceOrderWeeklyAvailability")]
        [OpenApiRequestBody("application/json", typeof(MaintenanceOrderWeeklyPlanChartGetRequest), Required = true)]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(MaintenanceOrderWeeklyPlanChartGetResponse))]
        public async Task<IActionResult> GetMaintenanceOrderWeeklyAvailability([HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "maintenanceorder/getmaintenanceorderweeklyavailability")] HttpRequest req)
        {
            _logger.LogInformation("Function Call : GetMaintenanceOrderWeeklyAvailability Started");

            // Get request body
            string requestBody = await _httpRequestBodyReader.ReadRequestBodyAsync(req, keepStreamOpen: true);

            // Get request object
            var request = JsonConvert.DeserializeObject<MaintenanceOrderWeeklyAvailabilityRequest>(requestBody);

            //  Validate request and return if request is invalid
            ValidationResult validationResult = await _maintenanceOrderWeeklyAvailabilityModelValidator.ValidateAsync(request);
            if (!validationResult.IsValid)
            {
                return new BadRequestObjectResult(validationResult.Errors.Select(e => new
                {
                    e.ErrorCode,
                    e.PropertyName,
                    e.ErrorMessage
                }));
            }

            // Send command
            var query = _mapper.Map<MaintenanceOrderWeeklyAvailabilityQuery>(request);
            var queryResponse = await _mediator.Send(query);
            var response = _mapper.Map<List<MaintenanceOrderWeeklyAvailabilityResponse>>(queryResponse);

            if (response == null || !response.Any())
            {
                return new NotFoundResult();
            }

            _logger.LogInformation($"Response : {System.Text.Json.JsonSerializer.Serialize(response)}");
            _logger.LogInformation("Function Call : GetMaintenanceOrderWeeklyAvailability Completed");

            return new OkObjectResult(response);
        }
    }
}

