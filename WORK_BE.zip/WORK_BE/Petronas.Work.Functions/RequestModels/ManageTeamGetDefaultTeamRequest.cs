﻿using Petronas.Work.Functions.Models;
using System;
using System.Collections.Generic;

namespace Petronas.Work.Functions.RequestModels
{
    public class ManageTeamGetDefaultTeamRequest : RequestBase
    {
        public Guid TeamId { get; set; }
    }
}
