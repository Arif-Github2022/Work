﻿using Petronas.Work.Core.Enumerations;
using System;

namespace Petronas.Work.Functions.Models
{
    public class MaintenanceOrderWeeklyPlanChartGetRequest : RequestBase
    {
        public Guid TeamId { get; set; }

        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }

        public WeekOperator WeekOperator { get; set; }

        public int NumberOfWeeks { get; set; }
    }
}
