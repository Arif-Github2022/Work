﻿using Petronas.Work.Functions.Models;
using System;

namespace Petronas.Work.Functions.RequestModels
{
    public class ResourceScheduleGetWeeklyPlanChartRequest : RequestBase
    {
        public Guid TeamId { get; set; }

        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }
    }
}
