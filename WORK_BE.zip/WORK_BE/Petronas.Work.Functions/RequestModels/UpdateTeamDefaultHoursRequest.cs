﻿using Petronas.Work.Functions.ResponseModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Functions.RequestModels
{
    public class UpdateTeamDefaultHoursRequest:ResponseBase
    {
        public List<resourceDefaultWorkHours> ResourceDefaultWorkHours { get; set; }
    }

    public class resourceDefaultWorkHours

    {
        public Guid Id { get; set; }
        public string Name { get; set; }

        public List<weekDayDefaultWorkHours> WeekDayDefaultWorkHours { get; set; }
    }

    public class weekDayDefaultWorkHours
    {
        public string WeekDay { get; set; }
        public int WorkHours { get; set; }
    }
}
