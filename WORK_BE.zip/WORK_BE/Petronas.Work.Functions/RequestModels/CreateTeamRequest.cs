﻿using Petronas.Work.Functions.Models;

namespace Petronas.Work.Functions.RequestModels
{
    public class CreateTeamRequest : RequestBase
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string Id { get; set; }
        public string Company { get; set; }

        public string AceId { get; set; }
    }
}
