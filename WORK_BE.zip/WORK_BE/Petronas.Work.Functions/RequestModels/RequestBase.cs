﻿namespace Petronas.Work.Functions.Models
{
    public abstract class RequestBase
    {
        public string TraceId { get; set; }
    }
}
