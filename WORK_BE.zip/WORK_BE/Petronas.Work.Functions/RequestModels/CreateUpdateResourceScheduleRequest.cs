﻿using Petronas.Work.Functions.Models;
using System;
using System.Collections.Generic;

namespace Petronas.Work.Functions.RequestModels
{
    public class CreateUpdateResourceScheduleRequest : RequestBase
    {
      public List<ResourceScheduleDetails> ResourceSchedule { get; set; }

    }

    public class ResourceScheduleDetails
    {
        public Guid ResourceId { get; set; }
        
        public string ResourceName { get; set; }

        public string ResourceCompany { get; set; }

        public bool IsResourceContractor { get; set; }

        public string ResourceAceId { get; set; }

        public Guid WorkOrderId { get; set; }
        
        public DateTime? PlannedDate { get; set; }
        
        public int PlannedWorkHours { get; set; }
    }

}
