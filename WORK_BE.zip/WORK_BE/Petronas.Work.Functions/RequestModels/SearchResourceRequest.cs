﻿using Petronas.Work.Functions.Models;

namespace Petronas.Work.Functions.RequestModels
{
    public class SearchResourceRequest : RequestBase
    {
        public string Name { get; set; }
    }
}
