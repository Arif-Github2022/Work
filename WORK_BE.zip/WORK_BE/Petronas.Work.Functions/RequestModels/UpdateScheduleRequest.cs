﻿using Petronas.Work.Functions.Models;
using System;

namespace Petronas.Work.Functions.RequestModels
{
    public class UpdateScheduleRequest: RequestBase
    {
        public Guid WorkOrderId { get; set; }
        public DateTime ScheduleStartDate { get; set; }
        public DateTime ScheduleEndDate { get; set; }
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }
    }
}
