﻿using Petronas.Work.Functions.Models;
using System;

namespace Petronas.Work.Functions.RequestModels
{
    public class CreateScheduleRequest : RequestBase
    {
        public Guid WorkOrderId { get; set; }
        public DateTime ScheduleStartDate { get; set; }
        public DateTime ScheduleEndDate { get; set; }
       
    }
}
