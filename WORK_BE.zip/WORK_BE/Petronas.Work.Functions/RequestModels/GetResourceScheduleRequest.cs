﻿using Petronas.Work.Functions.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Functions.RequestModels
{
    public class GetResourceScheduleRequest : RequestBase
    {
        public Guid TeamId { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }
    }
}
