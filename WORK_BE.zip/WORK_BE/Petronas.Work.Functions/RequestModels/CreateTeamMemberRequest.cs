﻿using Petronas.Work.Domain.Models;
using System.Collections.Generic;

namespace Petronas.Work.Functions.RequestModels
{
    public class CreateTeamMemberRequest
    {
        public string? TeamId { get; set; }
        public List<ResourceInformation>? ResourceInformation { get; set; }
    }
}
