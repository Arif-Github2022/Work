﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Petronas.Work.Core.Constants;
using Petronas.Work.Data.Infrastructure.Core;

namespace Petronas.Work.Functions.Factories
{
    /// <summary>
    /// <see cref="WorkDbContextFactory"/> is used initializing DbContext during design time.
    /// This is used ONLY in case of executing Entity Framework Core commands from 'Package Manager Concole'. This will NOT be used while running the
    /// application.
    /// Example : Add-Migration, Update-Database, etc.
    /// </summary>
    public class WorkDbContextFactory : IDesignTimeDbContextFactory<WorkDbContext>
    {
        public WorkDbContext CreateDbContext(string[] args)
        {
            var connectionString = "Server=Developer-Vm;Initial Catalog=WorkDb2;Persist Security Info=False;User ID=sa;Password=A@sh@635210#;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=True;Connection Timeout=90;";
            var optionsBuilder = new DbContextOptionsBuilder<WorkDbContext>();
            optionsBuilder.UseSqlServer(connectionString, x => x.MigrationsAssembly("Petronas.Work.Data"));

            return new WorkDbContext(optionsBuilder.Options);
        }
    }
}
