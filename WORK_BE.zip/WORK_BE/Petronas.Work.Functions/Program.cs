﻿using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Extensions.OpenApi.Extensions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Petronas.Work.Core.Utilities;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Petronas.Work.Data.Infrastructure.Core;
using System;
using Microsoft.EntityFrameworkCore;
using Petronas.Work.Core.Constants;
using Petronas.Work.Data.Infrastructure.Interface;
using Petronas.Work.Data.Infrastructure.Repositories;
using FluentValidation;
using Serilog.Events;
using Serilog.Sinks.MSSqlServer;
using Serilog;
using System.Collections.ObjectModel;
using System.Data;
using System.Reflection;
using Petronas.Work.Functions.Middleware;
using Petronas.Work.Domain.Handlers.QueryHandlers;
using Petronas.Work.Integration.WebClient.Interface;
using Petronas.Work.Integration.WebClient;
using Petronas.Work.Integration.Ace.Interface;
using Petronas.Work.Integration.Ace;
using Petronas.Work.Integration.Sap.Interface;
using Petronas.Work.Integration.Sap;
using Petronas.Work.Domain.Handlers.CommadHandlers;
using Azure.Identity;
using Microsoft.Extensions.Configuration;
using Azure.Security.KeyVault.Secrets;
using Petronas.Work.Domain.Common.Interface;
using Petronas.Work.Domain.Common;

namespace Petronas.Work.Functions
{
    public class Program
    {
        static async Task Main(string[] args)
        {

            var host = new HostBuilder()
              //  .ConfigureAppConfiguration(ConfigureAppConfiguration)
                .ConfigureFunctionsWebApplication(ConfigureWorker)
                .ConfigureServices(ConfigureServices)
                .ConfigureOpenApi()
                .ConfigureLogging(ConfigureLogging)
                .Build();

            await host.RunAsync();
        }

        static void ConfigureWorker(IFunctionsWorkerApplicationBuilder worker)
        {
            // Register custom middlewares with the worker
            worker.UseMiddleware<StampHttpRequestTraceIdMiddleware>();
            worker.UseMiddleware<ExceptionHandlingMiddleware>();
        }

        static void ConfigureAppConfiguration(HostBuilderContext context, IConfigurationBuilder configurationBuilder)
        {
            configurationBuilder.AddEnvironmentVariables();
            var keyVaultEndpoint = Environment.GetEnvironmentVariable("VaultURI", EnvironmentVariableTarget.Process);
            var tenantId = Environment.GetEnvironmentVariable("TenantId", EnvironmentVariableTarget.Process);

            //var clientId = Environment.GetEnvironmentVariable("ClientId", EnvironmentVariableTarget.Process);
            //var clientSecret = Environment.GetEnvironmentVariable("ClientSecret", EnvironmentVariableTarget.Process);

            if (!string.IsNullOrEmpty(keyVaultEndpoint))
            {
                var defaultAzureCredential = new DefaultAzureCredential(new DefaultAzureCredentialOptions
                {
                    AdditionallyAllowedTenants = { tenantId }
                });

                // authenticating a service principal with a client secret
                //var credential = new ClientSecretCredential(tenantId, clientId, clientSecret);
                //var keyVaultClient = new SecretClient(new Uri(keyVaultEndpoint), credential);

                var keyVaultClient = new SecretClient(new Uri(keyVaultEndpoint), defaultAzureCredential);
                configurationBuilder.AddAzureKeyVault(keyVaultClient.VaultUri, defaultAzureCredential);
            }
        }

        static void ConfigureServices(HostBuilderContext context, IServiceCollection services)
        {
            var workDbConnectionString = Environment.GetEnvironmentVariable(AppSettingConstant.ConnectionStrings.WorkDbConnectionString, EnvironmentVariableTarget.Process);
            services.AddDbContext<WorkDbContext>(options =>
            {
                SqlServerDbContextOptionsExtensions.UseSqlServer(options, workDbConnectionString, b => b.MigrationsAssembly(AppSettingConstant.AssemblyNames.Petronas_Work_Data));
            });

            // Get external integration settings
            
            // Ace
            var aceBaseUri = Environment.GetEnvironmentVariable(AppSettingConstant.ExternalIntegrations.Ace.AceBaseUri, EnvironmentVariableTarget.Process);
            var aceResourceUri = Environment.GetEnvironmentVariable(AppSettingConstant.ExternalIntegrations.Ace.AceResourceUri, EnvironmentVariableTarget.Process);
            var aceClientId = Environment.GetEnvironmentVariable(AppSettingConstant.ExternalIntegrations.Ace.AceClientId, EnvironmentVariableTarget.Process);
            var aceClientSecret = Environment.GetEnvironmentVariable(AppSettingConstant.ExternalIntegrations.Ace.AceClientSecret, EnvironmentVariableTarget.Process);
            var aceAuthorization = Environment.GetEnvironmentVariable(AppSettingConstant.ExternalIntegrations.Ace.AceAuthorization, EnvironmentVariableTarget.Process);
            var aceToken = Environment.GetEnvironmentVariable(AppSettingConstant.ExternalIntegrations.Ace.AceToken, EnvironmentVariableTarget.Process);

            // SAP
            var sapBaseUri = Environment.GetEnvironmentVariable(AppSettingConstant.ExternalIntegrations.Sap.SapBaseUri, EnvironmentVariableTarget.Process);
            var sapClientId = Environment.GetEnvironmentVariable(AppSettingConstant.ExternalIntegrations.Sap.SapClientId, EnvironmentVariableTarget.Process);
            var sapClientSecret = Environment.GetEnvironmentVariable(AppSettingConstant.ExternalIntegrations.Sap.SapClientSecret, EnvironmentVariableTarget.Process);

            var sapGetWorkOrdersResourceUri = Environment.GetEnvironmentVariable(AppSettingConstant.ExternalIntegrations.Sap.SapGetWorkOrdersResourceUri, EnvironmentVariableTarget.Process);
            var sapGetWorkOperationsResourceUri = Environment.GetEnvironmentVariable(AppSettingConstant.ExternalIntegrations.Sap.SapGetWorkOperationsResourceUri, EnvironmentVariableTarget.Process);

            // Register singleton services
            services.AddSingleton<HttpRequestBodyReader>();
            services.AddSingleton<WeekCalculator>();
            services.AddSingleton(new Integration.Ace.Configuration.Settings(aceBaseUri, aceResourceUri, aceClientId, aceClientSecret, aceAuthorization, aceToken));

            services.AddSingleton(new Integration.Sap.Configuration.Settings(sapBaseUri, sapClientId, sapClientSecret, sapGetWorkOrdersResourceUri, sapGetWorkOperationsResourceUri));


            // Register HttpClient Factory
            services.AddHttpClient<IHttpClientProxy, HttpClientProxy>();

            // Register external Integrations
            services.AddTransient<IAceHttpClientProxy, AceHttpClientProxy>();
            services.AddTransient<ISapHttpClientProxy, SapHttpClientProxy>();

            //Unit Of Work
            services.AddScoped<IWorkDbUnitOfWork, WorkDbUnitOfWork>();

            //Repository
            services.AddScoped<DbContext, WorkDbContext>();
            services.AddScoped(typeof(IRepository<>), typeof(Repository<>));

            // Register Transient Services
            services.AddTransient<IResourceWeekWorkHourCalculator, ResourceWeekWorkHourCalculator>();

            //AutoMapper
            services.AddAutoMapper(typeof(Program).GetTypeInfo().Assembly);
            services.AddAutoMapper(typeof(MaintenanceOrderSearchQueryHandler).GetTypeInfo().Assembly);

            //Validators
            AssemblyScanner.FindValidatorsInAssembly(typeof(Program).GetTypeInfo().Assembly)
                .ForEach(validator =>
                {
                    services.AddScoped(validator.InterfaceType, validator.ValidatorType);

                    // Also register it as its concrete type as well as the interface type
                    services.Add(ServiceDescriptor.Transient(validator.ValidatorType, validator.ValidatorType));
                });

            //MediatR
            services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(Program).GetTypeInfo().Assembly));
            services.AddMediatR(cfg => cfg.RegisterServicesFromAssembly(typeof(MaintenanceOrderSearchQueryHandler).GetTypeInfo().Assembly));
        }

        static void ConfigureLogging(HostBuilderContext context, ILoggingBuilder logBuilder)
        {
            var workDbConnectionString = Environment.GetEnvironmentVariable(AppSettingConstant.ConnectionStrings.WorkDbConnectionString, EnvironmentVariableTarget.Process);
            var columnoptions = new ColumnOptions
            {
                AdditionalColumns = new Collection<SqlColumn>
                {
                    new SqlColumn("TraceId",SqlDbType.UniqueIdentifier)
                }
            };
            columnoptions.Store.Remove(StandardColumn.Properties);
            columnoptions.Store.Remove(StandardColumn.MessageTemplate);
            Log.Logger = new LoggerConfiguration().Enrich.FromLogContext()
                .WriteTo.MSSqlServer(workDbConnectionString, sinkOptions: new MSSqlServerSinkOptions
                {
                    TableName = "Logs",
                    SchemaName = "dbo",
                    AutoCreateSqlTable = true
                },
                    null, null, LogEventLevel.Information, null, columnoptions, null, null)
                .MinimumLevel.Override("Microsoft", LogEventLevel.Error)
                .CreateLogger();

            logBuilder.Services.AddLogging(lb =>
            {
                lb.AddSerilog(Log.Logger, true);

            });
        }
    }
}
