﻿using AutoMapper;
using FluentValidation;
using FluentValidation.Results;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using Petronas.Work.Core.Utilities;
using Petronas.Work.Domain.Commands;
using Petronas.Work.Domain.Models;
using Petronas.Work.Domain.Queries;
using Petronas.Work.Functions.RequestModels;
using Petronas.Work.Functions.ResponseModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;


namespace Petronas.Work.Functions
{
    public class TeamManagement
    {
        private readonly ILogger<TeamManagement> _logger;
        private readonly HttpRequestBodyReader _httpRequestBodyReader;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;
        private IValidator<CreateTeamRequest> _createTeamRequestValidator;
        private IValidator<ManageTeamGetDefaultTeamRequest> _manageTeamGetDefaultTeamRequest;
        private IValidator<GetWeekNonWorkHoursRequest> _getWeekNonWorkHoursRequestValidator;
        private IValidator<UpdateWeekNonWorkHoursRequest> _updateWeekNonWorkHoursRequest;
        private IValidator<UpdateTeamDefaultHoursRequest> _updateTeamDefaultHoursRequest;
        private IValidator<CreateTeamMemberRequest> _createTeamMemberRequest;

        public TeamManagement(ILogger<TeamManagement> logger, IMediator mediator, IMapper mapper, HttpRequestBodyReader httpRequestBodyReader,
            IValidator<CreateTeamRequest> createTeamRequest, IValidator<ManageTeamGetDefaultTeamRequest> manageTeamGetDefaultTeamRequest, IValidator<GetWeekNonWorkHoursRequest> getWeekNonWorkHoursRequestValidator, IValidator<UpdateTeamDefaultHoursRequest> updateTeamDefaultHoursRequest, IValidator<UpdateWeekNonWorkHoursRequest> updateWeekNonWorkHoursRequest, IValidator<CreateTeamMemberRequest> createTeamMemberReques)
        {
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;
            _httpRequestBodyReader = httpRequestBodyReader ?? throw new ArgumentNullException();
            _createTeamRequestValidator = createTeamRequest;
            _manageTeamGetDefaultTeamRequest = manageTeamGetDefaultTeamRequest;
            _getWeekNonWorkHoursRequestValidator = getWeekNonWorkHoursRequestValidator;
            _updateTeamDefaultHoursRequest = updateTeamDefaultHoursRequest;
            _updateWeekNonWorkHoursRequest = updateWeekNonWorkHoursRequest;
            _createTeamMemberRequest = createTeamMemberReques;
        }




        [Function("GetTeamsList")]
        [OpenApiOperation(operationId: "GetTeamsList")]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(TeamsListResponse))]
        public async Task<IActionResult> GetTeamsList([HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "teammanagement/getteamslist")] HttpRequest req)
        {
            _logger.LogInformation("Function Call : GetTeamsList Started");
            // Send command
            var teamList = new TeamsListGetQuery();
            var response = await _mediator.Send(teamList);

            if (response == null)
            {
                return new NotFoundResult();
            }
            _logger.LogInformation($"Response : {System.Text.Json.JsonSerializer.Serialize(response)}");
            _logger.LogInformation("Function Call : CreateSchedule Completed");
            return new OkObjectResult(response);
        }

        [Function("CreateTeam")]
        [OpenApiOperation(operationId: "CreateTeam")]
        [OpenApiRequestBody("application/json", typeof(CreateTeamRequest), Required = true)]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(DefaultResponseModel))]
        public async Task<IActionResult> CreateResourceSchedule([HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "teammanagement/createteam")] HttpRequest req)
        {
            _logger.LogInformation("Function Call : CreateTeam Started");

            // Get request body
            string requestBody = await _httpRequestBodyReader.ReadRequestBodyAsync(req, keepStreamOpen: true);

            // Get request object
            var request = JsonConvert.DeserializeObject<CreateTeamRequest>(requestBody);

            // Validate request and return if request is invalid
            ValidationResult validationResult = await _createTeamRequestValidator.ValidateAsync(request);
            if (!validationResult.IsValid)
            {
                return new BadRequestObjectResult(validationResult.Errors.Select(e => new
                {
                    e.ErrorCode,
                    e.PropertyName,
                    e.ErrorMessage
                }));
            }

            // Send command
            var createScheduleQuery = _mapper.Map<CreateTeamCommand>(request);
            var queryResponse = await _mediator.Send(createScheduleQuery);

            var response = _mapper.Map<DefaultResponseModel>(queryResponse);



            if (response == null)
            {
                return new NotFoundResult();
            }
            _logger.LogInformation($"Response : {System.Text.Json.JsonSerializer.Serialize(response)}");
            _logger.LogInformation("Function Call : CreateTeam Completed");
            return new OkObjectResult(response);
        }

        [Function("GetTeamDefaultHours")]
        [OpenApiOperation(operationId: "GetTeamDefaultHours")]
        [OpenApiRequestBody("application/json", typeof(ManageTeamGetDefaultTeamRequest), Required = true)]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(ManageTeamGetDefaultTeamResponse))]
        public async Task<IActionResult> GetTeamDefaultHours([HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "teammanagement/getteamdefaulthours")] HttpRequest req)
        {
            _logger.LogInformation("Function Call : GetTeamDefaultHours Started");

            // Get request body
            string requestBody = await _httpRequestBodyReader.ReadRequestBodyAsync(req, keepStreamOpen: true);

            // Get request object
            var request = JsonConvert.DeserializeObject<ManageTeamGetDefaultTeamRequest>(requestBody);

            // Validate request and return if request is invalid
            ValidationResult validationResult = await _manageTeamGetDefaultTeamRequest.ValidateAsync(request);
            if (!validationResult.IsValid)
            {
                return new BadRequestObjectResult(validationResult.Errors.Select(e => new
                {
                    e.ErrorCode,
                    e.PropertyName,
                    e.ErrorMessage
                }));
            }

            // Send command
            var manageTeamGetQuery = _mapper.Map<ManageTeamGetDefaultTeamQuery>(request);
            var queryResponse = await _mediator.Send(manageTeamGetQuery);

            var response = _mapper.Map<List<ManageTeamGetDefaultTeamResponse>>(queryResponse);

            if (response == null)
            {
                return new NotFoundResult();
            }

            var resp = response.SelectMany(x => x.TeamDefaultWorkHours).GroupBy(i => i.ResourceId)
                       .Select(grouping =>
                           new
                           {
                               ResourceId = grouping.Key,
                               ResourceName = grouping.FirstOrDefault().ResourceName,
                               ResourceCompany = grouping.FirstOrDefault().ResourceCompany,
                               ResourceAceId = grouping.FirstOrDefault().ResourceAceId,
                               isResourceContractor = grouping.FirstOrDefault().IsResourceContractor,
                               WeekDayDefaultWorkHours = grouping.Select(k => new { k.WeekDay, k.WorkHours }).ToList()
                           }
                        ).ToList();

            _logger.LogInformation($"Response : {System.Text.Json.JsonSerializer.Serialize(resp)}");
            _logger.LogInformation("Function Call : GetTeamDefaultHours Completed");
            return new OkObjectResult(resp);
        }

        [Function("GetWeekNonWorkHours")]
        [OpenApiOperation(operationId: "GetWeekNonWorkHours")]
        [OpenApiRequestBody("application/json", typeof(GetWeekNonWorkHoursRequest), Required = true)]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(GetWeekNonWorkHoursResponse))]
        public async Task<IActionResult> GetWeekNonWorkHours([HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "teammanagement/getweeknonworkhours")] HttpRequest req)
        {
            _logger.LogInformation("Function Call : GetWeekNonWorkHours Started");

            // Get request body
            string requestBody = await _httpRequestBodyReader.ReadRequestBodyAsync(req, keepStreamOpen: true);

            // Get request object
            var request = JsonConvert.DeserializeObject<GetWeekNonWorkHoursRequest>(requestBody);

            // Validate request and return if request is invalid
            ValidationResult validationResult = await _getWeekNonWorkHoursRequestValidator.ValidateAsync(request);
            if (!validationResult.IsValid)
            {
                return new BadRequestObjectResult(validationResult.Errors.Select(e => new
                {
                    e.ErrorCode,
                    e.PropertyName,
                    e.ErrorMessage
                }));
            }

            // Send command
            var manageTeamGetQuery = _mapper.Map<GetWeekNonWorkHoursQuery>(request);
            var queryResponse = await _mediator.Send(manageTeamGetQuery);

            var response = _mapper.Map<List<GetWeekNonWorkHoursResponse>>(queryResponse);

            if (response == null)
            {
                return new NotFoundResult();
            }

            var resp = response.SelectMany(x => x.ResourceUnavailableHours).GroupBy(i => i.Id)
                        .Select(grouping =>
                            new
                            {
                                Id = grouping.Key,
                                Name = grouping.FirstOrDefault().Name,
                                teamNonWorkHours = grouping.Select(k => new { k.WeekDay, k.AwayHours }).ToList()
                            }
                         ).ToList();

            _logger.LogInformation($"Response : {System.Text.Json.JsonSerializer.Serialize(resp)}");
            _logger.LogInformation("Function Call : GetWeekNonWorkHours Completed");
            return new OkObjectResult(resp);
        }

        [Function("UpdateTeamDefaultHours")]
        [OpenApiOperation(operationId: "UpdateTeamDefaultHours")]
        [OpenApiRequestBody("application/json", typeof(List<UpdateTeamDefaultHoursRequest>), Required = true)]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(DefaultResponseModel))]
        public async Task<IActionResult> UpdateTeamDefaultHours([HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "teammanagement/updateteamdefaulthours")] HttpRequest req)
        {
            _logger.LogInformation("Function Call : UpdateTeamDefaultHours Started");

            // Get request body
            string requestBody = await _httpRequestBodyReader.ReadRequestBodyAsync(req, keepStreamOpen: true);

            // Get request object
            var request = JsonConvert.DeserializeObject<UpdateTeamDefaultHoursRequest>(requestBody);

            // Validate request and return if request is invalid
            ValidationResult validationResult = await _updateTeamDefaultHoursRequest.ValidateAsync(request);
            if (!validationResult.IsValid)
            {
                return new BadRequestObjectResult(validationResult.Errors.Select(e => new
                {
                    e.ErrorCode,
                    e.PropertyName,
                    e.ErrorMessage
                }));
            }
            // Send command
            var updateTeamQuery = _mapper.Map<UpdateTeamDefaultHoursCommand>(request);
            var queryResponse = await _mediator.Send(updateTeamQuery);
            var response = _mapper.Map<DefaultResponseModel>(queryResponse);
            if (response == null)
            {
                return new NotFoundResult();
            }
            _logger.LogInformation($"Response : {System.Text.Json.JsonSerializer.Serialize(response)}");
            _logger.LogInformation("Function Call : UpdateTeamDefaultHours Completed");
            return new OkObjectResult(response);
        }
        [Function("UpdateWeekNonWorkHours")]
        [OpenApiOperation(operationId: "UpdateWeekNonWorkHours")]
        [OpenApiRequestBody("application/json", typeof(UpdateWeekNonWorkHoursRequest), Required = true)]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(DefaultResponseResult))]
        public async Task<IActionResult> UpdateWeekNonWorkHours([HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "teammanagement/updateweeknonworkhours")] HttpRequest req)
        {
            _logger.LogInformation("Function Call : UpdateWeekNonWorkHours Started");

            // Get request body
            string requestBody = await _httpRequestBodyReader.ReadRequestBodyAsync(req, keepStreamOpen: true);

            // Get request object
            var request = JsonConvert.DeserializeObject<UpdateWeekNonWorkHoursRequest>(requestBody);

            // Validate request and return if request is invalid
            ValidationResult validationResult = await _updateWeekNonWorkHoursRequest.ValidateAsync(request);
            if (!validationResult.IsValid)
            {
                return new BadRequestObjectResult(validationResult.Errors.Select(e => new
                {
                    e.ErrorCode,
                    e.PropertyName,
                    e.ErrorMessage
                }));
            }

            // Send command
            var updateQuery = _mapper.Map<UpdateWeekNonWorkHoursCommand>(request);
            var queryResponse = await _mediator.Send(updateQuery);

            var response = _mapper.Map<DefaultResponseResult>(queryResponse);

            if (response == null)
            {
                return new NotFoundResult();
            }
            _logger.LogInformation($"Response : {System.Text.Json.JsonSerializer.Serialize(response)}");
            _logger.LogInformation("Function Call : UpdateWeekNonWorkHours Completed");
            return new OkObjectResult(response);
        }


        [Function("CreateUpdateTeamMembers")]
        [OpenApiOperation(operationId: "CreateUpdateTeamMembers")]
        [OpenApiRequestBody("application/json", typeof(CreateTeamMemberRequest), Required = true)]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/json", bodyType: typeof(DefaultResponseResult))]
        public async Task<IActionResult> CreateUpdateTeamMembers([HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "teammanagement/createupdateteammembers")] HttpRequest req)
        {
            _logger.LogInformation("Function Call : UpdateWeekNonWorkHours Started");

            // Get request body
            string requestBody = await _httpRequestBodyReader.ReadRequestBodyAsync(req, keepStreamOpen: true);

            // Get request object
            var request = JsonConvert.DeserializeObject<CreateTeamMemberRequest>(requestBody);

            // Validate request and return if request is invalid
            ValidationResult validationResult = await _createTeamMemberRequest.ValidateAsync(request);
            if (!validationResult.IsValid)
            {
                return new BadRequestObjectResult(validationResult.Errors.Select(e => new
                {
                    e.ErrorCode,
                    e.PropertyName,
                    e.ErrorMessage
                }));
            }

            // Send command
            var updateQuery = _mapper.Map<CreateResourceCommand>(request);
            var queryResponse = await _mediator.Send(updateQuery);

            var response = _mapper.Map<DefaultResponseResult>(queryResponse);

            if (response == null)
            {
                return new NotFoundResult();
            }
            _logger.LogInformation($"Response : {System.Text.Json.JsonSerializer.Serialize(response)}");
            _logger.LogInformation("Function Call : UpdateWeekNonWorkHours Completed");
            return new OkObjectResult(response);
        }

    }
}
