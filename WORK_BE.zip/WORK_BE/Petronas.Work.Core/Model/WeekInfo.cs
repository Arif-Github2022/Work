﻿namespace Petronas.Work.Core.Model
{
    public class WeekInfo
    {
        public int WeekNumberOfYear { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }
    }
}
