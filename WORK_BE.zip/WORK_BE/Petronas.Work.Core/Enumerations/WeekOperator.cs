﻿using System.Text.Json.Serialization;

namespace Petronas.Work.Core.Enumerations
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum WeekOperator
    {
        None,
        Next,
        Previous
    }
}
