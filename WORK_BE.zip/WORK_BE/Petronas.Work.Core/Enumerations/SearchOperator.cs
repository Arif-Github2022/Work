﻿using System.Text.Json.Serialization;

namespace Petronas.Work.Core.Enumerations
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum SearchOperator
    {
        And = 0,
        Or = 1
    }
}
