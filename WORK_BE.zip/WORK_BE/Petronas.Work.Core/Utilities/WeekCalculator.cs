﻿using Petronas.Work.Core.Extensions;
using Petronas.Work.Core.Model;
using System.Globalization;

namespace Petronas.Work.Core.Utilities
{
    public class WeekCalculator
    {
        public async Task<List<WeekInfo>> GetWeeks(DateTime startDate, DateTime endDate, DayOfWeek firstDayOfWeek = DayOfWeek.Monday, DayOfWeek lastDayOfWeek = DayOfWeek.Sunday)
        {
            return await Task.Run(() =>
            {
                int daysInWeek = 7;
                List<WeekInfo> weekInfo = new();
                DateTime currentDate = startDate;

                DateTime lastDayOfWeekAfterEndDate;
                int daysBetweenEndDateAndFollowingLastDayOfWeek = (int)lastDayOfWeek - (int)endDate.DayOfWeek;
                if (daysBetweenEndDateAndFollowingLastDayOfWeek >= 0)
                {
                    lastDayOfWeekAfterEndDate = endDate.AddDays(daysBetweenEndDateAndFollowingLastDayOfWeek);
                }
                else
                {
                    lastDayOfWeekAfterEndDate = endDate.AddDays(daysBetweenEndDateAndFollowingLastDayOfWeek + daysInWeek);
                }

                while (currentDate < lastDayOfWeekAfterEndDate)
                {
                    DateTime firstDayOfWeekBeforeStartDate;

                    int daysBetweenStartDateAndPreviousFirstDayOfWeek = (int)currentDate.DayOfWeek - (int)firstDayOfWeek;

                    if (daysBetweenStartDateAndPreviousFirstDayOfWeek >= 0)
                    {
                        firstDayOfWeekBeforeStartDate = currentDate.AddDays(-daysBetweenStartDateAndPreviousFirstDayOfWeek);
                    }
                    else
                    {
                        firstDayOfWeekBeforeStartDate = currentDate.AddDays(-(daysBetweenStartDateAndPreviousFirstDayOfWeek + daysInWeek));
                    }

                    weekInfo.Add(new WeekInfo
                    {
                        StartDate = firstDayOfWeekBeforeStartDate,
                        EndDate = firstDayOfWeekBeforeStartDate.AddDays(daysInWeek - 1),
                        WeekNumberOfYear = CultureInfo.CurrentCulture.Calendar.GetWeekOfYear(firstDayOfWeekBeforeStartDate, CalendarWeekRule.FirstFullWeek, firstDayOfWeek)
                    });

                    // Move to Next Week
                    currentDate = currentDate.Next(currentDate.DayOfWeek);
                }

                return weekInfo;
            });
        }
    }
}
