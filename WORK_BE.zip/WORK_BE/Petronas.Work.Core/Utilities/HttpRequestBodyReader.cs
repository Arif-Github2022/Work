﻿using Microsoft.AspNetCore.Http;

namespace Petronas.Work.Core.Utilities
{
    public class HttpRequestBodyReader
    {
        public async Task<string> ReadRequestBodyAsync(HttpRequest request, int streamBufferSize = 1024 * 500, bool keepStreamOpen = false)
        {
            request.EnableBuffering(streamBufferSize);

            string requestBody;
            using (var reader = new StreamReader(request.Body, System.Text.Encoding.UTF8, false, streamBufferSize, keepStreamOpen))
            {
                requestBody = await reader.ReadToEndAsync();
                request.Body.Position = 0;
            }

            return requestBody;
        }
    }
}
