﻿using System.Globalization;

namespace Petronas.Work.Core.Extensions
{
    public static class DateTimeExtensions
    {
        /// <summary>
        /// Calculates next week day from current date.
        /// </summary>
        /// <param name="from">From date</param>
        /// <param name="dayOfTheWeek">Day of week</param>
        /// <returns>Date of next week</returns>
        public static DateTime Next(this DateTime from, DayOfWeek dayOfTheWeek)
        {
            var date = from.Date.AddDays(1);
            var days = ((int)dayOfTheWeek - (int)date.DayOfWeek + 7) % 7;
            return date.AddDays(days);
        }

        public static DateTime FirstDayOfMonth(this DateTime currentDate)
        {
            return new DateTime(currentDate.Year, currentDate.Month, 1);
        }

        public static DateTime LastDayOfMonth(this DateTime dateTime)
        {
            return new DateTime(dateTime.Year, dateTime.Month, CultureInfo.CurrentCulture.Calendar.GetDaysInMonth(dateTime.Year, dateTime.Month));
        }
    }
}
