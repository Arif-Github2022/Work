﻿namespace Petronas.Work.Core.Constants
{
    public struct Company
    {
        public const string Petronas = "Petronas";
    }
}
