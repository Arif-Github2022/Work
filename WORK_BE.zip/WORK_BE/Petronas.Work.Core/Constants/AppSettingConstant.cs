﻿namespace Petronas.Work.Core.Constants
{
    public struct AppSettingConstant
    {
        public struct ConnectionStrings
        {
            public const string WorkDbConnectionString = "WorkDbConnectionString";
        }

        public struct AssemblyNames
        {
            public const string Petronas_Work_Data = "Petronas.Work.Data";
        }

        public struct ExternalIntegrations
        {
            public struct Ace
            {
                public const string AceClientId = "AceClientId";
                public const string AceClientSecret = "AceClientSecret";
                public const string AceAuthorization = "AceAuthorization";
                public const string AceToken = "AceToken";
                public const string AceBaseUri = "AceBaseUri";
                public const string AceResourceUri = "AceResourceUri";
            }

            public struct Sap
            {
                public const string SapClientId = "SapClientId";
                public const string SapClientSecret = "SapClientSecret";
                public const string SapBaseUri = "SapBaseUri";
                
                public const string SapGetWorkOrdersResourceUri = "SapGetWorkOrdersResourceUri";
                public const string SapGetWorkOperationsResourceUri = "SapGetWorkOperationsResourceUri";
            }
        }
    }
}
