﻿namespace Petronas.Work.Core.Constants
{
    public struct Role
    {
        public const string Superintendent = "Superintendent";
        public const string Technician = "Technician";
    }
}
