﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Petronas.Work.Data.Migrations
{
    public partial class InitialMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "dbo");

            migrationBuilder.CreateTable(
                name: "Resource",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Company = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsContractor = table.Column<bool>(type: "bit", nullable: true),
                    AceId = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RecordCreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RecordCreatedById = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    RecordUpdatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RecordUpdatedById = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Resource", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Role",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RecordCreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RecordCreatedById = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    RecordUpdatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RecordUpdatedById = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Role", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Team",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RecordCreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RecordCreatedById = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    RecordUpdatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RecordUpdatedById = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Team", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "WorkOrder",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    OrderNumber = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    OrderType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    OrderDescription = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DefectCode = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MaintenancePlant = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MaintenancePlanningPlant = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MaintenanceObjectLocation = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SystemStatus = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserStatus = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PlannerGroup = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MainWorkCenter = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MainWorkCenterPlant = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MaintenanceActivityType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    NotificationNo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BasicStartDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    BasicFinishDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ScheduledStartDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ScheduledFinishDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ActualStartDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ActualFinishDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Priority = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FunctionalLocation = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FunctionalLocationDescription = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    EquipmentNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    EquipmentDescription = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SuperiorOrder = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PlannedCost = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ActualCost = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Wbs = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ChangedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    CreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ScheduledStartTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ScheduledFinishTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Revision = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RecordCreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RecordCreatedById = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    RecordUpdatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RecordUpdatedById = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WorkOrder", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "DefaultResourceWorkPlan",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    WeekDay = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ResourceId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    WorkHours = table.Column<int>(type: "int", nullable: false),
                    RecordCreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RecordCreatedById = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    RecordUpdatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RecordUpdatedById = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DefaultResourceWorkPlan", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DefaultResourceWorkPlan_Resource_ResourceId",
                        column: x => x.ResourceId,
                        principalSchema: "dbo",
                        principalTable: "Resource",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ResourceCapacity",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ResourceId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    WorkHours = table.Column<int>(type: "int", nullable: true),
                    AwayHours = table.Column<int>(type: "int", nullable: true),
                    Day = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RecordCreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RecordCreatedById = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    RecordUpdatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RecordUpdatedById = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ResourceCapacity", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ResourceCapacity_Resource_ResourceId",
                        column: x => x.ResourceId,
                        principalSchema: "dbo",
                        principalTable: "Resource",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ResourceRole",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ResourceId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    RoleId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    RecordCreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RecordCreatedById = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    RecordUpdatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RecordUpdatedById = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ResourceRole", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ResourceRole_Resource_ResourceId",
                        column: x => x.ResourceId,
                        principalSchema: "dbo",
                        principalTable: "Resource",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ResourceRole_Role_RoleId",
                        column: x => x.RoleId,
                        principalSchema: "dbo",
                        principalTable: "Role",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ResourceTeam",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ResourceId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    TeamId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    RecordCreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RecordCreatedById = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    RecordUpdatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RecordUpdatedById = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ResourceTeam", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ResourceTeam_Resource_ResourceId",
                        column: x => x.ResourceId,
                        principalSchema: "dbo",
                        principalTable: "Resource",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ResourceTeam_Team_TeamId",
                        column: x => x.TeamId,
                        principalSchema: "dbo",
                        principalTable: "Team",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "OrderSchedule",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    WorkOrderId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ScheduleStartDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ScheduleEndDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RecordCreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RecordCreatedById = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    RecordUpdatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RecordUpdatedById = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OrderSchedule", x => x.Id);
                    table.ForeignKey(
                        name: "FK_OrderSchedule_WorkOrder_WorkOrderId",
                        column: x => x.WorkOrderId,
                        principalSchema: "dbo",
                        principalTable: "WorkOrder",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ResourceSchedule",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ResourceId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    WorkOrderId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    PlannedDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    PlannedWorkHours = table.Column<int>(type: "int", nullable: true),
                    ActualDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ActualWorkHours = table.Column<int>(type: "int", nullable: true),
                    RecordCreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RecordCreatedById = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    RecordUpdatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RecordUpdatedById = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ResourceSchedule", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ResourceSchedule_Resource_ResourceId",
                        column: x => x.ResourceId,
                        principalSchema: "dbo",
                        principalTable: "Resource",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ResourceSchedule_WorkOrder_WorkOrderId",
                        column: x => x.WorkOrderId,
                        principalSchema: "dbo",
                        principalTable: "WorkOrder",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "WorkOrderNotes",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    WorkOrderId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Notes = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    RecordCreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RecordCreatedById = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    RecordUpdatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    RecordUpdatedById = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WorkOrderNotes", x => x.Id);
                    table.ForeignKey(
                        name: "FK_WorkOrderNotes_WorkOrder_WorkOrderId",
                        column: x => x.WorkOrderId,
                        principalSchema: "dbo",
                        principalTable: "WorkOrder",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_DefaultResourceWorkPlan_ResourceId",
                schema: "dbo",
                table: "DefaultResourceWorkPlan",
                column: "ResourceId");

            migrationBuilder.CreateIndex(
                name: "IX_OrderSchedule_WorkOrderId",
                schema: "dbo",
                table: "OrderSchedule",
                column: "WorkOrderId");

            migrationBuilder.CreateIndex(
                name: "IX_ResourceCapacity_ResourceId",
                schema: "dbo",
                table: "ResourceCapacity",
                column: "ResourceId");

            migrationBuilder.CreateIndex(
                name: "IX_ResourceRole_ResourceId",
                schema: "dbo",
                table: "ResourceRole",
                column: "ResourceId");

            migrationBuilder.CreateIndex(
                name: "IX_ResourceRole_RoleId",
                schema: "dbo",
                table: "ResourceRole",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "IX_ResourceSchedule_ResourceId",
                schema: "dbo",
                table: "ResourceSchedule",
                column: "ResourceId");

            migrationBuilder.CreateIndex(
                name: "IX_ResourceSchedule_WorkOrderId",
                schema: "dbo",
                table: "ResourceSchedule",
                column: "WorkOrderId");

            migrationBuilder.CreateIndex(
                name: "IX_ResourceTeam_ResourceId",
                schema: "dbo",
                table: "ResourceTeam",
                column: "ResourceId");

            migrationBuilder.CreateIndex(
                name: "IX_ResourceTeam_TeamId",
                schema: "dbo",
                table: "ResourceTeam",
                column: "TeamId");

            migrationBuilder.CreateIndex(
                name: "IX_WorkOrder_OrderNumber",
                schema: "dbo",
                table: "WorkOrder",
                column: "OrderNumber",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_WorkOrderNotes_WorkOrderId",
                schema: "dbo",
                table: "WorkOrderNotes",
                column: "WorkOrderId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "DefaultResourceWorkPlan",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "OrderSchedule",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "ResourceCapacity",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "ResourceRole",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "ResourceSchedule",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "ResourceTeam",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "WorkOrderNotes",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Role",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Resource",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Team",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "WorkOrder",
                schema: "dbo");
        }
    }
}
