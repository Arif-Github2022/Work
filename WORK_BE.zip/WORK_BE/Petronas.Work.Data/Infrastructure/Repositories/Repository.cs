﻿using Microsoft.EntityFrameworkCore;
using Petronas.Work.Data.Entities.Interface;
using Petronas.Work.Data.Infrastructure.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Petronas.Work.Data.Infrastructure.Repositories
{
    public class Repository<T> : RepositoryBase<T, DbContext> where T : class, IEntityBase
    {
        public Repository(DbContext dataContext) : base(dataContext)
        {
        }
    }
}
