﻿using Petronas.Work.Data.Entities.dbo;
using Petronas.Work.Data.Infrastructure.Core;

namespace Petronas.Work.Data.Infrastructure.Interface
{
    public interface IWorkDbUnitOfWork : IDisposable
    {
        WorkDbContext DataContext { get; }

        IRepository<DefaultResourceWorkPlan> DefaultResourceWorkPlanRepository { get; }
        
        IRepository<OrderSchedule> OrderScheduleRepository { get; }

        IRepository<Resource> ResourceRepository { get; }
        
        IRepository<ResourceCapacity> ResourceCapacityRepository { get; }
        
        IRepository<ResourceRole> ResourceRoleRepository { get; }
        
        IRepository<ResourceSchedule> ResourceScheduleRepository { get; }
        
        IRepository<ResourceTeam> ResourceTeamRepository { get; }
        
        IRepository<Role> RoleRepository { get; }
        
        IRepository<Team> TeamRepository { get; }
        
        IRepository<WorkOrder> WorkOrderRepository { get; }
        
        IRepository<WorkOrderNotes> WorkOrderNotesRepository { get; }

        IRepository<ResourceRole> ResourceRoleRepositoryNew { get; }

        void SetDetachChanges(bool value);

        Task<int> SqlGet(string storedProcedureName);

        /// <summary>
        /// Save changes into database asynchronously.
        /// </summary>
        /// <returns></returns>
        Task<int> SaveChangesAsync();
      
    }
}
