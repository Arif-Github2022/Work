﻿using System.Linq.Expressions;

namespace Petronas.Work.Data.Infrastructure.Interface
{

    public interface ICoreRepository<T>
    {
        void Add(T entity);

        void AddRange(IList<T> entities);


        void Update(T entity);

        void UpdateRange(IList<T> entities);

        void Delete(T entity, bool isHardDelete = false);
        
        void Delete(Expression<Func<T, bool>> where, bool isHardDelete = false);

        IQueryable<T> GetQuery();
        
        IQueryable<T> GetQuery(Expression<Func<T, bool>> where);
    }
}
