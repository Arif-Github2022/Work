﻿using Microsoft.EntityFrameworkCore;
using Petronas.Work.Data.Entities.dbo;

namespace Petronas.Work.Data.Infrastructure.Interface
{
    public interface IWorkDbContext : IDisposable
    {
        DbSet<WorkOrder> WorkOrders { get; set; }

        DbSet<OrderSchedule> OrderSchedule { get; set; }
        DbSet<WorkOrderNotes> WorkOrderNotes { get; set; }
        
        DbSet<Resource> Resources { get; set; }

        DbSet<ResourceSchedule> ResourceSchedule { get; set; }
        
        DbSet<ResourceCapacity> ResourceCapacities { get; set; }

        DbSet<Role> Roles { get; set; }
        
        DbSet<Team> Teams { get; set; }

        DbSet<ResourceRole> ResourceRoles { get; set; }
        
        DbSet<ResourceTeam> ResourceTeams { get; set; }

        DbSet<DefaultResourceWorkPlan> DefaultResourceWorkPlans { get; set; }
    }
}
