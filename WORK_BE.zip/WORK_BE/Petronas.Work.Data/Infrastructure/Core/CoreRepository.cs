﻿using Microsoft.EntityFrameworkCore;
using Petronas.Work.Data.Infrastructure.Interface;
using System.Linq.Expressions;

namespace Petronas.Work.Data.Infrastructure.Core
{
    public class CoreRepository<T, TContext> : ICoreRepository<T> where T : class where TContext : DbContext
    {
        #region Protected Fields

        protected readonly TContext dataContext;
        protected readonly DbSet<T> dbset;

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="RepositoryBase{T, TDbContext}"/> class.
        /// </summary>
        /// <param name="dataContext">The data context.</param>
        public CoreRepository(TContext dataContext)
        {
            this.dataContext = dataContext;

            // Find Property with typeof(T) on dataContext
            var typeOfDbSet = typeof(DbSet<T>);
            foreach (var prop in dataContext.GetType().GetProperties())
            {
                if (typeOfDbSet == prop.PropertyType)
                {
                    dbset = prop.GetValue(dataContext, null) as DbSet<T>;
                    break;
                }
            }

            if (dbset == null)
            {
                dbset = dataContext.Set<T>();
            }
        }

        #endregion

        #region Virtual Methods

        public virtual void Add(T entity)
        {
            dbset.Add(entity);
        }

        public virtual void AddRange(IList<T> entities)
        {
            dbset.AddRange(entities);
        }

        public virtual void Update(T entity)
        {
            dataContext.Entry(entity).State = EntityState.Modified;
        }

        public virtual void UpdateRange(IList<T> entities)
        {
            foreach (var entity in entities)
            {
                dataContext.Entry(entity).State = EntityState.Modified;
            }
        }

        /// <summary>
        /// Deletes the specified context.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <param name="isHardDelete">is hard delete?</param>
        public virtual void Delete(T entity, bool isHardDelete = false)
        {
            dbset.Remove(entity);
            dataContext.Entry(entity).State = EntityState.Deleted;
        }

        /// <summary>
        /// Deletes the specified context.
        /// </summary>
        /// <param name="where">The where.</param>
        /// <param name="isHardDelete">is hard delete?</param>
        public virtual void Delete(Expression<Func<T, bool>> where, bool isHardDelete = false)
        {
            var entities = GetQuery(where).AsEnumerable();
            foreach (var entity in entities)
            {
                Delete(entity, isHardDelete);
            }
        }

        /// <summary>
        /// Gets the by identifier.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <returns></returns>
        public virtual T GetById(Guid id)
        {
            return dbset.Find(id);
        }

        public virtual ValueTask<T> GetByIdAsync(Guid id)
        {
            return dbset.FindAsync(id);
        }

        public virtual IQueryable<T> GetQuery()
        {
            return dbset.AsQueryable();
        }

        public virtual IQueryable<T> GetQuery(Expression<Func<T, bool>> where)
        {
            return GetQuery().Where(where);
        }

        #endregion
    }
}
