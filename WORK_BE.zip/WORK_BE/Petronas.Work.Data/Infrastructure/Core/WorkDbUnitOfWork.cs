﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Petronas.Work.Data.Entities.Base;
using Petronas.Work.Data.Entities.dbo;
using Petronas.Work.Data.Entities.Interface;
using Petronas.Work.Data.Infrastructure.Interface;
using Petronas.Work.Data.Infrastructure.Repositories;
using System.Data;

namespace Petronas.Work.Data.Infrastructure.Core
{
    public class WorkDbUnitOfWork : IWorkDbUnitOfWork
    {
        private readonly WorkDbContext _dbContext;

        public WorkDbUnitOfWork(WorkDbContext dbContext)
        {
            _dbContext = dbContext;
        }
        #region ---Properties---
        public WorkDbContext DataContext => _dbContext;

        private IRepository<DefaultResourceWorkPlan> _defaultResourceWorkPlanRepository;
        public IRepository<DefaultResourceWorkPlan> DefaultResourceWorkPlanRepository
        {
            get
            {
                return _defaultResourceWorkPlanRepository ?? new Repository<DefaultResourceWorkPlan>(_dbContext);
            }
        }

        private IRepository<OrderSchedule> _orderScheduleRepository;
        public IRepository<OrderSchedule> OrderScheduleRepository
        {
            get
            {
                return _orderScheduleRepository ?? new Repository<OrderSchedule>(_dbContext);
            }
        }

        private IRepository<Resource> _resourceRepository;
        public IRepository<Resource> ResourceRepository
        {
            get
            {
                return _resourceRepository ?? new Repository<Resource>(_dbContext);
            }
        }

        private IRepository<ResourceCapacity> _resourceCapacityRepository;
        public IRepository<ResourceCapacity> ResourceCapacityRepository
        {
            get
            {
                return _resourceCapacityRepository ?? new Repository<ResourceCapacity>(_dbContext);
            }
        }

        private IRepository<ResourceRole> _resourceRoleRepository;
        public IRepository<ResourceRole> ResourceRoleRepository
        {
            get
            {
                return _resourceRoleRepository ?? new Repository<ResourceRole>(_dbContext);
            }
        }

        private IRepository<ResourceRole> _ResourceRoleRepositoryNew;
        public IRepository<ResourceRole> ResourceRoleRepositoryNew
        {
            get
            {
                return _ResourceRoleRepositoryNew ?? new Repository<ResourceRole>(_dbContext);
            }
        }

        

        private IRepository<ResourceSchedule> _resourceScheduleRepository;
        public IRepository<ResourceSchedule> ResourceScheduleRepository
        {
            get
            {
                return _resourceScheduleRepository ?? new Repository<ResourceSchedule>(_dbContext);
            }
        }

        private IRepository<ResourceTeam> _resourceTeamRepository;
        public IRepository<ResourceTeam> ResourceTeamRepository
        {
            get
            {
                return _resourceTeamRepository ?? new Repository<ResourceTeam>(_dbContext);
            }
        }

        private IRepository<Role> _roleRepository;
        public IRepository<Role> RoleRepository
        {
            get
            {
                return _roleRepository ?? new Repository<Role>(_dbContext);
            }
        }

        private IRepository<Team> _teamRepository;
        public IRepository<Team> TeamRepository
        {
            get
            {
                return _teamRepository ?? new Repository<Team>(_dbContext);
            }
        }

        private IRepository<WorkOrder> _workOrderRepository;
        public IRepository<WorkOrder> WorkOrderRepository
        {
            get
            {
                return _workOrderRepository ?? new Repository<WorkOrder>(_dbContext);
            }
        }

        private IRepository<WorkOrderNotes> _workOrderNotesRepository;
        public IRepository<WorkOrderNotes> WorkOrderNotesRepository
        {
            get
            {
                return _workOrderNotesRepository ?? new Repository<WorkOrderNotes>(_dbContext);
            }
        }

        #endregion


        #region Public Methods

        public async Task<int> SaveChangesAsync()
        {
            SaveChangesDetail();
            return await _dbContext.SaveChangesAsync();
        }

        public void Dispose()
        {
            _dbContext.Dispose();
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Sets the detect changes.
        /// </summary>
        /// <param name="value">if set to <c>true</c> [value].</param>
        public void SetDetachChanges(bool value)
        {
            //_dbContext.Configuration.AutoDetectChangesEnabled = value;
        }

        public async Task<int> SqlGet(string storedProcedureName)
        {
            try
            {
                var conn = new SqlConnection(_dbContext.Database.GetConnectionString());
                if (conn == null)
                {
                    throw new InvalidCastException("SqlConnection is invalid for this database");
                }
                await conn.OpenAsync();
                using (var cmd = new SqlCommand(storedProcedureName, conn))
                {
                    cmd.CommandTimeout = 600;
                    cmd.CommandType = CommandType.StoredProcedure;
                    var result = await cmd.ExecuteNonQueryAsync();
                    conn.Close();
                    return result;
                }
            }
            catch (Exception ex)
            {
                return 0;
            }
        }

        #endregion


        #region Private Methods

        /*
        private IRepository<T> Repository<T>() where T : EntityBase, IEntityBase
        {
            return new Repository<T>(_dbContext);
        }*/

        private void SaveChangesDetail()
        {
            var entries = _dbContext.ChangeTracker.Entries();
            foreach (var e in entries)
            {
                if (e.Entity is IEntityBase entity)
                {
                    switch (e.State)
                    {
                        case EntityState.Added:
                            entity.RecordCreatedById = entity.RecordCreatedById != Guid.Empty ? entity.RecordCreatedById : Guid.Empty;
                            entity.RecordCreatedOn = entity.RecordCreatedOn != DateTime.MinValue ? entity.RecordCreatedOn : DateTime.Now;
                            entity.RecordUpdatedById = entity.RecordUpdatedById != Guid.Empty ? entity.RecordUpdatedById : Guid.Empty;
                            entity.RecordUpdatedOn = entity.RecordUpdatedOn != DateTime.MinValue ? entity.RecordUpdatedOn : DateTime.Now;
                            break;
                        case EntityState.Modified:
                            entity.RecordUpdatedById = entity.RecordUpdatedById != Guid.Empty ? entity.RecordUpdatedById : Guid.Empty;
                            entity.RecordUpdatedOn = entity.RecordUpdatedOn != DateTime.MinValue ? entity.RecordUpdatedOn : DateTime.Now;
                            break;
                    }
                }
            }
        }

        #endregion
    }
}
