﻿using Microsoft.EntityFrameworkCore;
using Petronas.Work.Data.Entities.dbo;
using Petronas.Work.Data.Entities.Interface;
using Petronas.Work.Data.Extensions;
using Petronas.Work.Data.Infrastructure.Interface;

namespace Petronas.Work.Data.Infrastructure.Core
{
#pragma warning disable CS8618
    public class WorkDbContext : DbContext, IWorkDbContext
    {
        public DbSet<WorkOrder> WorkOrders { get; set; }
        
        public DbSet<OrderSchedule> OrderSchedule { get; set; }
        
        public DbSet<WorkOrderNotes> WorkOrderNotes { get; set; }
        
        public DbSet<Resource> Resources { get; set; }
        
        public DbSet<ResourceSchedule> ResourceSchedule { get; set; }
        
        public DbSet<ResourceCapacity> ResourceCapacities { get; set; }
        
        public DbSet<Role> Roles { get; set; }
        
        public DbSet<Team> Teams { get; set; }
        
        public DbSet<ResourceRole> ResourceRoles { get; set; }
        
        public DbSet<ResourceTeam> ResourceTeams { get; set; }
        
        public DbSet<DefaultResourceWorkPlan> DefaultResourceWorkPlans { get; set; }

        public WorkDbContext(DbContextOptions<WorkDbContext> contextOptions) : base(contextOptions)
        {
            Database.Migrate();
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            //add filter to get only IsDeleted = false for all tables
            modelBuilder.SetQueryFilterOnAllEntities<IEntityBase>(p => !p.IsDeleted);

            // Global turn off delete behaviour on foreign keys
            // equivalent of builder.Conventions.Remove<OneToManyCascadeDeleteConvention>();
            // and builder.Conventions.Remove<ManyToManyCascadeDeleteConvention>();
            foreach (var relationship in modelBuilder.Model.GetEntityTypes()
                .SelectMany(e => e.GetForeignKeys()))
            {
                relationship.DeleteBehavior = DeleteBehavior.Restrict;
            }
        }
    }
#pragma warning restore CS8618
}
