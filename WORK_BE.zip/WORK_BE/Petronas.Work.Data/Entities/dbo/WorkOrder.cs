﻿using Microsoft.EntityFrameworkCore;
using Petronas.Work.Data.Entities.Base;
using System.ComponentModel.DataAnnotations.Schema;
using System.Net.Mail;

namespace Petronas.Work.Data.Entities.dbo
{
    [Table("WorkOrder", Schema = "dbo")]
    [Index(nameof(OrderNumber), IsUnique = true)]
    public class WorkOrder : EntityBase
    {
        public string OrderNumber { get; set; }

        public string? OrderType { get; set; }

        public string? OrderDescription { get; set; }

        public string? DefectCode { get; set; }

        public string? MaintenancePlant { get; set; }

        public string? MaintenancePlanningPlant { get; set; }

        public string? MaintenanceObjectLocation { get; set; }

        public string? SystemStatus { get; set; }

        public string? UserStatus { get; set; }

        public string? PlannerGroup { get; set; }

        public string? MainWorkCenter { get; set; }

        public string? MainWorkCenterPlant { get; set; }

        public string? MaintenanceActivityType { get; set; }

        public string? NotificationNo { get; set; }

        public DateTime? BasicStartDate { get; set; }

        public DateTime? BasicFinishDate { get; set; }

        public DateTime? ScheduledStartDate { get; set; }

        public DateTime? ScheduledFinishDate { get; set; }

        public DateTime? ActualStartDate { get; set; }

        public DateTime? ActualFinishDate { get; set; }

        public string? Priority { get; set; }

        public string? FunctionalLocation { get; set; }

        public string? FunctionalLocationDescription { get; set; }

        public string? EquipmentNumber { get; set; }

        public string? EquipmentDescription { get; set; }

        public string? SuperiorOrder { get; set; }

        public string? PlannedCost { get; set; }

        public string? ActualCost { get; set; }

        public string? Wbs { get; set; }

        public DateTime? ChangedOn { get; set; }

        public DateTime? CreatedOn { get; set; }

        public DateTime? ScheduledStartTime { get; set; }

        public DateTime? ScheduledFinishTime { get; set; }

        public string? Revision { get; set; }

        public virtual ICollection<OrderSchedule>? OrderSchedule { get; set; }

        public virtual ICollection<WorkOrderNotes>? WorkOrderNotes { get; set; }

        public virtual ICollection<ResourceSchedule>? ResourceSchedule { get; set; }
    }
}
