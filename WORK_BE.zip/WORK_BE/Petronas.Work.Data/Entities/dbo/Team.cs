﻿using Petronas.Work.Data.Entities.Base;
using System.ComponentModel.DataAnnotations.Schema;

namespace Petronas.Work.Data.Entities.dbo
{
    [Table("Team", Schema = "dbo")]
    public class Team : EntityBase
    {
        public string? Name { get; set; }

        public string? Description { get; set; }

        public virtual ICollection<ResourceTeam>? ResourceTeam { get; set; }
    }
}
