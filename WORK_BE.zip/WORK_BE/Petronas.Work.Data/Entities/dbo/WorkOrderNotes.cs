﻿using Petronas.Work.Data.Entities.Base;
using System.ComponentModel.DataAnnotations.Schema;

namespace Petronas.Work.Data.Entities.dbo
{
    [Table("WorkOrderNotes", Schema = "dbo")]
    public class WorkOrderNotes : EntityBase
    {
        public Guid WorkOrderId { get; set; }

        public string? Notes { get; set; }

        [ForeignKey("WorkOrderId")]
        public virtual WorkOrder? WorkOrder { get; set; }
    }
}
