﻿using Petronas.Work.Data.Entities.Base;
using System.ComponentModel.DataAnnotations.Schema;

namespace Petronas.Work.Data.Entities.dbo
{
    [Table("DefaultResourceWorkPlan", Schema = "dbo")]
    public class DefaultResourceWorkPlan : EntityBase
    {
        public string? WeekDay { get; set; }
        
        public Guid ResourceId { get; set; }
        
        public int WorkHours { get; set; }

        [ForeignKey("ResourceId")]
        public virtual Resource? Resource { get; set; }
    }
}
