﻿using Petronas.Work.Data.Entities.Base;
using System.ComponentModel.DataAnnotations.Schema;

namespace Petronas.Work.Data.Entities.dbo
{
    [Table("OrderSchedule", Schema = "dbo")]
    public class OrderSchedule : EntityBase
    {
        public Guid WorkOrderId { get; set; }

        public DateTime? ScheduleStartDate { get; set; }
        
        public DateTime? ScheduleEndDate { get; set; }

        [ForeignKey("WorkOrderId")]
        public virtual WorkOrder? WorkOrder { get; set; }
    }
}
