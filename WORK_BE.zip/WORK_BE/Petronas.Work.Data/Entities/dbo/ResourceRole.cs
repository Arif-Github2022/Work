﻿using Petronas.Work.Data.Entities.Base;
using System.ComponentModel.DataAnnotations.Schema;

namespace Petronas.Work.Data.Entities.dbo
{
    [Table("ResourceRole", Schema = "dbo")]
    public class ResourceRole : EntityBase
    {
        public Guid ResourceId { get; set; }

        public Guid RoleId { get; set; }

        [ForeignKey("ResourceId")]
        public virtual Resource? Resource { get; set; }

        [ForeignKey("RoleId")]
        public virtual Role? Role { get; set; }
    }
}
