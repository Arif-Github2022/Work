﻿using Petronas.Work.Data.Entities.Base;
using System.ComponentModel.DataAnnotations.Schema;

namespace Petronas.Work.Data.Entities.dbo
{
    [Table("ResourceSchedule", Schema = "dbo")]
    public class ResourceSchedule : EntityBase
    {
        public Guid ResourceId { get; set; }

        public Guid WorkOrderId { get; set; }

        public DateTime? PlannedDate { get; set; }
        
        public int? PlannedWorkHours { get; set; }
        
        public DateTime? ActualDate { get; set; }
        
        public int? ActualWorkHours { get; set; }

        [ForeignKey("WorkOrderId")]
        public virtual WorkOrder? WorkOrder { get; set; }

        [ForeignKey("ResourceId")]
        public virtual Resource? Resource { get; set; }
    }
}
