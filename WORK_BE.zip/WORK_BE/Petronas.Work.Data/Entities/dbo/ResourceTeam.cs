﻿using Petronas.Work.Data.Entities.Base;
using System.ComponentModel.DataAnnotations.Schema;

namespace Petronas.Work.Data.Entities.dbo
{
    [Table("ResourceTeam", Schema = "dbo")]
    public class ResourceTeam : EntityBase
    {
        public Guid ResourceId { get; set; }

        public Guid TeamId { get; set; }

        [ForeignKey("ResourceId")]
        public virtual Resource? Resource { get; set; }

        [ForeignKey("TeamId")]
        public virtual Team? Team { get; set; }
    }
}
