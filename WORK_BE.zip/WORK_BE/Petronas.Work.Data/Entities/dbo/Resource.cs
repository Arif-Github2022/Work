﻿using Petronas.Work.Data.Entities.Base;
using System.ComponentModel.DataAnnotations.Schema;

namespace Petronas.Work.Data.Entities.dbo
{
    [Table("Resource", Schema = "dbo")]
    public class Resource : EntityBase
    {
        public string? Name { get; set; }

        public string? Company { get; set; }
        
        public bool? IsContractor { get; set; }
        
        public string? AceId { get; set; }

        public virtual ICollection<ResourceSchedule>? ResourceSchedule { get; set; }

        public virtual ICollection<ResourceCapacity>? ResourceCapacity { get; set; }

        public virtual ICollection<ResourceRole>? ResourceRole { get; set; }

        public virtual ICollection<ResourceTeam>? ResourceTeam { get; set; }

        public virtual ICollection<DefaultResourceWorkPlan>? DefaultResourceWorkPlan { get; set; }
    }
}
