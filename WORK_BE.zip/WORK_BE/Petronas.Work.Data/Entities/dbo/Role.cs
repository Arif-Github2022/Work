﻿using Petronas.Work.Data.Entities.Base;
using System.ComponentModel.DataAnnotations.Schema;

namespace Petronas.Work.Data.Entities.dbo
{
    [Table("Role", Schema = "dbo")]
    public class Role : EntityBase
    { 
        public string? Name { get; set; }

        public virtual ICollection<ResourceRole>? ResourceRole { get; set; }
    }
}
