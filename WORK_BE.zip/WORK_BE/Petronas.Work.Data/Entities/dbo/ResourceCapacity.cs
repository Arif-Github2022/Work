﻿using Petronas.Work.Data.Entities.Base;
using System.ComponentModel.DataAnnotations.Schema;

namespace Petronas.Work.Data.Entities.dbo
{
    [Table("ResourceCapacity", Schema = "dbo")]
    public class ResourceCapacity : EntityBase
    {
        public Guid ResourceId { get; set; }
        
        public int? WorkHours { get; set; }
        
        public int? AwayHours { get; set; }
        
        public DateTime? Day { get; set; }

        [ForeignKey("ResourceId")]
        public virtual Resource? Resource { get; set; }
    }
}
