﻿using Petronas.Work.Data.Entities.Interface;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Petronas.Work.Data.Entities.Base
{
    public abstract class EntityBase : IEntityBase
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public Guid Id { get; set; }
        
        public DateTime? RecordCreatedOn { get; set; }
        
        public Guid? RecordCreatedById { get; set; }
        
        public DateTime? RecordUpdatedOn { get; set; }
        
        public Guid? RecordUpdatedById { get; set; }
        
        public bool IsActive { get; set; }
        
        public bool IsDeleted { get; set; }
    }
}
