﻿using System.ComponentModel.DataAnnotations;

namespace Petronas.Work.Data.Entities.Interface
{
    public interface IEntityBase
    {
        [Key]
        Guid Id { get; set; }

        DateTime? RecordCreatedOn { get; set; }

        Guid? RecordCreatedById { get; set; }

        DateTime? RecordUpdatedOn { get; set; }

        Guid? RecordUpdatedById { get; set; }

        bool IsActive { get; set; }

        bool IsDeleted { get; set; }
    }
}
