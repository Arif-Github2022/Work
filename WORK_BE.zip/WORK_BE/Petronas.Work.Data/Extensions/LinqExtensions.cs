﻿namespace Petronas.Work.Data.Extensions
{
    public static class LinqExtensions
    {
        public static List<TSource> ToListObject<TSource>(this IQueryable<TSource> source, bool queryWithDeleted = false)
        {
            List<TSource>? result = null;
            if (queryWithDeleted)
            {
                //var internalQuery = source.GetPropertyValue("InternalQuery");
                //var internalContext = internalQuery.GetPropertyValue("InternalContext");
                //var dbContext = internalContext.GetPropertyValue("Owner") as DbContext;
                result = source.ToList();
            }
            else
            {
                result = source.ToList();
            }

            return result;
        }
    }
}
